library(relectro)

ep3<-new("ElectroProject",directory="/data/projects/LEC_2objects_verti")
ep3<-setSessionList(ep3)
save(ep3,file=paste(ep3@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep3@resultsDirectory,"ep",sep="/"))
rss3<-getSessionList(ep3,clustered=T)
rss3<-sortRecSessionListChronologically(rss3)

ep4<-new("ElectroProject",directory="/data/projects/LEC_2objects_horiz")
ep4<-setSessionList(ep4)
save(ep4,file=paste(ep4@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep4@resultsDirectory,"ep",sep="/"))
rss4<-getSessionList(ep4,clustered=T)
rss4<-sortRecSessionListChronologically(rss4)


ep <- ep3
rss <- rss3
rm(ep3,rss3)


start.time <- Sys.time()
print(start.time)

source('~/source_scripts/meanwaveform_int.R')
source("~/source_scripts/Positrack.R")

wfs.sham=list()
cell_ids=vector()

#Do this for all sessions 
for (i in 1:length(rss)) {
  rs=rss[[i]]
  print(i)
  print(rs@session)
  
  #Get RecSession objects
  myList<-getRecSessionObjects(rs)
  st<-myList$st
  cg<-myList$cg
  df<-myList$df
  sw<-new("SpikeWaveform",session=rs@session)
  
  st.sham <- setIntervals(st, rs@trialStartRes[1], rs@trialEndRes[1])
  
  sw@wfMsPerBin<-.01
  
  #avoid cells without spikes
  for (clu in 1:length(cg@id)){
    if (length(which(st.sham@res[which(st.sham@clu==clu+1)] >= st.sham@startInterval & st.sham@res[which(st.sham@clu==clu+1)] <= st.sham@endInterval)==T)<2){
      print(paste("removing clu:", cg@id[clu], sep=" "))
      st.sham <- setCellList(st.sham, cellList = st.sham@cellList[which(st.sham@cellList!=clu+1)])
      cg@id <- cg@id[-clu]
      cg@clu <- cg@clu[-clu]
    }
  }
  sw.sham<-meanWaveform_int(sw,rs,st.sham,cg,df,filter=T)
  
  for(clu in cg@id){
    #sham
    wf.sham<-sw.sham@wf[,sw.sham@wfCluId==clu]
    wfs.sham[[length(wfs.sham)+1]]<-wf.sham
    cell_ids[length(cell_ids)+1]<-clu
  }
  
  ## save part already in case of crash
  save(wfs.sham,file=paste(ep@resultsDirectory, "waveforms/Waveforms_part.Rdata", sep = "/"))
  save(cell_ids,file=paste(ep@resultsDirectory, "waveforms/cell_id_waveforms_part.Rdata", sep = "/"))
  
  rm(rs, st, cg, df, sw, myList)
  rm(st.sham, sw.sham, wf.sham)
  
}


save(wfs.sham,file=paste(ep@resultsDirectory, "waveforms/Waveforms_all.Rdata", sep = "/"))
save(cell_ids,file=paste(ep@resultsDirectory, "waveforms/cell_id_waveforms_all.Rdata", sep = "/"))

end.time <- Sys.time()
print(paste("Start time:", start.time, sep = " "))
print(paste("End time:", end.time, sep = " "))
print(paste("Total time:", end.time-start.time, sep = " "))


####### spike waveform properties ##############################################################################################################

load(paste(ep@resultsDirectory, "waveforms/Waveforms_all.Rdata", sep = "/"))
load(paste(ep@resultsDirectory, "/waveforms/cell_id_waveforms_all.Rdata", sep = ""))
cells <- cell_ids
wfs <- wfs.sham

find_peaks <- function (x, m = 3){
  shape <- diff(sign(diff(x, na.pad = FALSE)))
  pks <- sapply(which(shape < 0), FUN = function(i){
    z <- i - m + 1
    z <- ifelse(z > 0, z, 1)
    w <- i + m + 1
    w <- ifelse(w < length(x), w, length(x))
    if(all(x[c(z : i, (i + 2) : w)] <= x[i + 1])) return(i + 1) else return(numeric(0))
  })
  pks <- unlist(pks)
  pks
}

# identify channel with largest spike waveform deflection 
wf.all=sapply(wfs, function(x){x[,which.min(apply(x, 2, min))]})

# trough-to-peak duration AND peak amplitude asymmetry of all cells
ttp.duration=c()
ptt.duration=c()
ptp.duration=c()
sasym=c()
spike.max1.time = c()
spike.max2.time = c()
spike.min.time = c()
spike.max1.voltage = c()
spike.max2.voltage = c()
spike.min.voltage = c()
wf.all.sham=c()
tt=seq(-1.475,1.475,.05) ### == sw@wfTimePoints
time=seq(-1,1,0.01)


for (ii in 1:length(wf.all[1,])) {
  y0=approx(x=tt,y=wf.all[,ii],xout = time) 
  voltage=smooth.spline(y0$y,spar=.3)$y
  spike_min=which.min(voltage)
  spike_max2=find_peaks(voltage[spike_min:length(time)])[1]+spike_min-1
  n1=((length(time)-1)/4)
  spike_max1=tail(find_peaks(voltage[n1:spike_min]),n=1)+(n1-1)
  if(length(spike_max1)==0){
    spike_max1 = tail(which(diff(diff(voltage[n1:spike_min]))>0),n=1)+(n1-1)
  }
  a = voltage[spike_max1]
  b = voltage[spike_max2]  
  sasym_before <- length(sasym)
  sasym=c(sasym,(b-a)/(abs(b)+abs(a)))
  sasym_after <- length(sasym)
  if(sasym_after - sasym_before != 1){
    print(paste("Problem with", ii, sep = " "))
    sasym=c(sasym,NA)
    ttp.duration=c(ttp.duration,NA)
    ptt.duration=c(ptt.duration,NA)
    ptp.duration=c(ptp.duration,NA)
    wf.all.sham=rbind(wf.all.sham,voltage)
    spike.max1.time=c(spike.max1.time,NA)
    spike.max2.time=c(spike.max2.time,NA)
    spike.min.time=c(spike.min.time,NA)
    spike.max1.voltage=c(spike.max1.voltage,NA)
    spike.max2.voltage=c(spike.max2.voltage,NA)
    spike.min.voltage=c(spike.min.voltage,NA)
  } else{
    
    # calculate trough-to-peak duration + more
    ttp.duration =c(ttp.duration,time[spike_max2]-time[spike_min])
    ptt.duration = c(ptt.duration, time[spike_min]-time[spike_max1])
    ptp.duration = c(ptp.duration, time[spike_max2]- time[spike_max1])
    wf.all.sham=rbind(wf.all.sham,voltage)
    
    #collect all values
    spike.max1.time = c(spike.max1.time,time[spike_max1])
    spike.max2.time = c(spike.max2.time,time[spike_max2])
    spike.min.time  = c(spike.min.time, time[spike_min])
    spike.max1.voltage = c(spike.max1.voltage,voltage[spike_max1])
    spike.max2.voltage = c(spike.max2.voltage, voltage[spike_max2])
    spike.min.voltage = c(spike.min.voltage, voltage[spike_min])
  }
}
waveform.data.sham <- data.frame(cell.id = cells[1:length(wf.all[1,])],
                                 trough.to.peak.duration =ttp.duration,
                                 peak.to.trough.duration=ptt.duration,
                                 peak.to.peak.duration=ptp.duration,
                                 spike.asymmetry = sasym,
                                 spike.max1.time = spike.max1.time,
                                 spike.max2.time = spike.max2.time,
                                 spike.min.time = spike.min.time,
                                 spike.max1.voltage = spike.max1.voltage,
                                 spike.max2.voltage = spike.max2.voltage,
                                 spike.min.voltage = spike.min.voltage)

save(file=paste(ep@resultsDirectory,"Waveform.stats.RData",sep="/"),time,wf.all.sham,waveform.data.sham)
write.csv(waveform.data.sham, file=paste(ep@resultsDirectory,"Waveform.stats.csv",sep="/"))

rm(wf.all, wf.all.sham, wfs, wfs.sham, y0, a, b, ptp.duration, ptt.duration, ttp.duration, sasym, sasym_after, sasym_before, 
   spike_max1, spike_max2, spike_min, spike.max1.time, spike.max1.voltage, spike.max2.time, spike.max2.voltage,
   spike.min.time, spike.min.voltage, time, tt, voltage)

# add spike waveform to summary table
cells_all <- read.csv("~/LEC_remapping/results/cells_allLEC_2objectv.csv", header = T)
load(file=paste(ep@resultsDirectory,"Waveform.stats.RData",sep="/"))

waveform.data.sham$cell.id <- factor(waveform.data.sham$cell.id, levels = levels(cells_all$cell.id))

All_Sta_wv <- cells_all
All_Sta_wv[,names(waveform.data.sham)[-1]] <- NA
for (cid in 1:length(waveform.data.sham$cell.id)){
  print(cid)
  for (param in names(waveform.data.sham)[-1]){
    All_Sta_wv[which(All_Sta_wv$cell.id==waveform.data.sham$cell.id[cid]), param] <- waveform.data.sham[cid, param]
  }
}
write.csv(All_Sta_wv, file="~/LEC_remapping/results/cells_allLEC_2objectv_wv.csv", row.names = F)
