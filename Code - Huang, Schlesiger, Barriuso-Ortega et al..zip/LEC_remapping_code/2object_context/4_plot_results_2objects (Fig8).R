library(ggplot2)
library(ggridges)
library(scales)
library(ggpubr)


# ################### load dataset ##################################
cells_all1 <- read.csv("~/LEC_remapping/results/cells_allLEC_2objecth_wz.csv", header = T)
cells_all1$paradigm <- '2objecth_LEC'
cells_all2 <- read.csv("~/LEC_remapping/results/cells_allLEC_2objectv_wz.csv", header = T)
cells_all2$paradigm <- '2objectv_LEC'
cells_all <- rbind(cells_all1, cells_all2)


## zscores by object
cells_all$z.score1_circ <- NA
cells_all$z.score1_tri <- NA
cells_all$sh_zscore1_circ <- NA
cells_all$sh_zscore1_tri <- NA
cells_all$z.score2_circ <- NA
cells_all$z.score2_tri <- NA
cells_all$sh_zscore2_circ <- NA
cells_all$sh_zscore2_tri <- NA
cells_all$z.score3_circ <- NA
cells_all$z.score3_tri <- NA
cells_all$sh_zscore3_circ <- NA
cells_all$sh_zscore3_tri <- NA
cells_all$z.score4_circ <- NA
cells_all$z.score4_tri <- NA
cells_all$sh_zscore4_circ <- NA
cells_all$sh_zscore4_tri <- NA
cells_all$z.score5_circ <- NA
cells_all$z.score5_tri <- NA
cells_all$sh_zscore5_circ <- NA
cells_all$sh_zscore5_tri <- NA

#horizontal protocol
cells_all$z.score1_circ[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$z.score1_tl[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$z.score1_tri[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$z.score1_tr[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$sh_zscore1_circ[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$shuff.zscore1_tl[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$sh_zscore1_tri[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$shuff.zscore1_tr[which(cells_all$paradigm=="2objecth_LEC")]

cells_all$z.score2_circ[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$z.score2_tr[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$z.score2_tri[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$z.score2_tl[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$sh_zscore2_circ[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$shuff.zscore2_tr[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$sh_zscore2_tri[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$shuff.zscore2_tl[which(cells_all$paradigm=="2objecth_LEC")]

cells_all$z.score3_circ[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$z.score3_br[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$z.score3_tri[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$z.score3_bl[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$sh_zscore3_circ[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$shuff.zscore3_br[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$sh_zscore3_tri[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$shuff.zscore3_bl[which(cells_all$paradigm=="2objecth_LEC")]

cells_all$z.score4_circ[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$z.score4_bl[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$z.score4_tri[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$z.score4_br[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$sh_zscore4_circ[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$shuff.zscore4_bl[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$sh_zscore4_tri[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$shuff.zscore4_br[which(cells_all$paradigm=="2objecth_LEC")]

cells_all$z.score5_circ[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$z.score5_bl[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$z.score5_tri[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$z.score5_tr[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$sh_zscore5_circ[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$shuff.zscore5_bl[which(cells_all$paradigm=="2objecth_LEC")]
cells_all$sh_zscore5_tri[which(cells_all$paradigm=="2objecth_LEC")] <- cells_all$shuff.zscore5_tr[which(cells_all$paradigm=="2objecth_LEC")]

#vertical protocol
cells_all$z.score1_circ[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$z.score1_br[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$z.score1_tri[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$z.score1_tr[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$sh_zscore1_circ[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$shuff.zscore1_br[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$sh_zscore1_tri[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$shuff.zscore1_tr[which(cells_all$paradigm=="2objectv_LEC")]

cells_all$z.score2_circ[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$z.score2_tr[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$z.score2_tri[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$z.score2_br[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$sh_zscore2_circ[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$shuff.zscore2_tr[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$sh_zscore2_tri[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$shuff.zscore2_br[which(cells_all$paradigm=="2objectv_LEC")]

cells_all$z.score3_circ[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$z.score3_tl[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$z.score3_tri[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$z.score3_bl[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$sh_zscore3_circ[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$shuff.zscore3_tl[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$sh_zscore3_tri[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$shuff.zscore3_bl[which(cells_all$paradigm=="2objectv_LEC")]

cells_all$z.score4_circ[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$z.score4_bl[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$z.score4_tri[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$z.score4_tl[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$sh_zscore4_circ[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$shuff.zscore4_bl[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$sh_zscore4_tri[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$shuff.zscore4_tl[which(cells_all$paradigm=="2objectv_LEC")]

cells_all$z.score5_circ[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$z.score5_br[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$z.score5_tri[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$z.score5_tl[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$sh_zscore5_circ[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$shuff.zscore5_br[which(cells_all$paradigm=="2objectv_LEC")]
cells_all$sh_zscore5_tri[which(cells_all$paradigm=="2objectv_LEC")] <- cells_all$shuff.zscore5_tl[which(cells_all$paradigm=="2objectv_LEC")]
#############################


#filter by firing rate and info score
cells_all_f <- cells_all[which(cells_all$MFR_S1>0.1 & cells_all$MFR_S2>0.1 & cells_all$MFR_S3>0.1 & cells_all$MFR_S4>0.1 &
                                 cells_all$MFR_S5>0.1 & cells_all$MFR_S1<5 & cells_all$MFR_S2<5 & cells_all$MFR_S3<5 & cells_all$MFR_S4<5 &
                                 cells_all$MFR_S5<5 & (cells_all$trough.to.peak.duration>0.4 & cells_all$spike.asymmetry<0.1)),]#


## March 2023 latest classification
cells_all_f <- cells_all[which(cells_all$MFR_S1>0.1 & cells_all$MFR_S2>0.1 & cells_all$MFR_S3>0.1 & cells_all$MFR_S4>0.1 &
                                 cells_all$MFR_S5>0.1 & cells_all$MFR_S1<5 & cells_all$MFR_S2<5 & cells_all$MFR_S3<5 & cells_all$MFR_S4<5 &
                                 cells_all$MFR_S5<5 & (cells_all$trough.to.peak.duration>0.4 & cells_all$spike.asymmetry<0.1)),]#
cells_all_f$class <- "other"
cells_all_f$class[which((cells_all_f$z.score1_circ>cells_all_f$sh_zscore1_circ & cells_all_f$z.score2_circ>cells_all_f$sh_zscore2_circ & cells_all_f$z.score5_circ>cells_all_f$sh_zscore5_circ & (cells_all_f$z.score3_circ<cells_all_f$sh_zscore3_circ & cells_all_f$z.score4_circ<cells_all_f$sh_zscore4_circ)) |
                                                                  (cells_all_f$z.score1_tri>cells_all_f$sh_zscore1_tri & cells_all_f$z.score2_tri>cells_all_f$sh_zscore2_tri & cells_all_f$z.score5_tri>cells_all_f$sh_zscore5_tri & (cells_all_f$z.score3_tri<cells_all_f$sh_zscore3_tri & cells_all_f$z.score4_tri<cells_all_f$sh_zscore4_tri))|
                                                                  (cells_all_f$z.score1_circ<cells_all_f$sh_zscore1_circ & cells_all_f$z.score2_circ<cells_all_f$sh_zscore2_circ & cells_all_f$z.score5_circ<cells_all_f$sh_zscore5_circ & (cells_all_f$z.score3_circ>cells_all_f$sh_zscore3_circ & cells_all_f$z.score4_circ>cells_all_f$sh_zscore4_circ)) |
                                                                  (cells_all_f$z.score1_tri<cells_all_f$sh_zscore1_tri & cells_all_f$z.score2_tri<cells_all_f$sh_zscore2_tri & cells_all_f$z.score5_tri<cells_all_f$sh_zscore5_tri & (cells_all_f$z.score3_tri>cells_all_f$sh_zscore3_tri & cells_all_f$z.score4_tri>cells_all_f$sh_zscore4_tri)))]<- "context-dependent-object-identity-cell"

cells_all_f$class[which(((cells_all_f$z.score1_circ>cells_all_f$sh_zscore1_circ & cells_all_f$z.score2_circ>cells_all_f$sh_zscore2_circ & cells_all_f$z.score5_circ>cells_all_f$sh_zscore5_circ & (cells_all_f$z.score3_circ<cells_all_f$sh_zscore3_circ & cells_all_f$z.score4_circ<cells_all_f$sh_zscore4_circ)) &
                          (cells_all_f$z.score1_tri>cells_all_f$sh_zscore1_tri & cells_all_f$z.score2_tri>cells_all_f$sh_zscore2_tri & cells_all_f$z.score5_tri>cells_all_f$sh_zscore5_tri & (cells_all_f$z.score3_tri<cells_all_f$sh_zscore3_tri & cells_all_f$z.score4_tri<cells_all_f$sh_zscore4_tri)))|
                          ((cells_all_f$z.score1_circ<cells_all_f$sh_zscore1_circ & cells_all_f$z.score2_circ<cells_all_f$sh_zscore2_circ & cells_all_f$z.score5_circ<cells_all_f$sh_zscore5_circ & (cells_all_f$z.score3_circ>cells_all_f$sh_zscore3_circ & cells_all_f$z.score4_circ>cells_all_f$sh_zscore4_circ)) &
                          (cells_all_f$z.score1_tri<cells_all_f$sh_zscore1_tri & cells_all_f$z.score2_tri<cells_all_f$sh_zscore2_tri & cells_all_f$z.score5_tri<cells_all_f$sh_zscore5_tri & (cells_all_f$z.score3_tri>cells_all_f$sh_zscore3_tri & cells_all_f$z.score4_tri>cells_all_f$sh_zscore4_tri))))]<- "context-dependent-object-cell"

cells_all_f$class[which(((cells_all_f$z.score2_circ>cells_all_f$sh_zscore2_circ & cells_all_f$z.score3_circ>cells_all_f$sh_zscore3_circ) | (cells_all_f$z.score2_tri>cells_all_f$sh_zscore2_tri & cells_all_f$z.score3_tri>cells_all_f$sh_zscore3_tri))|
                          ((cells_all_f$z.score1_circ>cells_all_f$sh_zscore1_circ & cells_all_f$z.score3_circ>cells_all_f$sh_zscore3_circ) | (cells_all_f$z.score1_tri>cells_all_f$sh_zscore1_tri & cells_all_f$z.score3_tri>cells_all_f$sh_zscore3_tri))|
                          ((cells_all_f$z.score2_circ>cells_all_f$sh_zscore2_circ & cells_all_f$z.score4_circ>cells_all_f$sh_zscore4_circ) | (cells_all_f$z.score2_tri>cells_all_f$sh_zscore2_tri & cells_all_f$z.score4_tri>cells_all_f$sh_zscore4_tri))|
                          ((cells_all_f$z.score1_circ>cells_all_f$sh_zscore1_circ & cells_all_f$z.score4_circ>cells_all_f$sh_zscore4_circ) | (cells_all_f$z.score1_tri>cells_all_f$sh_zscore1_tri & cells_all_f$z.score4_tri>cells_all_f$sh_zscore4_tri)))]<- "object-identity-cell"

cells_all_f$class[which(((cells_all_f$z.score2_circ>cells_all_f$sh_zscore2_circ & cells_all_f$z.score3_circ>cells_all_f$sh_zscore3_circ) & (cells_all_f$z.score2_tri>cells_all_f$sh_zscore2_tri & cells_all_f$z.score3_tri>cells_all_f$sh_zscore3_tri))|
                        ((cells_all_f$z.score1_circ>cells_all_f$sh_zscore1_circ & cells_all_f$z.score3_circ>cells_all_f$sh_zscore3_circ) & (cells_all_f$z.score1_tri>cells_all_f$sh_zscore1_tri & cells_all_f$z.score3_tri>cells_all_f$sh_zscore3_tri))|
                          ((cells_all_f$z.score2_circ>cells_all_f$sh_zscore2_circ & cells_all_f$z.score4_circ>cells_all_f$sh_zscore4_circ) & (cells_all_f$z.score2_tri>cells_all_f$sh_zscore2_tri & cells_all_f$z.score4_tri>cells_all_f$sh_zscore4_tri))|
                          ((cells_all_f$z.score1_circ>cells_all_f$sh_zscore1_circ & cells_all_f$z.score4_circ>cells_all_f$sh_zscore4_circ) & (cells_all_f$z.score1_tri>cells_all_f$sh_zscore1_tri & cells_all_f$z.score4_tri>cells_all_f$sh_zscore4_tri)))]<- "object-cell"

#pie chart
library(stringr)
library(dplyr)
plot_data <- cells_all_f[which(cells_all_f$class!="other"),] %>%
  group_by(paradigm, class) %>%
  tally %>%
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = "", y = percent, fill=class))+
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 0),'%', sep="")), position = position_stack(vjust=0.5), color="white") +#,vjust = 1.2
  coord_polar(theta="y",start = 0, direction = 1)+
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_void() +
  facet_wrap(.~paradigm)



######################### 1 session per mouse per protocol ####################
#pie chart
library(stringr)
library(dplyr)
#
plot_data <- cells_all_f[which(cells_all_f$class!="other"),] %>%
  group_by(paradigm, session) %>%
  tally %>%
  mutate(percent = n/sum(n))

cells_sess <- cells_all_f[which(cells_all_f$session=="ms5824-25082018-0107" | cells_all_f$session=="ms5849-27082018-0107"|
                                  cells_all_f$session=="ms6611-16112018-0107" | cells_all_f$session=="ms5824-11082018-0107"|
                                  cells_all_f$session=="ms5849-21082018-0107" | cells_all_f$session=="ms6611-13112018-0107"),]

plot_data <- cells_sess[which(cells_sess$class!="other"),] %>%
  group_by(paradigm, class) %>%
  tally %>%
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = "", y = percent, fill=class)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 0),'%', sep="")), position = position_stack(vjust=0.5), color="white") +#,vjust = 1.2
  coord_polar(theta="y",start = 0, direction = 1)+
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_void() +
  facet_wrap(.~paradigm)
