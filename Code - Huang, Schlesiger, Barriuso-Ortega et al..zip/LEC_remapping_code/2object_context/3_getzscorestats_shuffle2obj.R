library(relectro)
library(ggplot2)
library(scales)
library(gridBase)
library(grid)

source('~/source_scripts/Positrack.R')
source("~/source_scripts/getZscoreShuffle.R")

ep3<-new("ElectroProject",directory="/data/projects/LEC_2objects_verti")
ep3<-setSessionList(ep3)
save(ep3,file=paste(ep3@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep3@resultsDirectory,"ep",sep="/"))
rss3<-getSessionList(ep3,clustered=T)
rss3<-sortRecSessionListChronologically(rss3)

ep4<-new("ElectroProject",directory="/data/projects/LEC_2objects_horiz")
ep4<-setSessionList(ep4)
save(ep4,file=paste(ep4@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep4@resultsDirectory,"ep",sep="/"))
rss4<-getSessionList(ep4,clustered=T)
rss4<-sortRecSessionListChronologically(rss4)


zscorestats_5OF2object <- function(rs){
  print(rs@session)
  myList<-getRecSessionObjects(rs)
  st<-myList$st
  pt<-myList$pt
  cg<-myList$cg
  sp<-myList$sp
  
  #make coordinates match between the boxes and go from 0,70 (cm)
  pt_positrack <- setInvalidOutsideInterval(pt, s=rs@trialStartRes[c(1,3,5,7,9)], e=rs@trialEndRes[c(1,3,5,7,9)])
  int_posi <- data.frame(start=rs@trialStartRes[c(1,3,5,7,9)], end=rs@trialEndRes[c(1,3,5,7,9)])
  pt_posib <- pt_positrack
  for (interval in 1:length(int_posi[,1])){
    pt_posib@x <- pt_positrack@x[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@y <- pt_positrack@y[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@xWhl <- pt_positrack@xWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@yWhl <- pt_positrack@yWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt@x[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@x))] <- rescale(pt_posib@x[!is.na(pt_posib@x)], to = c(0,70), from=range(pt_posib@x, na.rm = T))
    pt@y[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@y))] <- rescale(pt_posib@y[!is.na(pt_posib@y)], to = c(0,70), from=range(pt_posib@y, na.rm = T))
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@xWhl[which(pt_posib@xWhl>=0)], to = c(0, 700), from=range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T))
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@yWhl[which(pt_posib@yWhl>=0)], to = c(0, 700), from=range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T))
  }
  int_hc <- data.frame(start=rs@trialStartRes[c(2,4,6,8)], end=rs@trialEndRes[c(2,4,6,8)]) 
  pt_hc <- setInvalidOutsideInterval(pt, s=int_hc[,1],e=int_hc[,2])
  x_save <- range(pt_posib@x, na.rm = T)
  y_save <- range(pt_posib@y, na.rm = T)
  xw_save <- range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T)
  yw_save <- range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T)
  for (t in 1:nrow(int_hc)){
    x <- pt_hc@x[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    y <- pt_hc@y[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    xWhl <- pt_hc@xWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    yWhl <- pt_hc@yWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    pt@x[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=x_save)
    pt@y[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=y_save)
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=xw_save) 
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=yw_save)
  }
  rm(x, y, yWhl, xWhl, pt_hc, int_hc, int_posi, pt_posib, pt_positrack) #free some memory
  
  print(paste('min x_cm:', min(pt@x, na.rm = T),'; max x_cm:', max(pt@x, na.rm = T)))
  print(paste('min y_cm:', min(pt@y, na.rm = T),'; max y_cm:', max(pt@y, na.rm = T)))
  
  ### IMPORTANT: recalculate speed after rescaling ## 
  ## get the speed from position
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  pt@speed[which(pt@speed==(-1.0))] <- NA
  
  ######### basic_stats ##########
  st <- meanFiringRate(st)
  st.s1 <- setIntervals(st, s=rs@trialStartRes[1], e=rs@trialEndRes[1])
  st.s2 <- setIntervals(st, s=rs@trialStartRes[3], e=rs@trialEndRes[3])
  st.s3 <- setIntervals(st, s=rs@trialStartRes[5], e=rs@trialEndRes[5])
  st.s4 <- setIntervals(st, s=rs@trialStartRes[7], e=rs@trialEndRes[7])
  st.s5 <- setIntervals(st, s=rs@trialStartRes[9], e=rs@trialEndRes[9])
  pt.s1<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[1], e=rs@trialEndRes[1])
  pt.s2<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[3], e=rs@trialEndRes[3])
  pt.s3<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[5], e=rs@trialEndRes[5])
  pt.s4<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[7], e=rs@trialEndRes[7])
  pt.s5<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[9], e=rs@trialEndRes[9])
  pt.s1<-speedFilter(pt.s1,minSpeed = 3,maxSpeed = 100)
  pt.s2<-speedFilter(pt.s2,minSpeed = 3,maxSpeed = 100)
  pt.s3<-speedFilter(pt.s3,minSpeed = 3,maxSpeed = 100)
  pt.s4<-speedFilter(pt.s4,minSpeed = 3,maxSpeed = 100)
  pt.s5<-speedFilter(pt.s5,minSpeed = 3,maxSpeed = 100)
  st.s1 <- meanFiringRate(st.s1)
  st.s2 <- meanFiringRate(st.s2)
  st.s3 <- meanFiringRate(st.s3)
  st.s4 <- meanFiringRate(st.s4)
  st.s5 <- meanFiringRate(st.s5)
  
  sp.s1<-firingRateMap2d(sp,st.s1,pt.s1, nRowMap = 37, nColMap = 37)
  sp.s2<-firingRateMap2d(sp,st.s2,pt.s2, nRowMap = 37, nColMap = 37)
  sp.s3<-firingRateMap2d(sp,st.s3,pt.s3, nRowMap = 37, nColMap = 37)
  sp.s4<-firingRateMap2d(sp,st.s4,pt.s4, nRowMap = 37, nColMap = 37)
  sp.s5<-firingRateMap2d(sp,st.s5,pt.s5, nRowMap = 37, nColMap = 37)
  sp.s1@reduceSize <- F
  sp.s2@reduceSize <- F
  sp.s3@reduceSize <- F
  sp.s4@reduceSize <- F
  sp.s5@reduceSize <- F
  
  sp.s1 <- firingRateMapsRotation(sp.s1, 180)
  sp.s2 <- firingRateMapsRotation(sp.s2, 180)
  sp.s3 <- firingRateMapsRotation(sp.s3, 180)
  sp.s4 <- firingRateMapsRotation(sp.s4, 180)
  sp.s5 <- firingRateMapsRotation(sp.s5, 180)
  
  protocol <- 'aabba'
  
  ### z score object ###
  #object zone boundaries for position 1 and 2
  map.df1 <- mapsAsDataFrame(sp.s1) 
  map.df1$rate[map.df1$rate == -1] <- NA
  map.df2 <- mapsAsDataFrame(sp.s2) 
  map.df2$rate[map.df2$rate == -1] <- NA
  map.df3 <- mapsAsDataFrame(sp.s3) 
  map.df3$rate[map.df3$rate == -1] <- NA
  map.df4 <- mapsAsDataFrame(sp.s4) 
  map.df4$rate[map.df4$rate == -1] <- NA
  map.df5 <- mapsAsDataFrame(sp.s5) 
  map.df5$rate[map.df5$rate == -1] <- NA
  #top right
  xmin1<-26
  xmax1<-31
  ymin1<-28
  ymax1<-33
  #bottom left
  xmin2<-7
  xmax2<-12
  ymin2<-5
  ymax2<-10
  #top left
  xmin3<-7
  xmax3<-12
  ymin3<-28
  ymax3<-33
  #bottom right
  xmin4<-26
  xmax4<-31
  ymin4<-5
  ymax4<-10
  
  #save object surrounding zones
  zone1 <- c(xmin1-2,xmax1+4,ymin1-4, ymax1+2) #top right
  zone2 <- c(xmin2-4,xmax2+2,ymin2-2, ymax2+4) #bottom left
  zone3 <- c(xmin3-4,xmax3+2,ymin3-4, ymax3+2) #top left
  zone4 <- c(xmin4-2,xmax4+4,ymin4-2, ymax4+4) #bottom right
  
  #trial 1
  #top right
  map1.zone1 <- map.df1[which(map.df1$x > zone1[1] & map.df1$x < zone1[2]  & map.df1$y > zone1[3] & map.df1$y < zone1[4]),]
  n1.zone1 <- sum(!is.na(map1.zone1$rate[map1.zone1$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map1.nozone1 <- map.df1[which(!(map.df1$x > zone1[1] & map.df1$x < zone1[2]  & map.df1$y > zone1[3] & map.df1$y < zone1[4])),]
  #bottom left
  map1.zone2 <- map.df1[which(map.df1$x > zone2[1] & map.df1$x < zone2[2]  & map.df1$y > zone2[3] & map.df1$y < zone2[4]),]
  n1.zone2 <- sum(!is.na(map1.zone2$rate[map1.zone2$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map1.nozone2 <- map.df1[which(!(map.df1$x > zone2[1] & map.df1$x < zone2[2]  & map.df1$y > zone2[3] & map.df1$y < zone2[4])),]
  #top left
  map1.zone3 <- map.df1[which(map.df1$x > zone3[1] & map.df1$x < zone3[2]  & map.df1$y > zone3[3] & map.df1$y < zone3[4]),]
  n1.zone3 <- sum(!is.na(map1.zone3$rate[map1.zone3$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map1.nozone3 <- map.df1[which(!(map.df1$x > zone3[1] & map.df1$x < zone3[2]  & map.df1$y > zone3[3] & map.df1$y < zone3[4])),]
  #bottom right
  map1.zone4 <- map.df1[which(map.df1$x > zone4[1] & map.df1$x < zone4[2]  & map.df1$y > zone4[3] & map.df1$y < zone4[4]),]
  n1.zone4 <- sum(!is.na(map1.zone4$rate[map1.zone4$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map1.nozone4 <- map.df1[which(!(map.df1$x > zone4[1] & map.df1$x < zone4[2]  & map.df1$y > zone4[3] & map.df1$y < zone4[4])),]
  
  #trial 2
  #top right
  map2.zone1 <- map.df2[which(map.df2$x > zone1[1] & map.df2$x < zone1[2]  & map.df2$y > zone1[3] & map.df2$y < zone1[4]),]
  n2.zone1 <- sum(!is.na(map2.zone1$rate[map2.zone1$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map2.nozone1 <- map.df2[which(!(map.df2$x > zone1[1] & map.df2$x < zone1[2]  & map.df2$y > zone1[3] & map.df2$y < zone1[4])),]
  #bottom left
  map2.zone2 <- map.df2[which(map.df2$x > zone2[1] & map.df2$x < zone2[2]  & map.df2$y > zone2[3] & map.df2$y < zone2[4]),]
  n2.zone2 <- sum(!is.na(map2.zone2$rate[map2.zone2$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map2.nozone2 <- map.df2[which(!(map.df2$x > zone2[1] & map.df2$x < zone2[2]  & map.df2$y > zone2[3] & map.df2$y < zone2[4])),]
  #top left
  map2.zone3 <- map.df2[which(map.df2$x > zone3[1] & map.df2$x < zone3[2]  & map.df2$y > zone3[3] & map.df2$y < zone3[4]),]
  n2.zone3 <- sum(!is.na(map2.zone3$rate[map2.zone3$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map2.nozone3 <- map.df2[which(!(map.df2$x > zone3[1] & map.df2$x < zone3[2]  & map.df2$y > zone3[3] & map.df2$y < zone3[4])),]
  #bottom right
  map2.zone4 <- map.df2[which(map.df2$x > zone4[1] & map.df2$x < zone4[2]  & map.df2$y > zone4[3] & map.df2$y < zone4[4]),]
  n2.zone4 <- sum(!is.na(map2.zone4$rate[map2.zone4$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map2.nozone4 <- map.df2[which(!(map.df2$x > zone4[1] & map.df2$x < zone4[2]  & map.df2$y > zone4[3] & map.df2$y < zone4[4])),]
  
  #trial 3
  #top right
  map3.zone1 <- map.df3[which(map.df3$x > zone1[1] & map.df3$x < zone1[2]  & map.df3$y > zone1[3] & map.df3$y < zone1[4]),]
  n3.zone1 <- sum(!is.na(map3.zone1$rate[map3.zone1$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map3.nozone1 <- map.df3[which(!(map.df3$x > zone1[1] & map.df3$x < zone1[2]  & map.df3$y > zone1[3] & map.df3$y < zone1[4])),]
  #bottom left
  map3.zone2 <- map.df3[which(map.df3$x > zone2[1] & map.df3$x < zone2[2]  & map.df3$y > zone2[3] & map.df3$y < zone2[4]),]
  n3.zone2 <- sum(!is.na(map3.zone2$rate[map3.zone2$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map3.nozone2 <- map.df3[which(!(map.df3$x > zone2[1] & map.df3$x < zone2[2]  & map.df3$y > zone2[3] & map.df3$y < zone2[4])),]
  #top left
  map3.zone3 <- map.df3[which(map.df3$x > zone3[1] & map.df3$x < zone3[2]  & map.df3$y > zone3[3] & map.df3$y < zone3[4]),]
  n3.zone3 <- sum(!is.na(map3.zone3$rate[map3.zone3$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map3.nozone3 <- map.df3[which(!(map.df3$x > zone3[1] & map.df3$x < zone3[2]  & map.df3$y > zone3[3] & map.df3$y < zone3[4])),]
  #bottom right
  map3.zone4 <- map.df3[which(map.df3$x > zone4[1] & map.df3$x < zone4[2]  & map.df3$y > zone4[3] & map.df3$y < zone4[4]),]
  n3.zone4 <- sum(!is.na(map3.zone4$rate[map3.zone4$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map3.nozone4 <- map.df3[which(!(map.df3$x > zone4[1] & map.df3$x < zone4[2]  & map.df3$y > zone4[3] & map.df3$y < zone4[4])),]
  
  #trial 4
  #top right
  map4.zone1 <- map.df4[which(map.df4$x > zone1[1] & map.df4$x < zone1[2]  & map.df4$y > zone1[3] & map.df4$y < zone1[4]),]
  n4.zone1 <- sum(!is.na(map4.zone1$rate[map4.zone1$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map4.nozone1 <- map.df4[which(!(map.df4$x > zone1[1] & map.df4$x < zone1[2]  & map.df4$y > zone1[3] & map.df4$y < zone1[4])),]
  #bottom left
  map4.zone2 <- map.df4[which(map.df4$x > zone2[1] & map.df4$x < zone2[2]  & map.df4$y > zone2[3] & map.df4$y < zone2[4]),]
  n4.zone2 <- sum(!is.na(map4.zone2$rate[map4.zone2$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map4.nozone2 <- map.df4[which(!(map.df4$x > zone2[1] & map.df4$x < zone2[2]  & map.df4$y > zone2[3] & map.df4$y < zone2[4])),]
  #top left
  map4.zone3 <- map.df4[which(map.df4$x > zone3[1] & map.df4$x < zone3[2]  & map.df4$y > zone3[3] & map.df4$y < zone3[4]),]
  n4.zone3 <- sum(!is.na(map4.zone3$rate[map4.zone3$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map4.nozone3 <- map.df4[which(!(map.df4$x > zone3[1] & map.df4$x < zone3[2]  & map.df4$y > zone3[3] & map.df4$y < zone3[4])),]
  #bottom right
  map4.zone4 <- map.df4[which(map.df4$x > zone4[1] & map.df4$x < zone4[2]  & map.df4$y > zone4[3] & map.df4$y < zone4[4]),]
  n4.zone4 <- sum(!is.na(map4.zone4$rate[map4.zone4$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map4.nozone4 <- map.df4[which(!(map.df4$x > zone4[1] & map.df4$x < zone4[2]  & map.df4$y > zone4[3] & map.df4$y < zone4[4])),]
  
  #trial 5
  #top right
  map5.zone1 <- map.df5[which(map.df5$x > zone1[1] & map.df5$x < zone1[2]  & map.df5$y > zone1[3] & map.df5$y < zone1[4]),]
  n5.zone1 <- sum(!is.na(map5.zone1$rate[map5.zone1$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map5.nozone1 <- map.df5[which(!(map.df5$x > zone1[1] & map.df5$x < zone1[2]  & map.df5$y > zone1[3] & map.df5$y < zone1[4])),]
  #bottom left
  map5.zone2 <- map.df5[which(map.df5$x > zone2[1] & map.df5$x < zone2[2]  & map.df5$y > zone2[3] & map.df5$y < zone2[4]),]
  n5.zone2 <- sum(!is.na(map5.zone2$rate[map5.zone2$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map5.nozone2 <- map.df5[which(!(map.df5$x > zone2[1] & map.df5$x < zone2[2]  & map.df5$y > zone2[3] & map.df5$y < zone2[4])),]
  #top left
  map5.zone3 <- map.df5[which(map.df5$x > zone3[1] & map.df5$x < zone3[2]  & map.df5$y > zone3[3] & map.df5$y < zone3[4]),]
  n5.zone3 <- sum(!is.na(map5.zone3$rate[map5.zone3$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map5.nozone3 <- map.df5[which(!(map.df5$x > zone3[1] & map.df5$x < zone3[2]  & map.df5$y > zone3[3] & map.df5$y < zone3[4])),]
  #bottom right
  map5.zone4 <- map.df5[which(map.df5$x > zone4[1] & map.df5$x < zone4[2]  & map.df5$y > zone4[3] & map.df5$y < zone4[4]),]
  n5.zone4 <- sum(!is.na(map5.zone4$rate[map5.zone4$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map5.nozone4 <- map.df5[which(!(map.df5$x > zone4[1] & map.df5$x < zone4[2]  & map.df5$y > zone4[3] & map.df5$y < zone4[4])),]

  #trial 1
  mean_fr1.zone1 <- c()
  mean_fr1.nozone1 <- c()
  sd_fr1.nozone1 <- c()
  mean_fr1.zone2 <- c()
  mean_fr1.nozone2 <- c() 
  sd_fr1.nozone2 <- c()
  mean_fr1.zone3 <- c()
  mean_fr1.nozone3 <- c() 
  sd_fr1.nozone3 <- c()
  mean_fr1.zone4 <- c()
  mean_fr1.nozone4 <- c() 
  sd_fr1.nozone4 <- c()
  #trial2
  mean_fr2.zone1 <- c()
  mean_fr2.nozone1 <- c()
  sd_fr2.nozone1 <- c()
  mean_fr2.zone2 <- c()
  mean_fr2.nozone2 <- c() 
  sd_fr2.nozone2 <- c()
  mean_fr2.zone3 <- c()
  mean_fr2.nozone3 <- c() 
  sd_fr2.nozone3 <- c()
  mean_fr2.zone4 <- c()
  mean_fr2.nozone4 <- c() 
  sd_fr2.nozone4 <- c()
  #trial 3
  mean_fr3.zone1 <- c()
  mean_fr3.nozone1 <- c()
  sd_fr3.nozone1 <- c()
  mean_fr3.zone2 <- c()
  mean_fr3.nozone2 <- c() 
  sd_fr3.nozone2 <- c()
  mean_fr3.zone3 <- c()
  mean_fr3.nozone3 <- c() 
  sd_fr3.nozone3 <- c()
  mean_fr3.zone4 <- c()
  mean_fr3.nozone4 <- c() 
  sd_fr3.nozone4 <- c()
  #trial 4
  mean_fr4.zone1 <- c()
  mean_fr4.nozone1 <- c()
  sd_fr4.nozone1 <- c()
  mean_fr4.zone2 <- c()
  mean_fr4.nozone2 <- c() 
  sd_fr4.nozone2 <- c()
  mean_fr4.zone3 <- c()
  mean_fr4.nozone3 <- c() 
  sd_fr4.nozone3 <- c()
  mean_fr4.zone4 <- c()
  mean_fr4.nozone4 <- c() 
  sd_fr4.nozone4 <- c()
  #trial 5
  mean_fr5.zone1 <- c()
  mean_fr5.nozone1 <- c()
  sd_fr5.nozone1 <- c()
  mean_fr5.zone2 <- c()
  mean_fr5.nozone2 <- c() 
  sd_fr5.nozone2 <- c()
  mean_fr5.zone3 <- c()
  mean_fr5.nozone3 <- c() 
  sd_fr5.nozone3 <- c()
  mean_fr5.zone4 <- c()
  mean_fr5.nozone4 <- c() 
  sd_fr5.nozone4 <- c()
  
  
  for(i in 1:st@nCells){
    #trial 1
    #zone1
    mean_fr1.zone1[i] <- mean(map1.zone1$rate[map1.zone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map1.nozone1_sample <- sample(map1.nozone1$rate[which(map1.nozone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map1.nozone1$rate))], size = n1.zone1)
    mean_fr1.nozone1[i] <- mean(map1.nozone1_sample, na.rm = TRUE)
    sd_fr1.nozone1[i] <- sd(map1.nozone1_sample, na.rm = TRUE)
    #zone2
    mean_fr1.zone2[i] <- mean(map1.zone2$rate[map1.zone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map1.nozone2_sample <- sample(map1.nozone2$rate[which(map1.nozone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map1.nozone2$rate))], size = n1.zone2)
    mean_fr1.nozone2[i] <- mean(map1.nozone2_sample, na.rm = TRUE)
    sd_fr1.nozone2[i] <- sd(map1.nozone2_sample, na.rm = TRUE)
    #zone3
    mean_fr1.zone3[i] <- mean(map1.zone3$rate[map1.zone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map1.nozone3_sample <- sample(map1.nozone3$rate[which(map1.nozone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map1.nozone3$rate))], size = n1.zone3)
    mean_fr1.nozone3[i] <- mean(map1.nozone3_sample, na.rm = TRUE)
    sd_fr1.nozone3[i] <- sd(map1.nozone3_sample, na.rm = TRUE)
    #zone4
    mean_fr1.zone4[i] <- mean(map1.zone4$rate[map1.zone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map1.nozone4_sample <- sample(map1.nozone4$rate[which(map1.nozone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map1.nozone4$rate))], size = n1.zone4)
    mean_fr1.nozone4[i] <- mean(map1.nozone4_sample, na.rm = TRUE)
    sd_fr1.nozone4[i] <- sd(map1.nozone4_sample, na.rm = TRUE)
    
    #trial 2
    #zone1
    mean_fr2.zone1[i] <- mean(map2.zone1$rate[map2.zone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map2.nozone1_sample <- sample(map2.nozone1$rate[which(map2.nozone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map2.nozone1$rate))], size = n2.zone1)
    mean_fr2.nozone1[i] <- mean(map2.nozone1_sample, na.rm = TRUE)
    sd_fr2.nozone1[i] <- sd(map2.nozone1_sample, na.rm = TRUE)
    #zone2
    mean_fr2.zone2[i] <- mean(map2.zone2$rate[map2.zone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map2.nozone2_sample <- sample(map2.nozone2$rate[which(map2.nozone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map2.nozone2$rate))], size = n2.zone2)
    mean_fr2.nozone2[i] <- mean(map2.nozone2_sample, na.rm = TRUE)
    sd_fr2.nozone2[i] <- sd(map2.nozone2_sample, na.rm = TRUE)
    #zone3
    mean_fr2.zone3[i] <- mean(map2.zone3$rate[map2.zone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map2.nozone3_sample <- sample(map2.nozone3$rate[which(map2.nozone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map2.nozone3$rate))], size = n2.zone3)
    mean_fr2.nozone3[i] <- mean(map2.nozone3_sample, na.rm = TRUE)
    sd_fr2.nozone3[i] <- sd(map2.nozone3_sample, na.rm = TRUE)
    #zone4
    mean_fr2.zone4[i] <- mean(map2.zone4$rate[map2.zone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map2.nozone4_sample <- sample(map2.nozone4$rate[which(map2.nozone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map2.nozone4$rate))], size = n2.zone4)
    mean_fr2.nozone4[i] <- mean(map2.nozone4_sample, na.rm = TRUE)
    sd_fr2.nozone4[i] <- sd(map2.nozone4_sample, na.rm = TRUE)
    
    #trial 3
    #zone1
    mean_fr3.zone1[i] <- mean(map3.zone1$rate[map3.zone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map3.nozone1_sample <- sample(map3.nozone1$rate[which(map3.nozone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map3.nozone1$rate))], size = n3.zone1)
    mean_fr3.nozone1[i] <- mean(map3.nozone1_sample, na.rm = TRUE)
    sd_fr3.nozone1[i] <- sd(map3.nozone1_sample, na.rm = TRUE)
    #zone2
    mean_fr3.zone2[i] <- mean(map3.zone2$rate[map3.zone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map3.nozone2_sample <- sample(map3.nozone2$rate[which(map3.nozone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map3.nozone2$rate))], size = n3.zone2)
    mean_fr3.nozone2[i] <- mean(map3.nozone2_sample, na.rm = TRUE)
    sd_fr3.nozone2[i] <- sd(map3.nozone2_sample, na.rm = TRUE)
    #zone3
    mean_fr3.zone3[i] <- mean(map3.zone3$rate[map3.zone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map3.nozone3_sample <- sample(map3.nozone3$rate[which(map3.nozone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map3.nozone3$rate))], size = n3.zone3)
    mean_fr3.nozone3[i] <- mean(map3.nozone3_sample, na.rm = TRUE)
    sd_fr3.nozone3[i] <- sd(map3.nozone3_sample, na.rm = TRUE)
    #zone4
    mean_fr3.zone4[i] <- mean(map3.zone4$rate[map3.zone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map3.nozone4_sample <- sample(map3.nozone4$rate[which(map3.nozone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map3.nozone4$rate))], size = n3.zone4)
    mean_fr3.nozone4[i] <- mean(map3.nozone4_sample, na.rm = TRUE)
    sd_fr3.nozone4[i] <- sd(map3.nozone4_sample, na.rm = TRUE)
    
    #trial 4
    #zone1
    mean_fr4.zone1[i] <- mean(map4.zone1$rate[map4.zone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map4.nozone1_sample <- sample(map4.nozone1$rate[which(map4.nozone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map4.nozone1$rate))], size = n4.zone1)
    mean_fr4.nozone1[i] <- mean(map4.nozone1_sample, na.rm = TRUE)
    sd_fr4.nozone1[i] <- sd(map4.nozone1_sample, na.rm = TRUE)
    #zone2
    mean_fr4.zone2[i] <- mean(map4.zone2$rate[map4.zone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map4.nozone2_sample <- sample(map4.nozone2$rate[which(map4.nozone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map4.nozone2$rate))], size = n4.zone2)
    mean_fr4.nozone2[i] <- mean(map4.nozone2_sample, na.rm = TRUE)
    sd_fr4.nozone2[i] <- sd(map4.nozone2_sample, na.rm = TRUE)
    #zone3
    mean_fr4.zone3[i] <- mean(map4.zone3$rate[map4.zone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map4.nozone3_sample <- sample(map4.nozone3$rate[which(map4.nozone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map4.nozone3$rate))], size = n4.zone3)
    mean_fr4.nozone3[i] <- mean(map4.nozone3_sample, na.rm = TRUE)
    sd_fr4.nozone3[i] <- sd(map4.nozone3_sample, na.rm = TRUE)
    #zone4
    mean_fr4.zone4[i] <- mean(map4.zone4$rate[map4.zone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map4.nozone4_sample <- sample(map4.nozone4$rate[which(map4.nozone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map4.nozone4$rate))], size = n4.zone4)
    mean_fr4.nozone4[i] <- mean(map4.nozone4_sample, na.rm = TRUE)
    sd_fr4.nozone4[i] <- sd(map4.nozone4_sample, na.rm = TRUE)
    
    #trial 5
    #zone1
    mean_fr5.zone1[i] <- mean(map5.zone1$rate[map5.zone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map5.nozone1_sample <- sample(map5.nozone1$rate[which(map5.nozone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map5.nozone1$rate))], size = n5.zone1)
    mean_fr5.nozone1[i] <- mean(map5.nozone1_sample, na.rm = TRUE)
    sd_fr5.nozone1[i] <- sd(map5.nozone1_sample, na.rm = TRUE)
    #zone2
    mean_fr5.zone2[i] <- mean(map5.zone2$rate[map5.zone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map5.nozone2_sample <- sample(map5.nozone2$rate[which(map5.nozone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map5.nozone2$rate))], size = n5.zone2)
    mean_fr5.nozone2[i] <- mean(map5.nozone2_sample, na.rm = TRUE)
    sd_fr5.nozone2[i] <- sd(map5.nozone2_sample, na.rm = TRUE)
    #zone3
    mean_fr5.zone3[i] <- mean(map5.zone3$rate[map5.zone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map5.nozone3_sample <- sample(map5.nozone3$rate[which(map5.nozone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map5.nozone3$rate))], size = n5.zone3)
    mean_fr5.nozone3[i] <- mean(map5.nozone3_sample, na.rm = TRUE)
    sd_fr5.nozone3[i] <- sd(map5.nozone3_sample, na.rm = TRUE)
    #zone4
    mean_fr5.zone4[i] <- mean(map5.zone4$rate[map5.zone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map5.nozone4_sample <- sample(map5.nozone4$rate[which(map5.nozone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map5.nozone4$rate))], size = n5.zone4)
    mean_fr5.nozone4[i] <- mean(map5.nozone4_sample, na.rm = TRUE)
    sd_fr5.nozone4[i] <- sd(map5.nozone4_sample, na.rm = TRUE)
    
  }
  
  #Calculate z score for session 
  #trial1
  z.score1_tr <- (mean_fr1.zone1 - mean_fr1.nozone1)/(sd_fr1.nozone1/sqrt(n1.zone1))
  z.score1_tl <- (mean_fr1.zone3 - mean_fr1.nozone3)/(sd_fr1.nozone3/sqrt(n1.zone3))
  z.score1_br <- (mean_fr1.zone4 - mean_fr1.nozone4)/(sd_fr1.nozone4/sqrt(n1.zone4))
  z.score1_bl <- (mean_fr1.zone2 - mean_fr1.nozone2)/(sd_fr1.nozone2/sqrt(n1.zone2))
  #trial2
  z.score2_tr <- (mean_fr2.zone1 - mean_fr2.nozone1)/(sd_fr2.nozone1/sqrt(n2.zone1))
  z.score2_tl <- (mean_fr2.zone3 - mean_fr2.nozone3)/(sd_fr2.nozone3/sqrt(n2.zone3))
  z.score2_br <- (mean_fr2.zone4 - mean_fr2.nozone4)/(sd_fr2.nozone4/sqrt(n2.zone4))
  z.score2_bl <- (mean_fr2.zone2 - mean_fr2.nozone2)/(sd_fr2.nozone2/sqrt(n2.zone2))
  #trial3
  z.score3_tr <- (mean_fr3.zone1 - mean_fr3.nozone1)/(sd_fr3.nozone1/sqrt(n3.zone1))
  z.score3_tl <- (mean_fr3.zone3 - mean_fr3.nozone3)/(sd_fr3.nozone3/sqrt(n3.zone3))
  z.score3_br <- (mean_fr3.zone4 - mean_fr3.nozone4)/(sd_fr3.nozone4/sqrt(n3.zone4))
  z.score3_bl <- (mean_fr3.zone2 - mean_fr3.nozone2)/(sd_fr3.nozone2/sqrt(n3.zone2))
  #trial4
  z.score4_tr <- (mean_fr4.zone1 - mean_fr4.nozone1)/(sd_fr4.nozone1/sqrt(n4.zone1))
  z.score4_tl <- (mean_fr4.zone3 - mean_fr4.nozone3)/(sd_fr4.nozone3/sqrt(n4.zone3))
  z.score4_br <- (mean_fr4.zone4 - mean_fr4.nozone4)/(sd_fr4.nozone4/sqrt(n4.zone4))
  z.score4_bl <- (mean_fr4.zone2 - mean_fr4.nozone2)/(sd_fr4.nozone2/sqrt(n4.zone2))
  #trial5
  z.score5_tr <- (mean_fr5.zone1 - mean_fr5.nozone1)/(sd_fr5.nozone1/sqrt(n5.zone1))
  z.score5_tl <- (mean_fr5.zone3 - mean_fr5.nozone3)/(sd_fr5.nozone3/sqrt(n5.zone3))
  z.score5_br <- (mean_fr5.zone4 - mean_fr5.nozone4)/(sd_fr5.nozone4/sqrt(n5.zone4))
  z.score5_bl <- (mean_fr5.zone2 - mean_fr5.nozone2)/(sd_fr5.nozone2/sqrt(n5.zone2))
  
  #store the results in a data frame called "cells" for each open field trial
  cells_all <- data.frame(mouse=rs@animalName, session=rs@session, cell.id=cg@id[st.s1@cellList-1],tetrode.id=cg@tetrode[st.s1@cellList-1],region=cg@brainRegion[st.s1@cellList-1],
                          clu.to.tet=cg@cluToTetrode[st.s1@cellList-1], protocol=protocol, MFR=st@meanFiringRate[st.s1@cellList-1],
                          z.score1_tr,z.score1_tl, z.score1_br,z.score1_bl, 
                          z.score2_tr,z.score2_tl, z.score2_br,z.score2_bl,
                          z.score3_tr,z.score3_tl, z.score3_br,z.score3_bl,
                          z.score4_tr,z.score4_tl, z.score4_br,z.score4_bl, 
                          z.score5_tr,z.score5_tl, z.score5_br,z.score5_bl)
  print(sp.s1@nShufflings)
  
  #calculate shuffled z scores
  zsh1 <- getZscoreShuffle_2obj(rs, sp.s1,st.s1, pt.s1, cg)
  zsh2 <- getZscoreShuffle_2obj(rs, sp.s2,st.s2, pt.s2, cg)
  zsh3 <- getZscoreShuffle_2obj(rs, sp.s3,st.s3, pt.s3, cg)
  zsh4 <- getZscoreShuffle_2obj(rs, sp.s4,st.s4, pt.s4, cg)
  zsh5 <- getZscoreShuffle_2obj(rs, sp.s5,st.s5, pt.s5, cg)
  
  shuff.zscore1_bl <- vector(length = length(st.s1@cellList))
  shuff.zscore2_bl<- vector(length = length(st.s1@cellList))
  shuff.zscore3_bl <- vector(length = length(st.s1@cellList))
  shuff.zscore4_bl <- vector(length = length(st.s1@cellList))
  shuff.zscore5_bl <- vector(length = length(st.s1@cellList))
  shuff.zscore1_br <- vector(length = length(st.s1@cellList))
  shuff.zscore2_br<- vector(length = length(st.s1@cellList))
  shuff.zscore3_br <- vector(length = length(st.s1@cellList))
  shuff.zscore4_br <- vector(length = length(st.s1@cellList))
  shuff.zscore5_br <- vector(length = length(st.s1@cellList))
  shuff.zscore1_tl <- vector(length = length(st.s1@cellList))
  shuff.zscore2_tl<- vector(length = length(st.s1@cellList))
  shuff.zscore3_tl <- vector(length = length(st.s1@cellList))
  shuff.zscore4_tl <- vector(length = length(st.s1@cellList))
  shuff.zscore5_tl <- vector(length = length(st.s1@cellList))
  shuff.zscore1_tr <- vector(length = length(st.s1@cellList))
  shuff.zscore2_tr<- vector(length = length(st.s1@cellList))
  shuff.zscore3_tr <- vector(length = length(st.s1@cellList))
  shuff.zscore4_tr <- vector(length = length(st.s1@cellList))
  shuff.zscore5_tr <- vector(length = length(st.s1@cellList))
  
  for (cell in st.s1@cellList){
    print("99th threshold...")
    # #z score 95th perc
    shuff.zscore1_bl[cell-1] <-  as.numeric(quantile(zsh1[[1]][,cell-1],0.95,na.rm=T))
    shuff.zscore2_bl[cell-1] <-  as.numeric(quantile(zsh2[[1]][,cell-1],0.95,na.rm=T))
    shuff.zscore3_bl[cell-1] <-  as.numeric(quantile(zsh3[[1]][,cell-1],0.95,na.rm=T))
    shuff.zscore4_bl[cell-1] <-  as.numeric(quantile(zsh4[[1]][,cell-1],0.95,na.rm=T))
    shuff.zscore5_bl[cell-1] <-  as.numeric(quantile(zsh5[[1]][,cell-1],0.95,na.rm=T))
    
    # #z score 95th perc
    shuff.zscore1_br[cell-1] <-  as.numeric(quantile(zsh1[[3]][,cell-1],0.95,na.rm=T))
    shuff.zscore2_br[cell-1] <-  as.numeric(quantile(zsh2[[3]][,cell-1],0.95,na.rm=T))
    shuff.zscore3_br[cell-1] <-  as.numeric(quantile(zsh3[[3]][,cell-1],0.95,na.rm=T))
    shuff.zscore4_br[cell-1] <-  as.numeric(quantile(zsh4[[3]][,cell-1],0.95,na.rm=T))
    shuff.zscore5_br[cell-1] <-  as.numeric(quantile(zsh5[[3]][,cell-1],0.95,na.rm=T))
    
    # #z score 95th perc
    shuff.zscore1_tl[cell-1] <-  as.numeric(quantile(zsh1[[5]][,cell-1],0.95,na.rm=T))
    shuff.zscore2_tl[cell-1] <-  as.numeric(quantile(zsh2[[5]][,cell-1],0.95,na.rm=T))
    shuff.zscore3_tl[cell-1] <-  as.numeric(quantile(zsh3[[5]][,cell-1],0.95,na.rm=T))
    shuff.zscore4_tl[cell-1] <-  as.numeric(quantile(zsh4[[5]][,cell-1],0.95,na.rm=T))
    shuff.zscore5_tl[cell-1] <-  as.numeric(quantile(zsh5[[5]][,cell-1],0.95,na.rm=T))
    
    # #z score 95th perc
    shuff.zscore1_tr[cell-1] <-  as.numeric(quantile(zsh1[[7]][,cell-1],0.95,na.rm=T))
    shuff.zscore2_tr[cell-1] <-  as.numeric(quantile(zsh2[[7]][,cell-1],0.95,na.rm=T))
    shuff.zscore3_tr[cell-1] <-  as.numeric(quantile(zsh3[[7]][,cell-1],0.95,na.rm=T))
    shuff.zscore4_tr[cell-1] <-  as.numeric(quantile(zsh4[[7]][,cell-1],0.95,na.rm=T))
    shuff.zscore5_tr[cell-1] <-  as.numeric(quantile(zsh5[[7]][,cell-1],0.95,na.rm=T))
  }
  cells_all <- cbind(cells_all, shuff.zscore1_bl, shuff.zscore1_br,shuff.zscore1_tl,shuff.zscore1_tr,
                     shuff.zscore2_bl, shuff.zscore2_br,shuff.zscore2_tl,shuff.zscore2_tr,
                     shuff.zscore3_bl, shuff.zscore3_br,shuff.zscore3_tl,shuff.zscore3_tr,
                     shuff.zscore4_bl, shuff.zscore4_br,shuff.zscore4_tl,shuff.zscore4_tr,
                     shuff.zscore5_bl, shuff.zscore5_br,shuff.zscore5_tl,shuff.zscore5_tr)
  
  results <-list(zscore=cells_all)
  names(results) <- c("zscore")
  return(results)
}

runOnSessionList(ep3,sessionList=rss3, fnct=zscorestats_5OF2object, save=T,overwrite=T) 
runOnSessionList(ep4,sessionList=rss4, fnct=zscorestats_5OF2object, save=T,overwrite=T) 

load(paste(ep3@resultsDirectory,"zscore",sep="/"))
zscore1 <- zscore
write.csv(zscore, "/home/isabel/Desktop/zscoresLEC_2objectv.csv")

load(paste(ep4@resultsDirectory,"zscore",sep="/"))
zscore2 <- zscore
write.csv(zscore, "/home/isabel/Desktop/zscoresLEC_2objecth.csv")

## add results to summary table
cells_all1 <- read.csv(file="~/LEC_remapping/results/cells_allLEC_2objectv_wv.csv", header = T)
cells_all2 <- read.csv(file="~/LEC_remapping/results/cells_allLEC_2objecth_wv.csv", header = T)

levels(zscore1$cid) <- levels(cells_all1$cell.id)
cells_all1[,colnames(zscore1)[9:length(zscore1[1,])]] <- NA
for (c in 1:length(zscore1$cell.id)){
  cells_all[which(cells_all$cell.id==zscore1$cell.id[c]),colnames(zscore1)[9:length(zscore1[1,])]] <- zscore1[c,colnames(zscore1)[9:length(zscore1[1,])]]
}
write.csv(cells_all1, file = "~/LEC_remapping/results/cells_allLEC_2objectv_wz.csv", row.names = F)

levels(zscore2$cid) <- levels(cells_all2$cell.id)
cells_all2[,colnames(zscore2)[9:length(zscore2[1,])]] <- NA
for (c in 1:length(zscore2$cell.id)){
  cells_all[which(cells_all$cell.id==zscore2$cell.id[c]),colnames(zscore2)[9:length(zscore2[1,])]] <- zscore2[c,colnames(zscore2)[9:length(zscore2[1,])]]
}
write.csv(cells_all2, file = "~/LEC_remapping/results/cells_allLEC_2objecth_wz.csv", row.names = F)
