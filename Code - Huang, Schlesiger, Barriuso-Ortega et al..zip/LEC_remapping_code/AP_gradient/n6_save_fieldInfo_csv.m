%% Load data tables
load '~/LEC_remapping/results/table_fieldInfo_AP.mat'
LEC_full = res_table;
clear 'res_table'

LEC_tmp = LEC_full;

n_cell = size(LEC_tmp,1);
for c = 1:n_cell
    if LEC_tmp(c).MFR_S1>5. || LEC_tmp(c).MFR_S1<0.1 || LEC_tmp(c).MFR_S2>5. || LEC_tmp(c).MFR_S2<0.1
        LEC_tmp(c).fieldInfo1{1,1} = [];
    elseif LEC_tmp(c).spikeasymmetrys1>0.1 || LEC_tmp(c).troughtopeakdurations1<0.4
        LEC_tmp(c).fieldInfo1{1,1} = [];
    end
end

%% create a table 
aa_fieldInfo =  cell(n_cell,14);

for idx2 = 1:n_cell  
   aa_fieldInfo{idx2,1} = LEC_tmp(idx2).fieldInfo1;
   aa_fieldInfo{idx2,2} = mat2str(LEC_tmp(idx2).Mouse_number);
   aa_fieldInfo{idx2,3} = string(LEC_tmp(idx2).session);
   aa_fieldInfo{idx2,4} = string(LEC_tmp(idx2).cid);

   if ~isempty(LEC_tmp(idx2).fieldInfo1) && size(LEC_tmp(idx2).fieldInfo1{1,1},2)>0 
        aa_fieldInfo{idx2,5} = size(LEC_tmp(idx2).fieldInfo1{1,1},2);
   else
        aa_fieldInfo{idx2,5} = 0;
   end
   aa_fieldInfo{idx2,6} = string(LEC_tmp(idx2).region);

end 



T_aa = aa_fieldInfo;

names = {'a1_fieldInfo', 'mouse', 'session','cid', 'nFields1', 'region'};

T_aa = cell2struct(T_aa',names);

T_aa = struct2table(T_aa);


nFields1 = T_aa.nFields1(T_aa.nFields>0);
mouse = string(T_aa.mouse(T_aa.nFields>0));
region = string(T_aa.region(T_aa.nFields>0));
cid = string(T_aa.cid(T_aa.nFields>0));
fielddiff = struct('cid', cid,'nFields1',nFields1, 'mouse', mouse,'region', region);


%save as csv
tosave = struct2table(fielddiff);
writetable(tosave,'~/LEC_remapping/results/fieldInfo_AP.csv')