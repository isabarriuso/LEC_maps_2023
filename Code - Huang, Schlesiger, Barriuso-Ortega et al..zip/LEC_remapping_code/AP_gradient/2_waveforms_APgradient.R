library(relectro)

ep1<-new("ElectroProject",directory="/data/projects/APgradient_isa/")
ep1<-setSessionList(ep1)
save(ep1,file=paste(ep1@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep1@resultsDirectory,"ep",sep="/"))
rss1<-getSessionList(ep1,clustered=T)
rss1<-sortRecSessionListChronologically(rss1)
sesslist <- sessionNamesFromSessionList(rss1)


source('~/source_scripts/meanwaveform_int.R')
source("~/source_scripts/Positrack.R")


################## get waveforms ###############
wfs.s1=list()
cell_ids=vector()

for (i in 1:length(rss1)) {
  rs=rss1[[i]]
  print(i)
  print(rs@session)
  
  #Get RecSession objects
  myList<-getRecSessionObjects(rs)
  st<-myList$st
  cg<-myList$cg
  df<-myList$df
  sw<-new("SpikeWaveform",session=rs@session)
  
  st.s1 <- setIntervals(st, rs@trialStartRes[1], rs@trialEndRes[1]) #1st open field trial
  
  sw@wfMsPerBin<-.01
  
  #remove cells without spikes in that trial
  for (clu in 1:length(cg@id)){
    if (length(which(st.s1@res[which(st.s1@clu==clu+1)] >= st.s1@startInterval & st.s1@res[which(st.s1@clu==clu+1)] <= st.s1@endInterval)==T)<2){
      print(paste("removing clu:", cg@id[clu], sep=" "))
      st.s1 <- setCellList(st.s1, cellList = st.s1@cellList[which(st.s1@cellList!=clu+1)])
      cg@id <- cg@id[-clu]
      cg@clu <- cg@clu[-clu]
    }
  }
  
  #calculate waveforms of all cells
  sw.s1<-meanWaveform_int(sw,rs,st.s1,cg,df,filter=T)
  ###
  
  for(clu in cg@id){
    wf.s1<-sw.s1@wf[,sw.s1@wfCluId==clu]
    wfs.s1[[length(wfs.s1)+1]]<-wf.s1
    #cell ids
    cell_ids[length(cell_ids)+1]<-clu
  }
  
  ## save part already in case of crash
  save(wfs.s1,file=paste(ep1@resultsDirectory, "waveforms/Waveforms_part.Rdata", sep = "/"))
  save(cell_ids,file=paste(ep1@resultsDirectory, "waveforms/cell_id_waveforms_part.Rdata", sep = "/"))
  
  rm(rs, st, cg, df, sw, myList)
  rm(st.s1, sw.s1, wf.s1)
  
}

##output: saves list with all wf as Waveforms.Rdata
save(wfs.s1,file=paste(ep1@resultsDirectory, "waveforms/Waveforms_all.Rdata", sep = "/"))
save(cell_ids,file=paste(ep1@resultsDirectory, "waveforms/cell_id_waveforms_all.Rdata", sep = "/"))


####### spike waveform properties ######

#load(paste(ep1@resultsDirectory, "waveforms/Waveforms_all.Rdata", sep = "/"))
#load(paste(ep1@resultsDirectory, "/waveforms/cell_id_waveforms_all.Rdata", sep = ""))
cells <- cell_ids
wfs <- wfs.s1

find_peaks <- function (x, m = 3){
  shape <- diff(sign(diff(x, na.pad = FALSE)))
  pks <- sapply(which(shape < 0), FUN = function(i){
    z <- i - m + 1
    z <- ifelse(z > 0, z, 1)
    w <- i + m + 1
    w <- ifelse(w < length(x), w, length(x))
    if(all(x[c(z : i, (i + 2) : w)] <= x[i + 1])) return(i + 1) else return(numeric(0))
  })
  pks <- unlist(pks)
  pks
}

# identify channel with largest spike waveform deflection 
wf.all=sapply(wfs, function(x){x[,which.min(apply(x, 2, min))]})

# trough-to-peak duration and peak amplitude asymmetry
ttp.duration=c()
ptt.duration=c()
ptp.duration=c()
sasym=c()
spike.max1.time = c()
spike.max2.time = c()
spike.min.time = c()
spike.max1.voltage = c()
spike.max2.voltage = c()
spike.min.voltage = c()
wf.all.s1=c()
tt=seq(-1.475,1.475,.05) ### == sw@wfTimePoints
time=seq(-1,1,0.01)

for (ii in 1:length(wf.all[1,])) {
  y0=approx(x=tt,y=wf.all[,ii],xout = time)
  voltage=smooth.spline(y0$y,spar=.3)$y
  
  # detect spike time (around 0 ms), and second peak in spike waveform
  spike_min=which.min(voltage)
  spike_max2=find_peaks(voltage[spike_min:length(time)])[1]+spike_min-1
  # detect first peak in spike waveform
  n1=((length(time)-1)/4)
  spike_max1=tail(find_peaks(voltage[n1:spike_min]),n=1)+(n1-1)
  # if no clear first peak take saddle point
  if(length(spike_max1)==0){
    spike_max1 = tail(which(diff(diff(voltage[n1:spike_min]))>0),n=1)+(n1-1)
  }
  
  # calculate peak amplitude asymmetry
  a = voltage[spike_max1]
  b = voltage[spike_max2]  
  sasym_before <- length(sasym)
  sasym=c(sasym,(b-a)/(abs(b)+abs(a)))
  sasym_after <- length(sasym)
  
  ####if no second peak is found: NA
  if(sasym_after - sasym_before != 1){
    print(paste("Problem with", ii, sep = " "))
    sasym=c(sasym,NA)
    ttp.duration=c(ttp.duration,NA)
    ptt.duration=c(ptt.duration,NA)
    ptp.duration=c(ptp.duration,NA)
    wf.all.s1=rbind(wf.all.s1,voltage)
    spike.max1.time=c(spike.max1.time,NA)
    spike.max2.time=c(spike.max2.time,NA)
    spike.min.time=c(spike.min.time,NA)
    spike.max1.voltage=c(spike.max1.voltage,NA)
    spike.max2.voltage=c(spike.max2.voltage,NA)
    spike.min.voltage=c(spike.min.voltage,NA)
    } else{
    # calculate trough-to-peak duration + more
    ttp.duration =c(ttp.duration,time[spike_max2]-time[spike_min])
    ptt.duration = c(ptt.duration, time[spike_min]-time[spike_max1])
    ptp.duration = c(ptp.duration, time[spike_max2]- time[spike_max1])
    wf.all.s1=rbind(wf.all.s1,voltage)
    
    #collect all values
    spike.max1.time = c(spike.max1.time,time[spike_max1])
    spike.max2.time = c(spike.max2.time,time[spike_max2])
    spike.min.time  = c(spike.min.time, time[spike_min])
    spike.max1.voltage = c(spike.max1.voltage,voltage[spike_max1])
    spike.max2.voltage = c(spike.max2.voltage, voltage[spike_max2])
    spike.min.voltage = c(spike.min.voltage, voltage[spike_min])
  }
}
waveform.data.s1 <- data.frame(cell.id = cells[1:length(wf.all[1,])], trough.to.peak.duration.s1 =ttp.duration,
                                 peak.to.trough.duration.s1=ptt.duration, peak.to.peak.duration.s1=ptp.duration,
                                 spike.asymmetry.s1 = sasym,spike.max1.time.s1 = spike.max1.time,spike.max2.time.s1 = spike.max2.time,
                                 spike.min.time.s1 = spike.min.time, spike.max1.voltage.s1 = spike.max1.voltage,
                                 spike.max2.voltage.s1 = spike.max2.voltage, spike.min.voltage.s1 = spike.min.voltage)

save(file=paste(ep1@resultsDirectory,"Waveform.stats.RData",sep="/"),time,wf.all.s1,waveform.data.s1)
write.csv(waveform.data.s1, file=paste(ep1@resultsDirectory,"Waveform.stats.csv",sep="/"))

rm(wf.all, wf.all.s1, wfs, wfs.s1, y0, a, b, ptp.duration, ptt.duration, ttp.duration, sasym, sasym_after, sasym_before, 
   spike_max1, spike_max2, spike_min, spike.max1.time, spike.max1.voltage, spike.max2.time, spike.max2.voltage,
   spike.min.time, spike.min.voltage, time, tt, voltage)

# add spike waveform to summary table
cells_all <- read.csv("~/LEC_remapping/results/AP_gradient_stats.csv", header = T)
#load(file=paste(ep1@resultsDirectory,"Waveform.stats.RData",sep="/"))

waveform.data.s1$cell.id <- factor(waveform.data.s1$cell.id, levels = levels(cells_all$cell.id))
cells_all[,names(waveform.data.s1)[-1]] <- NA
for (cid in 1:length(waveform.data.s1$cell.id)){
  print(cid)
  for (param in names(waveform.data.s1)[-1]){
    cells_all[which(cells_all$cell.id==waveform.data.s1$cell.id[cid]), param] <- waveform.data.s1[cid, param]
  }
}

write.csv(cells_all, file="~/LEC_remapping/results/AP_gradient_with_SW.csv", row.names = F)
