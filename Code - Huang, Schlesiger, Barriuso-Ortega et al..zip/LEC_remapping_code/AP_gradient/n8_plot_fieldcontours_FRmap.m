load('~/LEC_remapping/results/table_fieldInfo_AP.mat', 'res_table')
load('~/LEC_remapping/results/fieldInfo.mat')
load('~/LEC_remapping/results/alldata.mat', "spikeData_1")

ratemaps1 = reshape({spikeData_1.maps}, size(spikeData_1,1),size(spikeData_1,2),size(spikeData_1,3));
mapSize=36;

datadir = '~/LEC_remapping/results/APgradient_sop/';
files = dir(datadir);
filenames = {files.name}.';
sop_files = unique(filenames(contains(filenames, "_1.sop_phase_laser")));% _1.sop_phase_laser for Xu's data
sop_files_div = split(sop_files,'_');
session_names = {sop_files_div{:,1}};

h = figure;
idx = 1;
nrow= 8;
ncol= 5; 
for ss=1:size(ratemaps1,1)
    for kk=1:size(ratemaps1,3)
        for cid=1:size(ratemaps1,2)
            if ~isempty(ratemaps1{ss,cid,kk})
                cell_id = strcat(session_names{ss},'_',num2str(spikeData1(ss,cid,kk).CellID));
                region = res_table(find(strcmp([res_table.cellid], cell_id))).region;

                % trial 1
                subplot(nrow,ncol,idx)
                imagesc(ratemaps1{ss,cid,kk});hold on;
                colormap jet;
                title(strcat(session_names{ss},' cell ',num2str(spikeData(ss,cid,kk).CellID),string(region)))
                if ~isempty(fieldInfo1{ss,cid,kk})
                n_fields = length(fieldInfo1{ss,cid});
                for f = 1:n_fields
                    fieldBounds = ((fieldInfo1{ss,cid}(f).fieldBounds.boundary)*mapSize/2)+((mapSize+1)/2);
                    plot(fieldBounds(1,:),fieldBounds(2,:),'w','LineWidth',1)
                    com = rescale(fieldInfo1{ss,cid}(f).center,0.,35.,'InputMin',-35.,'InputMax',35.);
                    plot(com(1),com(2),'r+', 'MarkerSize',5, 'LineWidth',1)
                end
                end
                idx = idx+1;

                if idx>nrow*ncol
                    idx = 1;
                    set(h,'PaperUnits','inches','PaperPosition',[0 0 8.5 11],'PaperSize',[8.5 11])
                    print('-dpsc2', '~/LEC_remapping/results/FRplots_LECAP.pdf','-append')
                    clf;
                end
            end
        end
    end
end
set(h,'PaperUnits','inches','PaperPosition',[0 0 8.5 11],'PaperSize',[8.5 11])
print('-dpsc2', '~/LEC_remapping/results/FRplots_LECAP.pdf','-append')
clf;

close(h)