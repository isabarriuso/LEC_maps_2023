library(ggplot2)
library(scales)
library(ggpubr)
library(FSA)

res_dir <-'~/LEC_remapping/results/'

################### load datasets ##################################
cells_all <- read.csv(paste(res_dir,"AP_gradient_with_SW.csv", sep=""), header = T)
## field analysis
fieldinfo <- read.csv(paste(res_dir,'fieldInfo_AP.csv', sep = ""))
cells_all$nFields1 <- NA
for (i in 1:length(fieldinfo$cid)){
  cells_all$nFields1[which(cells_all$cell.id==fieldinfo$cid[i])] <- fieldinfo$nFields1[i]
}

#filter by firing rate ans spike waveform
cells_all_f <- cells_all[which((cells_all$MFR_S1>0.1 & cells_all$MFR_S2>0.1 & cells_all$MFR_S1<5 & cells_all$MFR_S2<5 &
                                 cells_all$trough.to.peak.duration.s1>0.4 & cells_all$spike.asymmetry.s1<0.1)),]

ggplot(cells_all_f, mapping = aes(x=region, y=IS_S1))+
  #facet_wrap(.~Mouse_number)+ #Figure S1 plots
  ylim(c(0,0.8))+
  scale_color_manual(values=c('#AA510e', '#E6890F','#F4AE52'))+
  geom_point(aes(color=region),position = position_jitterdodge(jitter.width = 0.5), size=0.5)+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

ggplot(cells_all_f, mapping = aes(x=region, y=nFields1))+
  scale_y_continuous(breaks=seq(0,25,2))+
  scale_color_manual(values=c('#AA510e', '#E6890F','#F4AE52'))+
  geom_point(aes(color=region),position = position_jitterdodge(jitter.width = 0.8), size=0.5)+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())
