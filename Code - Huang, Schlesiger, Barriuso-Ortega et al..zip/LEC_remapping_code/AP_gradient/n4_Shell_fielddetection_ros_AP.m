%% load all files from a directory
datadir = '~/LEC_remapping/results/APgradient_sop/';
savedir ='~/LEC_remapping/results/';

files = dir(datadir);
filenames = {files.name}.';
sop_files = unique(filenames(contains(filenames, "_1.sop_phase_laser")));

%% load parameter values
params = loadParamsRdx();
params.delimeterThresh = 0.333; 
params.searchIncrement = 0.1;
params.ac_bin_width = 0.004;
params.n_ac_bins = 200;
params.sampRate = 20;
params.binWidth = 2;
params.nbins= 72;
sLength = params.binWidth * params.nbins;
params.gridAxis = 0:params.gridWidth:(sLength/2-params.gridWidth/2);
params.mapAxis = 0:params.binWidth:(sLength/2-params.binWidth/2);
params.offset = 0; 
params.xRange = [-36 36];
params.yRange = [-36 36];
params.alphaValue = 10000;
params.shape = 1; 
params.useAdaptiveMap=0;
params.binSize=2;
params.binSizeInterp=2;
params.mapSize = 36;
params.bins = 36;
params.mapSizeInterp=params.mapSize*5;
params.minRunSpeed = 3;

%% create structures to load the data
indata = struct([]); 
spikeData_1 = struct(); 
cellData = struct(); 
fieldData = struct(); 

for sess=1:size(sop_files,1)
    session = strsplit(string(sop_files(sess)),"_");
    session = session{1};
    
    sop_file = strcat(datadir,session,  '_1.sop_phase_laser');
    sop_data1 = importsopfile(sop_file);
    xypath_file = strcat(datadir,session,  '_1.xyPath');
    readxyFile;
    xy_data1 = xy_data;
    clearvars xy_data
    
    samplingRate = 20000.;
    
    indata_1(sess).x = xy_data1.xPath;
    indata_1(sess).y = xy_data1.yPath;
    indata_1(sess).t = xy_data1.tPath/samplingRate;
    indata_1(sess).angle = nan(size(indata_1(sess).t));
    indata_1(sess).v = nan(size(indata_1(sess).t));
    indata_1(sess) = addVelocityToIndata(indata_1(sess)); %calculate velocity at each res value
    
    
    cellList = unique(sop_data1.cluSpike);
    
    for cid=1:length(cellList)
        spikeData_1(sess,cid,:).CellID = cellList(cid);
        spikeData_1(sess,cid,:).session = session;
        spikeData_1(sess,cid,:).tSp = sop_data1.tSpike(sop_data1.cluSpike==cellList(cid))/samplingRate;
        spikeData_1(sess,cid,:).xSp = sop_data1.xSpike(sop_data1.cluSpike==cellList(cid));
        spikeData_1(sess,cid,:).ySp= sop_data1.ySpike(sop_data1.cluSpike==cellList(cid));
        spikeData_1(sess,cid,:).pSp = nan(size(spikeData_1(sess,cid,:).tSp));
        spikeData_1(sess,cid,:).nSp = length(spikeData_1(sess,cid,:).tSp);
        spikeData_1(sess,cid,:).vSp = interp1(indata_1(sess).t, indata_1(sess).v, spikeData_1(sess,cid,:).tSp);
        spikeData_1(sess,cid,:).fSp= [0;1./diff(spikeData_1(sess,cid,:).tSp)];
        spikeData_1(sess,cid,:).IFR = nan(size(spikeData_1(sess,cid,:).tSp));
    end
    
    %% calculate rate maps
    if ~isempty(cellList)
        for  cid=1:length([spikeData_1(sess,:,:).CellID])
            if ~isempty([spikeData_1(sess,cid,:).tSp])
                %trial1
                cellData_1(sess).(strcat('cell',string(spikeData_1(sess,cid,:).CellID))) = calculateCellData_speedfilter(indata_1(sess).x, indata_1(sess).y, indata_1(sess).t, indata_1(sess).v, indata_1(sess).angle, spikeData_1(sess,cid,1).tSp,spikeData_1(sess,cid,1).xSp,spikeData_1(sess,cid,1).ySp,spikeData_1(sess,cid,1).vSp,[],[],[], params, savedir);
                spikeData_1(sess,cid,1).maps = cellData_1(sess).(strcat('cell',string(spikeData_1(sess,cid,1).CellID))).map;
                spikeData_1(sess,cid,1).spkmaps = cellData_1(sess).(strcat('cell',string(spikeData_1(sess,cid,1).CellID))).spikeMap;
                spikeData_1(sess,cid,1).timemaps = cellData_1(sess).(strcat('cell',string(spikeData_1(sess,cid,1).CellID))).timeMap;
            end
        end
    else
        continue
    end
    
        
end

ratemaps1 = reshape({spikeData_1.maps}, size(spikeData_1,1),size(spikeData_1,2),size(spikeData_1,3));
spkmaps1 = reshape({spikeData_1.spkmaps}, size(spikeData_1,1),size(spikeData_1,2),size(spikeData_1,3));
timemaps1 = reshape({spikeData_1.timemaps}, size(spikeData_1,1),size(spikeData_1,2),size(spikeData_1,3));

%% find fields
params.lowestFieldRate=1.5;
params.fieldThreshold=0.1;
params.minNumBins=10;
fieldData1 = generateFieldDataC(ratemaps1, params);
fieldInfo1 = generateFieldInfo(ratemaps1, spkmaps1, timemaps1, fieldData1, params);

%%save variables as .mat files 
save('~/LEC_remapping/results/fieldInfo_AP.mat','fieldInfo1')

save('~/LEC_remapping/results/alldata_AP.mat', 'indata','spikeData_1','fieldData1')
