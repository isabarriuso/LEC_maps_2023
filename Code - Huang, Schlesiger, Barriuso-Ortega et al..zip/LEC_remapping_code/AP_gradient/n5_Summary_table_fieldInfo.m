% load fieldInfo1
load('~/LEC_remapping/results/fieldInfo_AP.mat')

%load summary table
T_all = importfile_AP('~/LEC_remapping/results/AP_gradient_with_SW.csv');

%% load session names in the same order as for calculating the field stats
datadir = '~/LEC_remapping/results/APgradient_sop/';
files = dir(datadir);
filenames = {files.name}.';
sop_files = unique(filenames(contains(filenames, "_1.sop_phase_laser")));
sop_files_div = split(sop_files,'_');
session_names = {sop_files_div{:,1}};

T_toselect = split(T_all.cellid, "_"); 
res_table = struct("fieldInfo1",cell(size(T_toselect,1),1), "cid",cell(size(T_toselect,1),1));
for n=1:size(T_toselect,1) 
    cell_n = str2double(T_toselect{n,2})-1;
    sess_n = find(strcmp(session_names, T_toselect{n,1})); 
    disp(strcat(string(sess_n), "_",string(cell_n))) 
    res_table(n,1).fieldInfo1 = fieldInfo1(sess_n,cell_n);
    res_table(n,1).cid = strcat(T_toselect{n,1},"_",T_toselect{n,2});
end

 f = fieldnames(T_all);
 for j = 1:size(T_all,1) 
     for i = 1:(length(f)-3) 
        res_table(j,1).(f{i}) = T_all.(f{i})(j);
     end 
 end

%% save as mat file
save('~/LEC_remapping/results/table_fieldInfo_AP.mat', 'res_table')