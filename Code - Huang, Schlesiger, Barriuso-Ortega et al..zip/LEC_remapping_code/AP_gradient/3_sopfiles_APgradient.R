library(snow)
library(relectro)
library(scales)

workers<-c(rep("localhost",3))
cl<-makeCluster(workers, type = "SOCK",outfile="")
print(paste("Using",length(workers), "threads"))
clusterEvalQ(cl,library(relectro))

ep1<-new("ElectroProject",directory="/data/projects/APgradient_isa/") 
ep1<-setSessionList(ep1)
save(ep1,file=paste(ep1@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep1@resultsDirectory,"ep",sep="/"))
rss1<-getSessionList(ep1,clustered=T)
rss1<-sortRecSessionListChronologically(rss1)

spikeOnPathRes <- function(rs, env="session", shamstim="session", trial_n=NA){
  print(rs@session)
  #get sop_res function
  source('~/source_scripts/sop_respath.R')
  source('~/source_scripts/Positrack.R')
  library(scales)
  
  myList <- getRecSessionObjects(rs)
  cg <- myList$cg
  hd <- myList$hd
  pt <- myList$pt
  st <- myList$st
  sp <- myList$sp
  
  ############## make coordinates match between trials and go from 0,70 (cm)
  int_55 <- getIntervalsEnvironment(rs, environment = "sqr70") #get sampling times of each trial (column 1=start, column 2= stop, nrows= nTrials)
  pt_55 <- setInvalidOutsideInterval(pt, s=int_55) #select tracking data
  for (t in 1:nrow(int_55)){
    #get x and y values of trial number t (of the OF trials in room 55)
    x <- pt_55@x[which(pt_55@res > int_55[t,1] & pt_55@res < int_55[t,2])]
    y <- pt_55@y[which(pt_55@res > int_55[t,1] & pt_55@res < int_55[t,2])]
    xWhl <- pt_55@xWhl[which(pt_55@res > int_55[t,1] & pt_55@res < int_55[t,2])]
    yWhl <- pt_55@yWhl[which(pt_55@res > int_55[t,1] & pt_55@res < int_55[t,2])]
    # Set the scale that you want in the final pt object
    # We know that the open field is 70x70cm so we rescale x and y coordinate to (0,70), and xWhl and yWhl coordinates to (0,700) -provided that pxPerCm=10)
    pt@x[which((pt@res > int_55[t,1] & pt@res < int_55[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=range(x, na.rm = T)) #you need to exclude the NA values, otherwise the range detected will be NA
    pt@y[which((pt@res > int_55[t,1] & pt@res < int_55[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=range(y, na.rm = T)) #same here
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_55[t,1] & pt@res < int_55[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=range(xWhl[which(xWhl>=0)], na.rm = T)) #you need to exclude the -1 (invalid) values, otherwise the minimum range value will be -1
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_55[t,1] & pt@res < int_55[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=range(yWhl[which(yWhl>=0)], na.rm = T)) #same here
  }
  #If you also want to rescale the rest box trials, use the range from one the OF trials to appropriately do so.
  int_55 <- getIntervalsEnvironment(rs, environment = 'hc') #get sampling times of each trial (column 1=start, column 2= stop, nrows= nTrials)
  pt_55 <- setInvalidOutsideInterval(pt, s=int_55) #select tracking data
  x_save <- range(x, na.rm = T)
  y_save <- range(y, na.rm = T)
  xw_save <- range(xWhl[which(xWhl>=0)], na.rm = T)
  yw_save <- range(yWhl[which(yWhl>=0)], na.rm = T)
  for (t in 1:nrow(int_55)){
    #get x and y values of trial number t 
    x <- pt_55@x[which(pt_55@res > int_55[t,1] & pt_55@res < int_55[t,2])]
    y <- pt_55@y[which(pt_55@res > int_55[t,1] & pt_55@res < int_55[t,2])]
    xWhl <- pt_55@xWhl[which(pt_55@res > int_55[t,1] & pt_55@res < int_55[t,2])]
    yWhl <- pt_55@yWhl[which(pt_55@res > int_55[t,1] & pt_55@res < int_55[t,2])]
    # Set the scale that you want in the final pt object
    # We know that the open field is 70x70cm so we rescale x and y coordinate to (0,70), and xWhl and yWhl coordinates to (0,700) -provided that pxPerCm=10)
    pt@x[which((pt@res > int_55[t,1] & pt@res < int_55[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=x_save)
    pt@y[which((pt@res > int_55[t,1] & pt@res < int_55[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=y_save)
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_55[t,1] & pt@res < int_55[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=xw_save) #you need to exclude the -1 (invalid) values, otherwise the minimum range value will be -1
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_55[t,1] & pt@res < int_55[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=yw_save) #same here
  }
  rm(x, y, yWhl, xWhl, pt_55, int_55) #free some memory
  
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  pt@speed[which(pt@speed==(-1.0))] <- NA
  
  print("Selecting res values for specified environment and stimulation trials...")
  if ((env!="session")==TRUE){   ## Type "session" to run for whole session and sqr70 otherwise
    #get pt and st objects for the interval needed
    pt <- setInvalidOutsideInterval(pt,s=getIntervalsEnvironment(rs,environment=env))
    st <- setIntervals(st,s=getIntervalsEnvironment(rs, environment=env))
  }
  if (isTRUE(is.numeric(trial_n))){
    print(rs@trialStartRes[trial_n])
    print(rs@trialEndRes[trial_n])
    pt <- setInvalidOutsideInterval(pt,s=rs@trialStartRes[trial_n], e=rs@trialEndRes[trial_n])
    st <- setIntervals(st,s=rs@trialStartRes[trial_n], e=rs@trialEndRes[trial_n])
  }
  #create data frame with the sop data with the res values of the desired trial
  print("creating sop_res file...")
  sop_res <- spikeOnPath_res(sp, st, pt)
  
  
  #store the results in files readable outside of R
  write.csv(as.data.frame(sop_res[1:3]), file = paste("~/LEC_remapping/results/APgradient_sop/",rs@session,"_",trial_n,".xyPath", sep = ""))
  write.csv(as.data.frame(sop_res[4:length(sop_res)]), file=paste("~/LEC_remapping/results/APgradient_sop/",rs@session,"_",trial_n,".sop_phase_laser", sep = ""))
  return(result=sop_res)
}

#1st OF trial
runOnSessionList(ep1,sessionList=rss1, fnct=spikeOnPathRes, save=T,overwrite=T, 
                 env="session", shamstim="session", trial_n=1, parallel = T, cluster = cl) 
#2nd OF trial
runOnSessionList(ep1,sessionList=rss1, fnct=spikeOnPathRes,save=T,overwrite=T, 
                 env="session",  shamstim="session", trial_n=3, parallel = T, cluster= cl)

stopCluster(cl) # stop the cluster when we are done
rm(cl,workers)
