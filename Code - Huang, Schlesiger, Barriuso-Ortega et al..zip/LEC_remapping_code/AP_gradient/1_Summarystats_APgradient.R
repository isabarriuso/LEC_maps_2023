library(relectro)
library(scales)


ep1<-new("ElectroProject",directory="/data/projects/APgradient/")
ep1<-setSessionList(ep1)
save(ep1,file=paste(ep1@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep1@resultsDirectory,"ep",sep="/"))
rss1<-getSessionList(ep1,clustered=T)
rss1<-sortRecSessionListChronologically(rss1)

source('~/source_scripts/MapCorrShuffle.R')
source('~/source_scripts/Positrack.R')

All_Statistics<-function(rs){
  print(rs@session)
  myList<-getRecSessionObjects(rs)
  st<-myList$st
  pt<-myList$pt
  cg<-myList$cg
  sp<-myList$sp
  hd<-myList$hd
  
  #make coordinates match between the trials and go from 0,70 (cm)
  if(any(rs@environment=='sqr70')){
    pt_positrack <- setInvalidOutsideInterval(pt, s=getIntervalsEnvironment(rs, environment = "sqr70"))
    int_posi <- getIntervalsEnvironment(rs, environment = "sqr70")
    pt_posib <- pt_positrack
    for (interval in 1:length(int_posi[,1])){
      pt_posib@x <- pt_positrack@x[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
      pt_posib@y <- pt_positrack@y[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
      pt_posib@xWhl <- pt_positrack@xWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
      pt_posib@yWhl <- pt_positrack@yWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
      #set the same scale in the trk files as in the positrack files
      pt@x[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@x))] <- rescale(pt_posib@x[!is.na(pt_posib@x)], to = c(0,70), from=range(pt_posib@x, na.rm = T))
      pt@y[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@y))] <- rescale(pt_posib@y[!is.na(pt_posib@y)], to = c(0,70), from=range(pt_posib@y, na.rm = T))
      pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@xWhl[which(pt_posib@xWhl>=0)], to = c(0, 700), from=range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T))
      pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@yWhl[which(pt_posib@yWhl>=0)], to = c(0, 700), from=range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T))
    }
    rm(pt_positrack, pt_posib, int_posi)
  }
  #re-calculate speed
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  pt@speed[which(pt@speed==(-1.0))] <- NA
  
  intervals<-getIntervalsEnvironment(rs,environment = "sqr70")
  ptsqr70.1<-setInvalidOutsideInterval(pt,s=getIntervalsEnvironment(rs,env="sqr70")[1,1],e=getIntervalsEnvironment(rs,env="sqr70")[1,2])
  ptsqr70.1<-speedFilter(ptsqr70.1,minSpeed=3,maxSpeed = 80)
  
  ptsqr70.2<-setInvalidOutsideInterval(pt,s=getIntervalsEnvironment(rs,env="sqr70")[2,1],e=getIntervalsEnvironment(rs,env="sqr70")[2,2])
  ptsqr70.2<-speedFilter(ptsqr70.2,minSpeed=3,maxSpeed = 80)

  ## st
  stsqr70.1<-setIntervals(st=st,s=intervals[1,1],e=intervals[1,2])
  stsqr70.2<-setIntervals(st=st,s=intervals[2,1],e=intervals[2,2])
  
  #### Export MeanFiringRate 
  st<-meanFiringRate(st)
  stsqr70.1<-meanFiringRate(stsqr70.1)
  stsqr70.2<-meanFiringRate(stsqr70.2)
  
  MFR <- st@meanFiringRate
  MFR_S1 <- stsqr70.1@meanFiringRate
  MFR_S2 <- stsqr70.2@meanFiringRate
  
  #### Export cluster isolation distance and refractory ratio
  cluIso <- clusterIsolationCheck(rs)
  clu_stats <- cluIso$cluster.check
  
  ############################
  sp@cmPerBin=2
  sp<-getMapStats(sp,st,pt)
  spsqr70.1<-getMapStats(sp,stsqr70.1,ptsqr70.1)
  spsqr70.2<-getMapStats(sp,stsqr70.2,ptsqr70.2)
  
  #### Export PeakFiringRate
  PFR <- sp@peakRate
  PFR_S1 <- spsqr70.1@peakRate
  PFR_S2 <- spsqr70.2@peakRate
  
  #### Export InformationScore
  sp<-getMapStats(sp,st,pt)
  IS <- sp@infoScore
  IS_S1 <- spsqr70.1@infoScore
  IS_S2 <- spsqr70.2@infoScore

  ####### Map stability
  pt<-speedFilter(pt,minSpeed = 3,maxSpeed = 80)
  sp<-firingRateMap2d(sp,st,pt)
  spsqr70.1<-firingRateMap2d(sp,stsqr70.1,ptsqr70.1,nRowMap = 38,nColMap = 38)
  spsqr70.2<-firingRateMap2d(sp,stsqr70.2,ptsqr70.2, nRowMap = 38,nColMap = 38)
  MS_S12<-firingRateMapCorrelation(spsqr70.1,spsqr70.2)
  
  ######### Map stability within each trial (1st "1/2 part" to 2nd "1/2 part")
  #trial 1
  s1s <- getIntervalsEnvironment(rs,env="sqr70")[1,1]
  e1e <- getIntervalsEnvironment(rs,env="sqr70")[1,2]
  ptsqr70.1a<-setInvalidOutsideInterval(pt,s=s1s, e=round(e1e/2))
  ptsqr70.1a<-speedFilter(ptsqr70.1a,minSpeed=3,maxSpeed = 80)
  ptsqr70.1b<-setInvalidOutsideInterval(pt,s=round(e1e/2)+1, e=e1e)
  ptsqr70.1b<-speedFilter(ptsqr70.1b,minSpeed=3,maxSpeed = 80)
  stsqr70.1a<-setIntervals(st=st,s=s1s,e=round(e1e/2))
  stsqr70.1b<-setIntervals(st=st,s=round(e1e/2)+1,e=e1e)
  spsqr70.1a<-firingRateMap2d(sp,stsqr70.1a,ptsqr70.1a, nRowMap = 38,nColMap = 38)
  spsqr70.1b<-firingRateMap2d(sp,stsqr70.1b,ptsqr70.1b, nRowMap = 38,nColMap = 38)
  
  MS_S1ab<-firingRateMapCorrelation(spsqr70.1a,spsqr70.1b)
  
  #trial 2
  s2s <- getIntervalsEnvironment(rs,env="sqr70")[2,1]
  e2e <- getIntervalsEnvironment(rs,env="sqr70")[2,2]
  ptsqr70.2a<-setInvalidOutsideInterval(pt,s=s2s, e=s2s+round((e2e-s2s)/2))
  ptsqr70.2a<-speedFilter(ptsqr70.2a,minSpeed=3,maxSpeed = 80)
  ptsqr70.2b<-setInvalidOutsideInterval(pt,s=s2s+round((e2e-s2s)/2)+1, e=e2e)
  ptsqr70.2b<-speedFilter(ptsqr70.2b,minSpeed=3,maxSpeed = 80)
  stsqr70.2a<-setIntervals(st=st,s=s2s,e=s2s+round((e2e-s2s)/2))
  stsqr70.2b<-setIntervals(st=st,s=s2s+round((e2e-s2s)/2)+1,e=e2e)
  spsqr70.2a<-firingRateMap2d(sp,stsqr70.2a,ptsqr70.2a, nRowMap = 38,nColMap = 38)
  spsqr70.2b<-firingRateMap2d(sp,stsqr70.2b,ptsqr70.2b, nRowMap = 38,nColMap = 38)
  
  MS_S2ab<-firingRateMapCorrelation(spsqr70.2a,spsqr70.2b)
  
  #shuffling of information score trial 1
  ptsqr70.1<-setInvalidOutsideInterval(pt,s=getIntervalsEnvironment(rs,env="sqr70")[1,1],e=getIntervalsEnvironment(rs,env="sqr70")[1,2])
  stsqr70.1<-setIntervals(st=st,s=intervals[1,1],e=intervals[1,2])
  sp@nShufflings<-100 
  sp<-getMapStatsShuffle(sp,stsqr70.1,pt)
  shuf_1 <- sp@infoScoreShuffle
  All_shuf <- data.frame(matrix(shuf_1,nrow= length(stsqr70.1@cellList),ncol = 100,byrow = FALSE), row.names = stsqr70.1@cellList)
  j <- c(1:length(stsqr70.1@cellList))
  Threshold95_IS_S1<-c()
  for (index in j) {
    statThreshold<-quantile(All_shuf[index,],probs = 0.95)
    Threshold95_IS_S1[index]<-as.numeric(statThreshold)
  }
  
  #shuffling of information score trial 1
  ptsqr70.2<-setInvalidOutsideInterval(pt,s=getIntervalsEnvironment(rs,env="sqr70")[2,1], e=getIntervalsEnvironment(rs,env="sqr70")[2,2])
  stsqr70.2<-setIntervals(st=st,s=intervals[2,1],e=intervals[2,2])
  sp@nShufflings<-100
  sp<-getMapStatsShuffle(sp,stsqr70.2,pt)
  shuf <- sp@infoScoreShuffle
  All_shuf <- data.frame(matrix(shuf,nrow= length(stsqr70.2@cellList),ncol = 100,byrow = FALSE), row.names = stsqr70.2@cellList)
  j <- c(1:length(stsqr70.2@cellList))
  Threshold95_IS_S2<-c()
  for (index in j) {
    statThreshold<-quantile(All_shuf[index,],probs = 0.95)
    Threshold95_IS_S2[index]<-as.numeric(statThreshold)
  }
  
  #################### map correlation shuffle
  Threshold95_MS_S1ab <- c()
  Threshold95_MS_S2ab <- c()
  Threshold95_MS_S12 <- c()
  
  MS_S11sh <- getMapCorrShuffle(spsqr70.1a,stsqr70.1a,ptsqr70.1a, spsqr70.1b, stsqr70.1b,ptsqr70.1b)
  MS_S22sh <- getMapCorrShuffle(spsqr70.2a,stsqr70.2a,ptsqr70.2a, spsqr70.2b,stsqr70.2b,ptsqr70.2b)
  MS_S12sh <- getMapCorrShuffle(spsqr70.1,stsqr70.1,ptsqr70.1, spsqr70.2,stsqr70.2,ptsqr70.2)
  
  for (cell in stsqr70.1@cellList){
    print("99th threshold...")
    Threshold95_MS_S1ab[cell-1] <- as.numeric(quantile(MS_S11sh[,cell-1],0.95,na.rm=T))
    Threshold95_MS_S2ab[cell-1] <- as.numeric(quantile(MS_S22sh[,cell-1],0.95,na.rm=T))
    Threshold95_MS_S12[cell-1] <- as.numeric(quantile(MS_S12sh[,cell-1],0.95,na.rm=T))
  }
  ######################## General information of the session    #################
  cell.id=cg@id[st@cellList-1]
  tetrode.id=cg@tetrode[st@cellList-1]
  region=cg@brainRegion[st@cellList-1]
  clu.to.tet=cg@cluToTetrode[st@cellList-1]
  Mouse_number=rs@animalName
  Mouse_line="WT"
  session = rs@session
  
  
  All_Sta_with_id <- data.frame(Mouse_number,session,Mouse_line,cell.id,tetrode.id,clu.to.tet,
                                region,MFR,MFR_S1,MFR_S2, IS,IS_S1,IS_S2,
                                MS_S12,MS_S1ab,MS_S2ab,isolationDistance=clu_stats$isolationDistance, refractoryRatio = clu_stats$refractoryRatio,
                                Threshold95,Threshold95_IS_S1, Threshold95_IS_S2, Threshold95_MS_S1ab,Threshold95_MS_S2ab)
  
  ## return all the sta 
  return(list(stats_APgradient=stats_APgradient))
  
  
}

runOnSessionList(ep1,
                 sessionList=rss1, # write the correct n
                 fnct=All_Statistics,
                 save=T,overwrite=T)


load(paste(ep1@resultsDirectory,"stats_APgradient",sep="/"))
write.csv(All_Sta_with_id, file="~/LEC_remapping/results/AP_gradient_stats.csv")
