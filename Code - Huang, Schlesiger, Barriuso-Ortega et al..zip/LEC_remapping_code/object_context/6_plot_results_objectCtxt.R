library(ggplot2)
library(ggridges)
library(scales)
library(ggpubr)

cells_all1 <- read.csv("~/LEC_remapping/results/cells_allLEC_object_wz.csv", header = T)
cells_all1$paradigm <- "object_LEC"
cells_all2 <- read.csv("~/LEC_remapping/results/cells_allCA1_object_wz.csv", header = T)
cells_all1$paradigm <- "object_CA1"
cells_all <- rbind(cells_all1,cells_all2)

fieldCA1 <- read.csv('~/LEC_remapping/results/fieldInfo_CA1.csv', header = T)
fieldLEC <- read.csv('~/LEC_remapping/results/fieldInfo_LEC.csv', header = T)

field_all <- rbind(fieldCA1, fieldLEC)

levels(field_all$cid) <- levels(cells_all$cell.id)
cells_all[,colnames(field_all)[5:9]] <- NA
for (c in 1:length(field_all$cid)){
  cells_all[which(cells_all$cell.id==field_all$cid[c]),colnames(field_all)[5:9]] <- field_all[c,colnames(field_all)[5:9]]
}


cells_all$shuff.MS_sCdO <- NA
cells_all$shuff.MS_dCsO <- NA
cells_all$shuff.MS_sCsO <- NA
cells_all$shuff.MS_sCdOC <- NA
cells_all$MFR_dCsO <- NA
cells_all$MFR_sCdO <- NA
cells_all$MFR_sCdOC <- NA
cells_all$MFR_sCsO <- NA
# add across and within shuff map stability depending on the protocol
for (i in 1:length(cells_all$cell.id)){
  if (cells_all$protocol[i]=="aabba"){
    cells_all$shuff.MS_sCdO[i] <-cells_all$shuff.MS_S12[i]
    cells_all$shuff.MS_dCsO[i] <-cells_all$shuff.MS_S23[i]
    cells_all$shuff.MS_sCsO[i] <-cells_all$shuff.MS_S34[i]
    cells_all$shuff.MS_dCdO[i] <-cells_all$shuff.MS_S45[i]
    cells_all$MFR_dCsO[i] <- (cells_all$MFR_S2[i]-cells_all$MFR_S3[i])/(cells_all$MFR_S2[i]+cells_all$MFR_S3[i])
    cells_all$MFR_dCdO[i] <- (cells_all$MFR_S4[i]-cells_all$MFR_S5[i])/(cells_all$MFR_S4[i]+cells_all$MFR_S5[i])
    cells_all$MFR_sCdO[i] <- (cells_all$MFR_S1[i]-cells_all$MFR_S2[i])/(cells_all$MFR_S1[i]+cells_all$MFR_S2[i])
    cells_all$MFR_sCsO[i] <- (cells_all$MFR_S3[i]-cells_all$MFR_S4[i])/(cells_all$MFR_S3[i]+cells_all$MFR_S4[i])
    cells_all$MFR_sCsO2[i] <- (cells_all$MFR_S1[i]-cells_all$MFR_S5[i])/(cells_all$MFR_S1[i]+cells_all$MFR_S5[i])
  }else if (cells_all$protocol[i]=="abbaa"){
    cells_all$shuff.MS_sCdO[i] <-cells_all$shuff.MS_S45[i]
    cells_all$shuff.MS_dCsO[i] <-cells_all$shuff.MS_S34[i]
    cells_all$shuff.MS_sCsO[i] <-cells_all$shuff.MS_S23[i]
    cells_all$shuff.MS_dCdO[i] <-cells_all$shuff.MS_S12[i]
    cells_all$MFR_dCdO[i] <- (cells_all$MFR_S1[i]-cells_all$MFR_S2[i])/(cells_all$MFR_S1[i]+cells_all$MFR_S2[i])
    cells_all$MFR_dCsO[i] <-(cells_all$MFR_S3[i]-cells_all$MFR_S4[i])/(cells_all$MFR_S3[i]+cells_all$MFR_S4[i])
    cells_all$MFR_sCsO[i] <- (cells_all$MFR_S2[i]-cells_all$MFR_S3[i])/(cells_all$MFR_S2[i]+cells_all$MFR_S3[i])
    cells_all$MFR_sCdO[i] <-  (cells_all$MFR_S4[i]-cells_all$MFR_S5[i])/(cells_all$MFR_S4[i]+cells_all$MFR_S5[i])
    cells_all$MFR_sCsO2[i] <- (cells_all$MFR_S1[i]-cells_all$MFR_S5[i])/(cells_all$MFR_S1[i]+cells_all$MFR_S5[i])
  }
}


############## excitatory neurons
cells_all_f <- cells_all[which(cells_all$MFR_S1>0.1 & cells_all$MFR_S2>0.1 & cells_all$MFR_S3>0.1 & cells_all$MFR_S4>0.1 &
                                 cells_all$MFR_S5> 0.1 & cells_all$MFR_S1<5 & cells_all$MFR_S2<5 & cells_all$MFR_S3<5 & cells_all$MFR_S4<5 &
                                 cells_all$MFR_S5<5 & (cells_all$trough.to.peak.duration>0.4 & cells_all$spike.asymmetry<0.1)),]
#############
#spatial
cells_all_f$spatial <- "other"
cells_all_f$spatial[which(cells_all_f$protocol=='aabba' & ((cells_all_f$IS_S1sh < cells_all_f$IS_S1 & cells_all_f$IS_S5sh < cells_all_f$IS_S5 & cells_all_f$shuff.MS_S11 < cells_all_f$MS_S11 & cells_all_f$shuff.MS_S55 < cells_all_f$MS_S55) |
                                                             (cells_all_f$IS_S4sh < cells_all_f$IS_S4 & cells_all_f$IS_S3sh < cells_all_f$IS_S3 & cells_all_f$shuff.MS_S44 < cells_all_f$MS_S44 & cells_all_f$shuff.MS_S33 < cells_all_f$MS_S33)))] <- "spatial"
cells_all_f$spatial[which(cells_all_f$protocol=='abbaa' & ((cells_all_f$IS_S2sh < cells_all_f$IS_S2 & cells_all_f$IS_S3sh < cells_all_f$IS_S3 & cells_all_f$shuff.MS_S22 < cells_all_f$MS_S22 & cells_all_f$shuff.MS_S33 < cells_all_f$MS_S33) |
                                                             (cells_all_f$IS_S1sh < cells_all_f$IS_S1 & cells_all_f$IS_S5sh < cells_all_f$IS_S5 & cells_all_f$shuff.MS_S11 < cells_all_f$MS_S11 & cells_all_f$shuff.MS_S55 < cells_all_f$MS_S55)))] <- "spatial"
#get object cells
cells_all_f$class <- "other"
cells_all_f$class[which(cells_all_f$protocol=="aabba" & (cells_all_f$z.score1>cells_all_f$shuff.zscore1 & cells_all_f$z.score2>cells_all_f$shuff.zscore2 & cells_all_f$z.score5>cells_all_f$shuff.zscore5))]<- "object-in-context-black"
cells_all_f$class[which(cells_all_f$protocol=="abbaa" & (cells_all_f$z.score1>cells_all_f$shuff.zscore1 & cells_all_f$z.score4>cells_all_f$shuff.zscore4 & cells_all_f$z.score5>cells_all_f$shuff.zscore5))]<- "object-in-context-black"
cells_all_f$class[which(cells_all_f$protocol=="aabba" & (cells_all_f$z.score1>cells_all_f$shuff.zscore1 & cells_all_f$z.score2>cells_all_f$shuff.zscore2 & cells_all_f$z.score3>cells_all_f$shuff.zscore3))] <-"object-cell"
cells_all_f$class[which(cells_all_f$protocol=="abbaa" & (cells_all_f$z.score3>cells_all_f$shuff.zscore3 & cells_all_f$z.score4>cells_all_f$shuff.zscore4 & cells_all_f$z.score5>cells_all_f$shuff.zscore5))] <-"object-cell"

library(stringr)
library(dplyr)
plot_data <- cells_all_f %>% 
  group_by(paradigm, class) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = "", y = percent, fill=class)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 1),'%', sep="")), position = position_stack(vjust=0.5), color="white") +
  coord_polar(theta="y",start = 0, direction = 1)+
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_void() + 
  facet_grid(.~paradigm)+
  scale_fill_manual(values = c('#74d2c2', '#F4AE52','black'))

###### only for spatial neurons
cells_all_ctx <- cells_all_f[which(cells_all_f$spatial=="spatial" & cells_all_f$class=="other"),]
cells_all_ctx$disc_group <- "unstable"
cells_all_ctx$disc_group[which((cells_all_ctx$sCsO>0.4 |cells_all_ctx$MS_S15>0.4))] <- "stable"
cells_all_ctx$disc_group[which(cells_all_ctx$class=="stable"& cells_all_ctx$dCsO<0.4)]<-"discriminating"

library(stringr)
library(dplyr)
plot_data <- cells_all_ctx %>% 
  group_by(paradigm, disc_group) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = "", y = percent, fill=disc_group)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 0),'%', sep="")), position = position_stack(vjust=0.5), color="black") +
  coord_polar(theta="y",start = 0, direction = 1)+
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_void() + 
  facet_grid(paradigm~.)+  
  scale_fill_manual(values = c('#B1B1B1','#16301B',"#A2D5D9", '#ff7f11', '#FFB370', '#A21632'))#+

#per mouse
library(stringr)
library(dplyr)
plot_data <- cells_all_ctx %>% 
  group_by(paradigm, mouse, disc_group) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = "", y = percent, fill=disc_group)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 0),'%', sep="")), position = position_stack(vjust=0.5), color="black") +
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_void() + 
  facet_grid(paradigm~mouse)+  
  scale_fill_manual(values = c('#B1B1B1','#16301B',"#A2D5D9", '#ff7f11', '#FFB370', '#A21632'))#+

#map stability
toplot_f <- rbind(cells_all_ctx[,1:(length(cells_all_ctx))],cells_all_ctx[,1:(length(cells_all_ctx))],cells_all_ctx[,1:(length(cells_all_ctx))],cells_all_ctx[,1:(length(cells_all_ctx))],cells_all_ctx[,1:(length(cells_all_ctx))])
toplot_f$Stability <- c(cells_all_ctx$sCsO, cells_all_ctx$sCdO, cells_all_ctx$dCsO, cells_all_ctx$dCdO, cells_all_ctx$MS_S15)
toplot_f$disc_group <- c(cells_all_ctx$disc_group, cells_all_ctx$disc_group, cells_all_ctx$disc_group, cells_all_ctx$disc_group, cells_all_ctx$disc_group, cells_all_ctx$disc_group)
toplot_f$stab_group <- c(rep('sCsO', length(cells_all_ctx$cell.id)), rep('sCdO', length(cells_all_ctx$cell.id)), rep('dCsO', length(cells_all_ctx$cell.id)), rep('dCdO', length(cells_all_ctx$cell.id)), rep('sCsO2', length(cells_all_ctx$cell.id)))
toplot_f$stab_group <- factor(toplot_f$stab_group, levels = c("sCsO", "sCdO", "dCsO","dCdO", "sCsO2"))
toplot_f$rate_change <- c(abs(cells_all_ctx$MFR_sCsO), abs(cells_all_ctx$MFR_sCdO), abs(cells_all_ctx$MFR_dCsO), abs(cells_all_ctx$MFR_dCdO), abs(cells_all_ctx$MFR_sCsO2))

ggplot(toplot_f[which(toplot_f$disc_group=="discriminating"),], mapping = aes(x=stab_group, y=Stability))+
  geom_point(aes(color=region), position = position_jitterdodge(jitter.width = 1.1), size=0.5)+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+
  facet_wrap(.~paradigm)+#facet_wrap(.~mouse)+
  scale_color_manual(values=c('#F4AE52','#50a1d9'))+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  theme_classic2()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), axis.text.y = element_text(angle = 45))

ggplot(cells_all_ctx[which(cells_all_ctx$disc_group=="discriminating"),], mapping = aes(x=region, y=sCsO-sCdO))+
  geom_point(aes(color=region), position = position_jitterdodge(jitter.width = 1.1), size=0.5)+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+
  scale_color_manual(values=c('#F4AE52','#50a1d9'))+
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

### remapping to the object location
cells_all_ctx$remap_object <- "stable"
cells_all_ctx$remap_object[which(cells_all_ctx$sCdO<0.75*cells_all_ctx$sCsO & cells_all_ctx$sCdO<0.75*cells_all_ctx$MS_S15)] <- "object-location-remapping"

library(stringr)
library(dplyr)
plot_data <- cells_all_ctx[which(cells_all_ctx$disc_group=="discriminating"),] %>% 
  group_by(paradigm, remap_object) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = "", y = percent, fill=remap_object)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = n), position = position_stack(vjust=0.5), color="white") +
  coord_polar(theta="y",start = 0, direction = 1)+
  theme_void() + 
  facet_grid(paradigm~.)+
  scale_fill_manual(values = c('green', 'black'))


######## field analysis
#distribution center of mass fields
ggplot(field_all[which(field_all$cid %in% cells_all_ctx$cell.id[which(cells_all_ctx$disc_group=="discriminating")]),], mapping = aes(x=center_largest_x, y=center_largest_y, color=paradigm))+ #largest field size
  geom_point()+
  theme_classic2()

#### according to position of the largest field
cells_all_ctx$field_position <- "away-object"
cells_all_ctx$field_position[which(cells_all_ctx$center_largest_x<17.5 & cells_all_ctx$center_largest_y<17.5)] <- "near-object" #matlab flipped coordinates in y-axis

library(stringr)
library(dplyr)
plot_data <- cells_all_ctx[which(cells_all_ctx$disc_group=="discriminating" & (cells_all_ctx$paradigm=="object_LEC"|cells_all_ctx$paradigm=="object_CA1")),] %>% 
  group_by(paradigm, field_position, remap_object) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = "", y = percent, fill=remap_object)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = n), position = position_stack(vjust=0.5), color="white") +
  theme_void() + 
  facet_grid(paradigm~field_position)+
  scale_fill_manual(values = c('#74d2c2', '#F4AE52'))

##### calculate euclidean distance
#object center in bin coordinates: 8.625 x 8.625 (17.25 cm x 17.25 cm)
object_x <- 8.625
object_y <- 8.625
object_location <- c(object_x, object_y)

euclidean <- function(a, b) sqrt(sum((a - b)^2))

cells_all_ctx$eu.dist_largest <- NA

for (i in 1:length(cells_all_ctx$cell.id)){
  com_largest <- c(cells_all_ctx$center_largest_x[i],cells_all_ctx$center_largest_y[i])
  cells_all_ctx$eu.dist_largest[i]<- euclidean(com_largest, object_location)
}

ggplot(cells_all_ctx[which(cells_all_ctx$disc_group=="discriminating" & (cells_all_ctx$paradigm=="object_LEC"|cells_all_ctx$paradigm=="object_CA1")),], mapping=aes(x=paradigm, y=eu.dist_largest))+
  stat_compare_means(method = "wilcox.test", paired = F)+
  geom_point(aes(color=paradigm), position = position_jitterdodge(jitter.width = 0.4))+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+
  scale_color_manual(values = c("#51A0D9", "#F2AE51"))+
  theme_classic2()
