%% load all files from a directory
datadir = '~/LEC_remapping/results/sop_object/LEC_object/'; %change accordingly
savedir ='~/LEC_remapping/results/'; %where the resulting variables will be

files = dir(datadir);
filenames = {files.name}.';
sop_files = unique(filenames(contains(filenames, "_2.sop_phase_laser")));

%% load parameter values
params = loadParamsRdx();
params.delimeterThresh = 0.333; % To get ~2 theta cycles (~200-333 ms for a theta freq 6-10 Hz)
params.searchIncrement = 0.1;
params.nbins= 72;
sLength = params.binWidth * params.nbins;
params.gridAxis = 0:params.gridWidth:(sLength/2-params.gridWidth/2);
params.mapAxis = 0:params.binWidth:(sLength/2-params.binWidth/2);
params.offset = 0; 
params.xRange = [-36 36];
params.yRange = [-36 36];
params.alphaValue = 10000;
params.useAdaptiveMap=0;
params.binSize=2;
params.binSizeInterp=2;
params.mapSize = 36;
params.bins = 36;
params.mapSizeInterp=params.mapSize*5;
params.minRunSpeed = 3;

indata = struct([]);
spikeData_1 = struct();
cellData = struct(); 
fieldData = struct();

for sess=1:size(sop_files,1)
    session = strsplit(string(sop_files(sess)),"_");
    session = session{1};
    
    %get sop file for the 1st trial
    sop_file = strcat(datadir,session,  '_2.sop_phase_laser');
    sop_data1 = importsopfile(sop_file); 
    xypath_file = strcat(datadir,session,  '_2.xyPath');
    readxyFile; 
    xy_data1 = xy_data;
    clearvars xy_data
    
    samplingRate = 20000.;
    
    indata_1(sess).x = xy_data1.xPath;
    indata_1(sess).y = xy_data1.yPath;
    indata_1(sess).t = xy_data1.tPath/samplingRate;
    indata_1(sess).angle = nan(size(indata_1(sess).t));
    indata_1(sess).v = nan(size(indata_1(sess).t));
    indata_1(sess) = addVelocityToIndata(indata_1(sess));
    
    cellList = unique(sop_data1.cluSpike); 
    
    for cid=1:length(cellList)
        spikeData_1(sess,cid,:).CellID = cellList(cid);
        spikeData_1(sess,cid,:).session = session;
        spikeData_1(sess,cid,:).tSp = sop_data1.tSpike(sop_data1.cluSpike==cellList(cid))/samplingRate;
        spikeData_1(sess,cid,:).xSp = sop_data1.xSpike(sop_data1.cluSpike==cellList(cid));
        spikeData_1(sess,cid,:).ySp= sop_data1.ySpike(sop_data1.cluSpike==cellList(cid));
        spikeData_1(sess,cid,:).pSp = nan(size(spikeData_1(sess,cid,:).tSp));
        spikeData_1(sess,cid,:).nSp = length(spikeData_1(sess,cid,:).tSp);
        spikeData_1(sess,cid,:).vSp = interp1(indata_1(sess).t, indata_1(sess).v, spikeData_1(sess,cid,:).tSp);
        spikeData_1(sess,cid,:).fSp= [0;1./diff(spikeData_1(sess,cid,:).tSp)];
        spikeData_1(sess,cid,:).IFR = nan(size(spikeData_1(sess,cid,:).tSp)); 
    end

    if ~isempty(cellList)
        for  cid=1:length([spikeData_1(sess,:,:).CellID])
            if ~isempty([spikeData_1(sess,cid,:).tSp])
                %trial1
                cellData_1(sess).(strcat('cell',string(spikeData_1(sess,cid,:).CellID))) = calculateCellData_speedfilter(indata_1(sess).x, indata_1(sess).y, indata_1(sess).t, indata_1(sess).v, indata_1(sess).angle, spikeData_1(sess,cid,1).tSp,spikeData_1(sess,cid,1).xSp,spikeData_1(sess,cid,1).ySp,spikeData_1(sess,cid,1).vSp,[],[],[], params, savedir);
                spikeData_1(sess,cid,1).maps = cellData_1(sess).(strcat('cell',string(spikeData_1(sess,cid,1).CellID))).map;
                spikeData_1(sess,cid,1).spkmaps = cellData_1(sess).(strcat('cell',string(spikeData_1(sess,cid,1).CellID))).spikeMap;
                spikeData_1(sess,cid,1).timemaps = cellData_1(sess).(strcat('cell',string(spikeData_1(sess,cid,1).CellID))).timeMap;
            end
        end
    else
        continue
    end
    
        
end

ratemaps1 = reshape({spikeData_1.maps}, size(spikeData_1,1),size(spikeData_1,2),size(spikeData_1,3));
spkmaps1 = reshape({spikeData_1.spkmaps}, size(spikeData_1,1),size(spikeData_1,2),size(spikeData_1,3));
timemaps1 = reshape({spikeData_1.timemaps}, size(spikeData_1,1),size(spikeData_1,2),size(spikeData_1,3));

%% find fields
params.lowestFieldRate=1.5;
params.fieldThreshold=0.1;
params.minNumBins=10;
fieldData1 = generateFieldDataC(ratemaps1, params);
fieldInfo1 = generateFieldInfo(ratemaps1, spkmaps1, timemaps1, fieldData1, params);


%%save variables as .mat files 
save('~/LEC_remapping/results/LEC_object/fieldInfo.mat','fieldInfo1')
save('~/LEC_remapping/results/LEC_object/alldata.mat', 'indata_1', 'spikeData_1','fieldData1')

%clear all

% load fieldInfo1
load('~/LEC_remapping/results/LEC_object/fieldInfo.mat')

%load summary table
T_all = readtable("~/LEC_remapping/results/cells_allLEC_object_wz.csv");

files = dir(datadir);
filenames = {files.name}.';
sop_files = unique(filenames(contains(filenames, "_2.sop_phase_laser")));% 
sop_files_div = split(sop_files,'_');
session_names = {sop_files_div{:,1}};

T_toselect = split(T_all.cell_id, "_"); %get session in col 1 and cell id in col2
res_table = struct("fieldInfo1",cell(size(T_toselect,1),1), "cid",cell(size(T_toselect,1),1));
for n=1:size(T_toselect,1)
    cell_n = str2double(T_toselect{n,2})-1;
    sess_n = find(strcmp(session_names, T_toselect{n,1})); %get index in session_cb for that session
    disp(strcat(string(sess_n), "_",string(cell_n))) 
    res_table(n,1).fieldInfo1 = fieldInfo1(sess_n,cell_n);
    res_table(n,1).cid = strcat(T_toselect{n,1},"_",T_toselect{n,2});
end

%add values from the summary table
 f = fieldnames(T_all);
 for j = 1:size(T_all,1) %loop over cells in sum table
     for i = 1:(length(f)-3) %loop over fields in sum table (last 3 are not in table: 'Properties', 'Row','Variables')
        res_table(j,1).(f{i}) = T_all.(f{i})(j); %add value for said cell and field
     end 
 end

%% save as mat file
save('~/LEC_remapping/results/LEC_object/table_fieldInfo.mat', 'res_table')

%% % save as a csv file

%% Load data tables
lec_object = res_table;

n_cell = size(lec_object,1);
%% filter out interneurons
for c = 1:n_cell
    if lec_object(c).MFR_S1>5. || lec_object(c).MFR_S1<0.1 || lec_object(c).MFR_S2>5. || lec_object(c).MFR_S2<0.1
        lec_object(c).fieldInfo1{1,1} = [];
    elseif lec_object(c).spike_asymmetry>0.1 || lec_object(c).trough_to_peak_duration<0.4
        lec_object(c).fieldInfo1{1,1} = [];
    end
end

%% create a table 
aa_fieldInfo =  cell(n_cell,10);

for idx2 = 1:n_cell  
   aa_fieldInfo{idx2,1} = lec_object(idx2).fieldInfo1;
   aa_fieldInfo{idx2,2} = string(lec_object(idx2).mouse);
   aa_fieldInfo{idx2,3} = string(lec_object(idx2).session);
   aa_fieldInfo{idx2,4} = string(lec_object(idx2).cid);
   aa_fieldInfo{idx2,5} = string(lec_object(idx2).region);

   if ~isempty(lec_object(idx2).fieldInfo1) && size(lec_object(idx2).fieldInfo1{1,1},2)>0 
        aa_fieldInfo{idx2,6} = size(lec_object(idx2).fieldInfo1{1,1},2);
        [Max1, MaxIn1] = max([lec_object(idx2).fieldInfo1{1,1}.fieldSize]);
        aa_fieldInfo{idx2,7} = lec_object(idx2).fieldInfo1{1,1}(MaxIn1).fieldSize;
        aa_fieldInfo{idx2,8} = lec_object(idx2).fieldInfo1{1,1}(MaxIn1).center;
        aa_fieldInfo{idx2,8} = rescale(aa_fieldInfo{idx2,10},0.,35.,'InputMin',-35.,'InputMax',35.);
        aa_fieldInfo{idx2,9} = aa_fieldInfo{idx2,10}(1);
        aa_fieldInfo{idx2,10} = aa_fieldInfo{idx2,10}(2);
   else
        aa_fieldInfo{idx2,6} = 0;
        aa_fieldInfo{idx2,7} = 0;
        aa_fieldInfo{idx2,8} = 0;
   end
   

end 



T_aa = aa_fieldInfo;

names = {'a1_fieldInfo', 'mouse', 'session','cid', 'region', 'nFields1', 'FieldSizelargest','center_largest', 'center_largest_x', 'center_largest_y'};

T_aa = cell2struct(T_aa',names);

T_aa = struct2table(T_aa);

tosave = T_aa(T_aa.nFields1>0,2:10);

writetable(tosave,'~/LEC_remapping/results/fieldInfo_LEC.csv')