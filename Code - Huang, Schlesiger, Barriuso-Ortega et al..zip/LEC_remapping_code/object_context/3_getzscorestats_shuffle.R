library(relectro)
library(scales)

ep1<-new("ElectroProject",directory="/data/projects/LEC_context_object/")
ep1<-setSessionList(ep1)
save(ep1,file=paste(ep1@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep1@resultsDirectory,"ep",sep="/"))
rss1<-getSessionList(ep1,clustered=T)
rss1<-sortRecSessionListChronologically(rss1)

ep2<-new("ElectroProject",directory="/data/projects/CA1_context_object/")
ep2<-setSessionList(ep2)
save(ep2,file=paste(ep2@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep2@resultsDirectory,"ep",sep="/"))
rss2<-getSessionList(ep2,clustered=T)
rss2<-sortRecSessionListChronologically(rss2)


source('~/source_scripts/Positrack.R')
source("~/soource_scripts/getZscoreShuffle.R")

zscorestats_5OFobject <- function(rs){
  print(rs@session)
  ## load the data in R
  myList<-getRecSessionObjects(rs)
  st<-myList$st
  pt<-myList$pt
  cg<-myList$cg
  sp<-myList$sp
  
  #make coordinates match between the boxes and go from 0,70 (cm)
  pt_positrack <- setInvalidOutsideInterval(pt, s=rs@trialStartRes[c(2,4,6,8,10)], e=rs@trialEndRes[c(2,4,6,8,10)])
  int_posi <- data.frame(start=rs@trialStartRes[c(2,4,6,8,10)], end=rs@trialEndRes[c(2,4,6,8,10)])
  pt_posib <- pt_positrack
  for (interval in 1:length(int_posi[,1])){
    pt_posib@x <- pt_positrack@x[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@y <- pt_positrack@y[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@xWhl <- pt_positrack@xWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@yWhl <- pt_positrack@yWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt@x[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@x))] <- rescale(pt_posib@x[!is.na(pt_posib@x)], to = c(0,70), from=range(pt_posib@x, na.rm = T))
    pt@y[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@y))] <- rescale(pt_posib@y[!is.na(pt_posib@y)], to = c(0,70), from=range(pt_posib@y, na.rm = T))
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@xWhl[which(pt_posib@xWhl>=0)], to = c(0, 700), from=range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T))
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@yWhl[which(pt_posib@yWhl>=0)], to = c(0, 700), from=range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T))
  }
  #Rescale the rest box trials, use the range from one the OF trials to appropriately do so.
  int_hc <- data.frame(start=rs@trialStartRes[c(1,3,5,7,9,11)], end=rs@trialEndRes[c(1,3,5,7,9,11)])
  pt_hc <- setInvalidOutsideInterval(pt, s=int_hc[,1],e=int_hc[,2])
  x_save <- range(pt_posib@x, na.rm = T)
  y_save <- range(pt_posib@y, na.rm = T)
  xw_save <- range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T)
  yw_save <- range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T)
  for (t in 1:nrow(int_hc)){
    x <- pt_hc@x[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    y <- pt_hc@y[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    xWhl <- pt_hc@xWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    yWhl <- pt_hc@yWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    pt@x[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=x_save)
    pt@y[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=y_save)
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=xw_save)
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=yw_save)
  }
  rm(x, y, yWhl, xWhl, pt_hc, int_hc, int_posi, pt_posib, pt_positrack) #free some memory
  
  print(paste('min x_cm:', min(pt@x, na.rm = T),'; max x_cm:', max(pt@x, na.rm = T)))
  print(paste('min y_cm:', min(pt@y, na.rm = T),'; max y_cm:', max(pt@y, na.rm = T)))
  
  ### IMPORTANT: recalculate speed after rescaling ## 
  ## get the speed from position
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  pt@speed[which(pt@speed==(-1.0))] <- NA
  
  st <- meanFiringRate(st)
  # create st objects for each open field trial in the session
  st.s1 <- setIntervals(st, s=rs@trialStartRes[2], e=rs@trialEndRes[2])
  st.s2 <- setIntervals(st, s=rs@trialStartRes[4], e=rs@trialEndRes[4])
  st.s3 <- setIntervals(st, s=rs@trialStartRes[6], e=rs@trialEndRes[6])
  st.s4 <- setIntervals(st, s=rs@trialStartRes[8], e=rs@trialEndRes[8])
  st.s5 <- setIntervals(st, s=rs@trialStartRes[10], e=rs@trialEndRes[10])
  # create a positrack object for each open field trial in the session
  pt.s1<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[2], e=rs@trialEndRes[2])
  pt.s2<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[4], e=rs@trialEndRes[4])
  pt.s3<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[6], e=rs@trialEndRes[6])
  pt.s4<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[8], e=rs@trialEndRes[8])
  pt.s5<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[10], e=rs@trialEndRes[10])
  #filter by speed
  pt.s1<-speedFilter(pt.s1,minSpeed = 3,maxSpeed = 100)
  pt.s2<-speedFilter(pt.s2,minSpeed = 3,maxSpeed = 100)
  pt.s3<-speedFilter(pt.s3,minSpeed = 3,maxSpeed = 100)
  pt.s4<-speedFilter(pt.s4,minSpeed = 3,maxSpeed = 100)
  pt.s5<-speedFilter(pt.s5,minSpeed = 3,maxSpeed = 100)
  
  # Create firing rate maps for each cell of the list in each open field trial #
  sp.s1<-firingRateMap2d(sp,st.s1,pt.s1, nRowMap = 37, nColMap = 37)
  sp.s2<-firingRateMap2d(sp,st.s2,pt.s2, nRowMap = 37, nColMap = 37)
  sp.s3<-firingRateMap2d(sp,st.s3,pt.s3, nRowMap = 37, nColMap = 37)
  sp.s4<-firingRateMap2d(sp,st.s4,pt.s4, nRowMap = 37, nColMap = 37)
  sp.s5<-firingRateMap2d(sp,st.s5,pt.s5, nRowMap = 37, nColMap = 37)
  sp.s1@reduceSize <- F
  sp.s2@reduceSize <- F
  sp.s3@reduceSize <- F
  sp.s4@reduceSize <- F
  sp.s5@reduceSize <- F
  
  # rotate 180° those maps from the other room
  if(rs@environment[2]==rs@environment[4]){
    protocol <- 'aabba'
  }else if(rs@environment[2]==rs@environment[8]){
    protocol <- 'abbaa'
  }
  ### z score object ###
  #object zone boundaries for position 1 and 2
  map.df1 <- mapsAsDataFrame(sp.s1) 
  map.df1$rate[map.df1$rate == -1] <- NA
  map.df2 <- mapsAsDataFrame(sp.s2) 
  map.df2$rate[map.df2$rate == -1] <- NA
  map.df3 <- mapsAsDataFrame(sp.s3) 
  map.df3$rate[map.df3$rate == -1] <- NA
  map.df4 <- mapsAsDataFrame(sp.s4) 
  map.df4$rate[map.df4$rate == -1] <- NA
  map.df5 <- mapsAsDataFrame(sp.s5) 
  map.df5$rate[map.df5$rate == -1] <- NA
  #position 1
  xmin1<-7
  xmax1<-12
  ymin1<-26
  ymax1<-31
  #position 2
  xmin2<-27
  xmax2<-32
  ymin2<-7
  ymax2<-12
  
  #save object surrounding zones
  zone1 <- c(xmin1-2,xmax1+4,ymin1-4, ymax1+2)
  zone2 <- c(xmin2-4,xmax2+2,ymin2-2, ymax2+4)
  #if recording was in room 55, fr map is rotated 180° (i.e. zone1 is zone2 and viceversa)
  if(rs@animalName=="ib10079" | rs@animalName=="ib10220"){
    zone2 <- c(xmin1-2,xmax1+4,ymin1-4, ymax1+2)
    zone1 <- c(xmin2-4,xmax2+2,ymin2-2, ymax2+4)
  }
  
  #create maps of the object zone and no zone (the rest) for each trial
  map.zone1 <- map.df1[which(map.df1$x > zone1[1] & map.df1$x < zone1[2]  & map.df1$y > zone1[3] & map.df1$y < zone1[4]),]
  n.zone1 <- sum(!is.na(map.zone1$rate[map.zone1$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map.nozone1 <- map.df1[which(!(map.df1$x > zone1[1] & map.df1$x < zone1[2]  & map.df1$y > zone1[3] & map.df1$y < zone1[4])),]
  
  map.zone2 <- map.df2[which(map.df2$x > zone2[1] & map.df2$x < zone2[2]  & map.df2$y > zone2[3] & map.df2$y < zone2[4]),]
  n.zone2 <- sum(!is.na(map.zone2$rate[map.zone2$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map.nozone2 <- map.df2[which(!(map.df2$x > zone2[1] & map.df2$x < zone2[2]  & map.df2$y > zone2[3] & map.df2$y < zone2[4])),]
  
  map.zone3 <- map.df3[which(map.df3$x > zone2[1] & map.df3$x < zone2[2]  & map.df3$y > zone2[3] & map.df3$y < zone2[4]),]
  n.zone3 <- sum(!is.na(map.zone3$rate[map.zone3$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map.nozone3 <- map.df3[which(!(map.df3$x > zone2[1] & map.df3$x < zone2[2]  & map.df3$y > zone2[3] & map.df3$y < zone2[4])),]
  
  map.zone4 <- map.df4[which(map.df4$x > zone2[1] & map.df4$x < zone2[2]  & map.df4$y > zone2[3] & map.df4$y < zone2[4]),]
  n.zone4 <- sum(!is.na(map.zone4$rate[map.zone4$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map.nozone4 <- map.df4[which(!(map.df4$x > zone2[1] & map.df4$x < zone2[2]  & map.df4$y > zone2[3] & map.df4$y < zone2[4])),]
  
  map.zone5 <- map.df5[which(map.df5$x > zone1[1] & map.df5$x < zone1[2]  & map.df5$y > zone1[3] & map.df5$y < zone1[4]),]
  n.zone5 <- sum(!is.na(map.zone5$rate[map.zone5$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
  map.nozone5 <- map.df5[which(!(map.df5$x > zone1[1] & map.df5$x < zone1[2]  & map.df5$y > zone1[3] & map.df5$y < zone1[4])),]
  
  # calculate mean rate in each of those zones for each cell
  mean_fr.zone1 <- c()
  mean_fr.nozone1 <- c()
  sd_fr.nozone1 <- c()
  mean_fr.zone2 <- c()
  mean_fr.nozone2 <- c()
  sd_fr.nozone2 <- c()
  mean_fr.zone3 <- c()
  mean_fr.nozone3 <- c()
  sd_fr.nozone3 <- c()
  mean_fr.zone4 <- c()
  mean_fr.nozone4 <- c()
  sd_fr.nozone4 <- c()
  mean_fr.zone5 <- c()
  mean_fr.nozone5 <- c()
  sd_fr.nozone5 <- c()
  for(i in 1:st@nCells){
    mean_fr.zone1[i] <- mean(map.zone1$rate[map.zone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map.nozone1_sample <- sample(map.nozone1$rate[which(map.nozone1$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map.nozone1$rate))], size = n.zone1)
    mean_fr.nozone1[i] <- mean(map.nozone1_sample, na.rm = TRUE)
    sd_fr.nozone1[i] <- sd(map.nozone1_sample, na.rm = TRUE)
    
    mean_fr.zone2[i] <- mean(map.zone2$rate[map.zone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map.nozone2_sample <- sample(map.nozone2$rate[which(map.nozone2$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map.nozone2$rate))], size = n.zone2)
    mean_fr.nozone2[i] <- mean(map.nozone2_sample, na.rm = TRUE)
    sd_fr.nozone2[i] <- sd(map.nozone2_sample, na.rm = TRUE)
    
    mean_fr.zone3[i] <- mean(map.zone3$rate[map.zone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map.nozone3_sample <- sample(map.nozone3$rate[which(map.nozone3$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map.nozone3$rate))], size = n.zone3)
    mean_fr.nozone3[i] <- mean(map.nozone3_sample, na.rm = TRUE)
    sd_fr.nozone3[i] <- sd(map.nozone3_sample, na.rm = TRUE)
    
    mean_fr.zone4[i] <- mean(map.zone4$rate[map.zone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map.nozone4_sample <- sample(map.nozone4$rate[which(map.nozone4$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map.nozone4$rate))], size = n.zone4)
    mean_fr.nozone4[i] <- mean(map.nozone4_sample, na.rm = TRUE)
    sd_fr.nozone4[i] <- sd(map.nozone4_sample, na.rm = TRUE)
    
    mean_fr.zone5[i] <- mean(map.zone5$rate[map.zone5$clu.id == paste(rs@session, "_",cg@clu[i],sep = "")], na.rm = TRUE)
    map.nozone5_sample <- sample(map.nozone5$rate[which(map.nozone5$clu.id == paste(rs@session, "_",cg@clu[i],sep = "") & !is.na(map.nozone5$rate))], size = n.zone5)
    mean_fr.nozone5[i] <- mean(map.nozone5_sample, na.rm = TRUE)
    sd_fr.nozone5[i] <- sd(map.nozone5_sample, na.rm = TRUE)
  }
  
  #Calculate z score for session 
  z.score1 <- (mean_fr.zone1 - mean_fr.nozone1)/(sd_fr.nozone1/sqrt(n.zone1))
  z.score2 <- (mean_fr.zone2 - mean_fr.nozone2)/(sd_fr.nozone2/sqrt(n.zone2))
  z.score3 <- (mean_fr.zone3 - mean_fr.nozone3)/(sd_fr.nozone3/sqrt(n.zone3))
  z.score4 <- (mean_fr.zone4 - mean_fr.nozone4)/(sd_fr.nozone4/sqrt(n.zone4))
  z.score5 <- (mean_fr.zone5 - mean_fr.nozone5)/(sd_fr.nozone5/sqrt(n.zone5))

  #store the results in a data frame called "cells" for each open field trial
  cells_all <- data.frame(mouse=rs@animalName, session=rs@session, cell.id=cg@id[st.s1@cellList-1],tetrode.id=cg@tetrode[st.s1@cellList-1],region=cg@brainRegion[st.s1@cellList-1],
                          clu.to.tet=cg@cluToTetrode[st.s1@cellList-1], protocol=protocol, MFR=st@meanFiringRate[st.s1@cellList-1],
                          z.score1, z.score2, z.score3, z.score4, z.score5)
  rm(z.score1, z.score2, z.score3, z.score4, z.score5)
  gc()
  print(sp.s1@nShufflings)
  
  zsh1 <- getZscoreShuffle(rs, sp.s1,st.s1, pt.s1, cg, zone = 1)
  zsh2 <- getZscoreShuffle(rs, sp.s2,st.s2, pt.s2, cg, zone = 2)
  zsh3 <- getZscoreShuffle(rs, sp.s3,st.s3, pt.s3, cg, zone = 2)
  zsh4 <- getZscoreShuffle(rs, sp.s4,st.s4, pt.s4, cg, zone = 2)
  zsh5 <- getZscoreShuffle(rs, sp.s5,st.s5, pt.s5, cg, zone = 1)
  
  shuff.zscore1 <- vector(length = length(st.s1@cellList))
  shuff.zscore2 <- vector(length = length(st.s1@cellList))
  shuff.zscore3 <- vector(length = length(st.s1@cellList))
  shuff.zscore4 <- vector(length = length(st.s1@cellList))
  shuff.zscore5 <- vector(length = length(st.s1@cellList))
  
  for (cell in st.s1@cellList){
    print("95th threshold...")
    # #z score 95th perc
    shuff.zscore1[cell-1] <-  as.numeric(quantile(zsh1[[1]][,cell-1],0.95,na.rm=T))
    shuff.zscore2[cell-1] <-  as.numeric(quantile(zsh2[[1]][,cell-1],0.95,na.rm=T))
    shuff.zscore3[cell-1] <-  as.numeric(quantile(zsh3[[1]][,cell-1],0.95,na.rm=T))
    shuff.zscore4[cell-1] <-  as.numeric(quantile(zsh4[[1]][,cell-1],0.95,na.rm=T))
    shuff.zscore5[cell-1] <-  as.numeric(quantile(zsh5[[1]][,cell-1],0.95,na.rm=T))
  }
  cells_all <- cbind(cells_all, shuff.zscore1, shuff.zscore2, shuff.zscore3, shuff.zscore4, shuff.zscore5)
  
  results <-list(zscore=cells_all)
  names(results) <- c("zscore")
  return(results)
}

runOnSessionList(ep1,sessionList=rss1, fnct=zscorestats_5OFobject, save=T,overwrite=T, parallel = F, cluster = cl) 
runOnSessionList(ep2,sessionList=rss2, fnct=zscorestats_5OFobject, save=T,overwrite=T, parallel = F, cluster = cl) 

#store everything as csv
load(paste(ep1@resultsDirectory,"zscore",sep="/"))
zscore1 <- zscore
write.csv(zscore, "~/LEC_remapping/results/zscore_shuffle_LECobject.csv")

load(paste(ep2@resultsDirectory,"zscore",sep="/"))
zscore2 <- zscore
write.csv(zscore, "~/LEC_remapping/results/zscore_shuffle_CA1object.csv")


## add results to summary table
cells_all1 <- read.csv(file="~/LEC_remapping/results/cells_allLEC_object_wv.csv", header = T)
cells_all2 <- read.csv(file="~/LEC_remapping/results/cells_allCA1_object_wv.csv", header = T)

levels(zscore1$cid) <- levels(cells_all1$cell.id)
cells_all1[,colnames(zscore1)[9:length(zscore1[1,])]] <- NA
for (c in 1:length(zscore1$cell.id)){
  cells_all[which(cells_all$cell.id==zscore1$cell.id[c]),colnames(zscore1)[9:length(zscore1[1,])]] <- zscore1[c,colnames(zscore1)[9:length(zscore1[1,])]]
}
write.csv(cells_all1, file = "~/LEC_remapping/results/cells_allLEC_object_wz.csv", row.names = F)

levels(zscore2$cid) <- levels(cells_all2$cell.id)
cells_all2[,colnames(zscore2)[9:length(zscore2[1,])]] <- NA
for (c in 1:length(zscore2$cell.id)){
  cells_all[which(cells_all$cell.id==zscore2$cell.id[c]),colnames(zscore2)[9:length(zscore2[1,])]] <- zscore2[c,colnames(zscore2)[9:length(zscore2[1,])]]
}
write.csv(cells_all2, file = "~/LEC_remapping/results/cells_allCA1_object_wz.csv", row.names = F)
