library(snow)
library(relectro)
library(scales)

workers<-c(rep("localhost",3))
cl<-makeCluster(workers, type = "SOCK",outfile="")
print(paste("Using",length(workers), "threads"))
clusterEvalQ(cl,library(relectro))

ep1<-new("ElectroProject",directory="/data/projects/Global_Remapping_Isa/LEC_context_object/")
ep1<-setSessionList(ep1)
save(ep1,file=paste(ep1@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep1@resultsDirectory,"ep",sep="/"))
rss1<-getSessionList(ep1,clustered=T)
rss1<-sortRecSessionListChronologically(rss1)

ep2<-new("ElectroProject",directory="/data/projects/Global_Remapping_Isa/CA1_context_object/")
ep2<-setSessionList(ep2)
save(ep2,file=paste(ep2@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep2@resultsDirectory,"ep",sep="/"))
rss2<-getSessionList(ep2,clustered=T)
rss2<-sortRecSessionListChronologically(rss2)

rs <- rss1[[1]]

source('~/source_scripts/sop_respath.R')

spikeOnPathRes <- function(rs, trial_n=NA){
  print(rs@session)
  #get sop_res function
  source('~/source_scripts/sop_respath.R')
  source('~/source_scripts/Positrack.R')
  library(scales)
  myList <- getRecSessionObjects(rs)
  cg <- myList$cg
  hd <- myList$hd
  pt <- myList$pt
  st <- myList$st
  sp <- myList$sp
  
  #make coordinates match between the boxes and go from 0,70 (cm)
  pt_positrack <- setInvalidOutsideInterval(pt, s=rs@trialStartRes[c(2,4,6,8,10)], e=rs@trialEndRes[c(2,4,6,8,10)])
  int_posi <- data.frame(start=rs@trialStartRes[c(2,4,6,8,10)], end=rs@trialEndRes[c(2,4,6,8,10)])
  pt_posib <- pt_positrack
  for (interval in 1:length(int_posi[,1])){
    pt_posib@x <- pt_positrack@x[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@y <- pt_positrack@y[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@xWhl <- pt_positrack@xWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@yWhl <- pt_positrack@yWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt@x[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@x))] <- rescale(pt_posib@x[!is.na(pt_posib@x)], to = c(0,70), from=range(pt_posib@x, na.rm = T))
    pt@y[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@y))] <- rescale(pt_posib@y[!is.na(pt_posib@y)], to = c(0,70), from=range(pt_posib@y, na.rm = T))
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@xWhl[which(pt_posib@xWhl>=0)], to = c(0, 700), from=range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T))
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@yWhl[which(pt_posib@yWhl>=0)], to = c(0, 700), from=range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T))
  }
  #Rescale the rest box trials, use the range from one the OF trials to appropriately do so.
  int_hc <- data.frame(start=rs@trialStartRes[c(1,3,5,7,9,11)], end=rs@trialEndRes[c(1,3,5,7,9,11)])
  pt_hc <- setInvalidOutsideInterval(pt, s=int_hc[,1],e=int_hc[,2])
  x_save <- range(pt_posib@x, na.rm = T)
  y_save <- range(pt_posib@y, na.rm = T)
  xw_save <- range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T)
  yw_save <- range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T)
  for (t in 1:nrow(int_hc)){
    x <- pt_hc@x[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    y <- pt_hc@y[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    xWhl <- pt_hc@xWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    yWhl <- pt_hc@yWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    pt@x[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=x_save)
    pt@y[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=y_save)
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=xw_save)
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=yw_save)
  }
  rm(x, y, yWhl, xWhl, pt_hc, int_hc, int_posi, pt_posib, pt_positrack) #free some memory
  
  print(paste('min x_cm:', min(pt@x, na.rm = T),'; max x_cm:', max(pt@x, na.rm = T)))
  print(paste('min y_cm:', min(pt@y, na.rm = T),'; max y_cm:', max(pt@y, na.rm = T)))
  
  ### IMPORTANT: recalculate speed after rescaling ## 
  ## get the speed from position
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  pt@speed[which(pt@speed==(-1.0))] <- NA
  
  if (isTRUE(is.numeric(trial_n))){
    print(rs@trialStartRes[trial_n])
    print(rs@trialEndRes[trial_n])
    pt <- setInvalidOutsideInterval(pt,s=rs@trialStartRes[trial_n], e=rs@trialEndRes[trial_n])
    st <- setIntervals(st,s=rs@trialStartRes[trial_n], e=rs@trialEndRes[trial_n])
  }
  sop_res <- spikeOnPath_res(sp, st, pt)
  
  write.csv(as.data.frame(sop_res[1:3]), file = paste("~/LEC_remapping/results/sop_object/",rs@session,"_",trial_n,".xyPath", sep = ""))
  write.csv(as.data.frame(sop_res[4:length(sop_res)]), file=paste("~/LEC_remapping/results/sop_object/",rs@session,"_",trial_n,".sop_phase_laser", sep = ""))
  return(result=sop_res)
}

# run function in all sessions 
###### LEC ####
#1st OF trial
runOnSessionList(ep1,sessionList=rss1, fnct=spikeOnPathResb, save=T,overwrite=T, trial_n=2, parallel = T, cluster = cl) 
#2nd OF trial
runOnSessionList(ep1,sessionList=rss1, fnct=spikeOnPathResb,save=T,overwrite=T,  trial_n=4, parallel = T, cluster= cl)
#3rd OF trials
runOnSessionList(ep1,sessionList=rss1, fnct=spikeOnPathResb, save=T,overwrite=T,  trial_n=6, parallel = T, cluster = cl) 
#4th OF trials
runOnSessionList(ep1,sessionList=rss1, fnct=spikeOnPathResb,save=T,overwrite=T, trial_n=8, parallel = T, cluster= cl)
#5th OF trials
runOnSessionList(ep1,sessionList=rss1, fnct=spikeOnPathResb,save=T,overwrite=T, trial_n=10, parallel = T, cluster= cl)
###### CA1 #####
#1st OF trials
runOnSessionList(ep2,sessionList=rss2, fnct=spikeOnPathResb, save=T,overwrite=T,  trial_n=2, parallel = T, cluster= cl) 
#2nd OF trials
runOnSessionList(ep2,sessionList=rss2, fnct=spikeOnPathResb,save=T,overwrite=T,  trial_n=4, parallel = T, cluster= cl)
#3rd OF trials
runOnSessionList(ep2,sessionList=rss2, fnct=spikeOnPathResb, save=T,overwrite=T,  trial_n=6, parallel = T, cluster= cl) 
#4th OF trials
runOnSessionList(ep2,sessionList=rss2, fnct=spikeOnPathResb,save=T,overwrite=T, trial_n=8, parallel = T, cluster= cl)
#5th OF trials
runOnSessionList(ep2,sessionList=rss2, fnct=spikeOnPathResb,save=T,overwrite=T, trial_n=10, parallel = T, cluster= cl)

stopCluster(cl) # stop the cluster when we are done
rm(cl,workers)

