Directory = '~/LEC_remapping/Maps_LEC_2room'; %change accordingly

%% pick only cells ids from spatial neurons
cids_foranalysis = readtable('~/LEC_remapping/cid_spatial_remapping.csv');

%get n cells per session
[d, ~, inames] = unique(cids_foranalysis.session);
Freq = histcounts(inames,numel(d)).';

d = dir(Directory); dfolders = d([d(:).isdir]);
n_s = size(d,1);

%get max number of cells in any of the sessions to preallocate the size of rate map
max_cells = max(Freq);

%% Create rate map structure
for a = 3:n_s
disp(a)
RateMap =  cell(5,max_cells);
cd (Directory);
cd (dfolders(a).name);
Info = readtable('cid_list.csv', 'ReadVariableNames', false);

ntrial = 5;
n_cells = size(Info,1);

if n_cells<0
    continue
end

[toinclude] = Info.Var1(ismember(Info.Var1, cids_foranalysis.cell_id));
if size(toinclude,1)> 0
cids = split(toinclude,"_");
    if size(toinclude,1) ==1
        cids = reshape(cids, [1,2]);
        cids_sess = cids(2);
    else
        cids_sess = cids(:,2);
    end
    for g = 1:size(cids_sess,1)
        for i = 1:ntrial
            Map = strcat('RateMap',num2str(i),'_',num2str(str2num(cids_sess{g})-1),'.csv');
            CurrMap = table2array(readtable(Map,"ReadVariableNames", false));
            CurrMap1 = CurrMap;

            CurrMap1(CurrMap1<0)=NaN;

            RateMap(i,g) = {CurrMap1};
        end
    end
    RateMap = RateMap(:,1:size(cids_sess,1));
    save RateMap RateMap

end
end

%%
RateMaps_1 = [];
RateMaps_2 = [];
for a = 3:n_s
    disp(a)
    cd (Directory) ;
    cd (dfolders(a).name);
    Info = readtable('cid_list.csv', 'ReadVariableNames', false);
    n_cells = size(Info,1);
    [toinclude] = Info.Var1(ismember(Info.Var1, cids_foranalysis.cell_id));
    if size(toinclude,1)> 0
        cids = split(toinclude,"_");
        if size(toinclude,1) ==1
            cids = reshape(cids, [1,2]);
            cids_sess = cids(2);
        else
            cids_sess = cids(:,2);
        end
        load ('RateMap')
        %add only the slots that contain data
        if Info.Var2{1} =="aabba"
            RateMaps_1 = [RateMaps_1, RateMap(:,1:size(toinclude,1))];
        elseif Info.Var2{1} =="abbaa"
            RateMaps_2 = [RateMaps_2, RateMap(:,1:size(toinclude,1))];
        end
    end

end

StackMap1_1 = makeStacksMS(RateMaps_1, 1);
StackMap2_1 = makeStacksMS(RateMaps_1, 2);
StackMap3_1 = makeStacksMS(RateMaps_1, 3);
StackMap4_1 = makeStacksMS(RateMaps_1, 4);
StackMap5_1 = makeStacksMS(RateMaps_1, 5);

StackMap1_2 = makeStacksMS(RateMaps_2, 1);
StackMap2_2 = makeStacksMS(RateMaps_2, 2);
StackMap3_2 = makeStacksMS(RateMaps_2, 3);
StackMap4_2 = makeStacksMS(RateMaps_2, 4);
StackMap5_2 = makeStacksMS(RateMaps_2, 5);

%make stack maps of a1,a2,a3,b1,b2 (a=black, b=white)
stackMap_a1 = cat(3,StackMap1_1,StackMap5_2);
stackMap_a2 = cat(3,StackMap2_1,StackMap4_2);
stackMap_a3 = cat(3,StackMap5_1,StackMap1_2);
stackMap_b1 = cat(3,StackMap3_1,StackMap3_2);
stackMap_b2 = cat(3,StackMap4_1,StackMap2_2);

PV12 = calculatePFandPVcorrMS(stackMap_a1, stackMap_a2);%W1
f = fieldnames(PV12)';
f{2,1} = {};
corr_a1a2 = struct(f{:});
corr_b1b2 = struct(f{:});
corr_a2b1 = struct(f{:});
corr_b2a3 = struct(f{:});

for it = 1:100
disp(it)
%% shuffled W1
% assign new indexes to shuffle the order of a2 maps
new_ix = randperm(size(stackMap_a1,3));
stackMap_a2_reorder = stackMap_a2(:,:,new_ix);
%calculate shuffled MS (=PF)
tmp_corr = calculatePFandPVcorrMS(stackMap_a1, stackMap_a2_reorder);
corr_a1a2 = [corr_a1a2, tmp_corr];

%% shuffled W2
% assign new indexes to shuffle the order of b2 maps
new_ix = randperm(size(stackMap_b1,3));
stackMap_b2_reorder = stackMap_b2(:,:,new_ix);
%calculate shuffledMS (=PF)
tmp_corr = calculatePFandPVcorrMS(stackMap_b1, stackMap_b2_reorder);
corr_b1b2 = [corr_b1b2, tmp_corr];

%% shuffled A1
% assign new indexes to shuffle the order of b1 maps
new_ix = randperm(size(stackMap_a2,3));
stackMap_b1_reorder = stackMap_b1(:,:,new_ix);
%calculate shuffled MS (=PF)
tmp_corr = calculatePFandPVcorrMS(stackMap_a2, stackMap_b1_reorder);
corr_a2b1 = [corr_a2b1, tmp_corr];

%% shuffled A2
% assign new indexes to shuffle the order of a3 maps
new_ix = randperm(size(stackMap_b2,3));
stackMap_a3_reorder = stackMap_a3(:,:,new_ix);
%calculate shuffled MS (=PF)
tmp_corr = calculatePFandPVcorrMS(stackMap_b2, stackMap_a3_reorder);
corr_b2a3 = [corr_b2a3, tmp_corr];
end
%%

save('~/LEC_remapping/shuffling_ms/CA12box_shuffMS.mat', "corr_b2a3","corr_a2b1","corr_b1b2", "corr_a1a2", ...
    "stackMap_a1", "stackMap_a2", "stackMap_a3", "stackMap_b1","stackMap_b2")

%change accordingly
writematrix(vertcat(corr_a1a2.PFcorr),'~/Desktop/LEC_remapping/results/shuffling_ms/LEC2room_shuffMS_W1.csv')
writematrix(vertcat(corr_b1b2.PFcorr),'~/Desktop/LEC_remapping/results/shuffling_ms/LEC2room_shuffMS_W2.csv')
writematrix(vertcat(corr_a2b1.PFcorr),'~/Desktop/LEC_remapping/results/shuffling_ms/LEC2room_shuffMS_A1.csv')
writematrix(vertcat(corr_b2a3.PFcorr),'~/Desktop/LEC_remapping/results/shuffling_ms/LEC2room_shuffMS_A2.csv')

quantile(horzcat(vertcat(corr_a1a2.PFcorr)),0.95,"all") %threshold for w1
quantile(horzcat(vertcat(corr_b1b2.PFcorr)),0.95,"all") %threshold for w2

chance_w1 = nanmedian(nanmedian(horzcat(vertcat(corr_a1a2.PFcorr))));

quantile(horzcat(vertcat(corr_a2b1.PFcorr)),0.95,"all") %threshold for A1
quantile(horzcat(vertcat(corr_b2a3.PFcorr)),0.95,"all") %threshold for A2