library(relectro)
library(ggplot2)
library(scales)
library(gridBase)
library(grid)

ep1<-new("ElectroProject",directory="/data/projects/Global_Remapping/LEC_2box_subset1") 
ep1<-setSessionList(ep1)
save(ep1,file=paste(ep1@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep1@resultsDirectory,"ep",sep="/"))
rss1<-getSessionList(ep1,clustered=T)
rss1<-sortRecSessionListChronologically(rss1)

source('~/source_scripts/MapCorrShuffle.R')
source('~/source_scripts/MapInfoShuffle.R')
source('~/source_scripts/Positrack.R')

recSessionstats_5OFbw2 <- function(rs, protocol="abbaa"){
  print(rs@session)
  myList<-getRecSessionObjects(rs)
  st<-myList$st
  pt<-myList$pt
  cg<-myList$cg
  sp<-myList$sp
  
  #make coordinates match between the boxes and go from 0,70 (cm)
  pt_positrack <- setInvalidOutsideInterval(pt, s=getIntervalsEnvironment(rs, environment = "sqr70"))
  int_posi <- data.frame(start=getIntervalsEnvironment(rs, environment = "sqr70")[,1], end=getIntervalsEnvironment(rs, environment = "sqr70")[,2])
  pt_posib <- pt_positrack
  for (interval in 1:length(int_posi[,1])){
    pt_posib@x <- pt_positrack@x[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@y <- pt_positrack@y[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@xWhl <- pt_positrack@xWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@yWhl <- pt_positrack@yWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt@x[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@x))] <- rescale(pt_posib@x[!is.na(pt_posib@x)], to = c(0,70), from=range(pt_posib@x, na.rm = T))
    pt@y[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@y))] <- rescale(pt_posib@y[!is.na(pt_posib@y)], to = c(0,70), from=range(pt_posib@y, na.rm = T))
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@xWhl[which(pt_posib@xWhl>=0)], to = c(0, 700), from=range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T))
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@yWhl[which(pt_posib@yWhl>=0)], to = c(0, 700), from=range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T))
  }
  #rescale the rest box trials, use the range from one the OF trials to appropriately do so.
  int_hc <- data.frame(start=getIntervalsEnvironment(rs, environment = "hc")[,1], end=getIntervalsEnvironment(rs, environment = "hc")[,2]) 
  pt_hc <- setInvalidOutsideInterval(pt, s=int_hc[,1],e=int_hc[,2]) 
  x_save <- range(pt_posib@x, na.rm = T)
  y_save <- range(pt_posib@y, na.rm = T)
  xw_save <- range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T)
  yw_save <- range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T)
  for (t in 1:nrow(int_hc)){
    x <- pt_hc@x[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    y <- pt_hc@y[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    xWhl <- pt_hc@xWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    yWhl <- pt_hc@yWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    pt@x[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=x_save)
    pt@y[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=y_save)
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=xw_save) 
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=yw_save) 
  }
  rm(x, y, yWhl, xWhl, pt_hc, int_hc, int_posi, pt_posib, pt_positrack) #free some memory
  
  ### IMPORTANT: recalculate speed after rescaling ## 
  ## get the speed from position
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  
  pt@speed[which(pt@speed==(-1.0))] <- NA
  
  print(paste('min x_cm:', min(pt@x, na.rm = T),'; max x_cm:', max(pt@x, na.rm = T)))
  print(paste('min y_cm:', min(pt@y, na.rm = T),'; max y_cm:', max(pt@y, na.rm = T)))
 
  ######### basic_stats ##########
  #calculate overall firing rate
  st <- meanFiringRate(st)
  # create st objects for each open field trial in the session
  st.s1 <- setIntervals(st, s=rs@trialStartRes[1], e=rs@trialEndRes[1])
  st.s2 <- setIntervals(st, s=rs@trialStartRes[3], e=rs@trialEndRes[3])
  st.s3 <- setIntervals(st, s=rs@trialStartRes[5], e=rs@trialEndRes[5])
  st.s4 <- setIntervals(st, s=rs@trialStartRes[7], e=rs@trialEndRes[7])
  st.s5 <- setIntervals(st, s=rs@trialStartRes[9], e=rs@trialEndRes[9])
  # create a positrack object for each open field trial in the session
  pt.s1<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[1], e=rs@trialEndRes[1])
  pt.s2<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[3], e=rs@trialEndRes[3])
  pt.s3<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[5], e=rs@trialEndRes[5])
  pt.s4<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[7], e=rs@trialEndRes[7])
  pt.s5<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[9], e=rs@trialEndRes[9])
  #filter by speed
  pt.s1<-speedFilter(pt.s1,minSpeed = 3,maxSpeed = 100)
  pt.s2<-speedFilter(pt.s2,minSpeed = 3,maxSpeed = 100)
  pt.s3<-speedFilter(pt.s3,minSpeed = 3,maxSpeed = 100)
  pt.s4<-speedFilter(pt.s4,minSpeed = 3,maxSpeed = 100)
  pt.s5<-speedFilter(pt.s5,minSpeed = 3,maxSpeed = 100)
  
  #Calculate the mean firing rates in each trial
  st.s1 <- meanFiringRate(st.s1)
  st.s2 <- meanFiringRate(st.s2)
  st.s3 <- meanFiringRate(st.s3)
  st.s4 <- meanFiringRate(st.s4)
  st.s5 <- meanFiringRate(st.s5)
  
  # Create firing rate maps for each cell of the list in each open field trial #
  sp.s1<-firingRateMap2d(sp,st.s1,pt.s1, nRowMap = 37, nColMap = 37)
  sp.s2<-firingRateMap2d(sp,st.s2,pt.s2, nRowMap = 37, nColMap = 37)
  sp.s3<-firingRateMap2d(sp,st.s3,pt.s3, nRowMap = 37, nColMap = 37)
  sp.s4<-firingRateMap2d(sp,st.s4,pt.s4, nRowMap = 37, nColMap = 37)
  sp.s5<-firingRateMap2d(sp,st.s5,pt.s5, nRowMap = 37, nColMap = 37)
  sp.s1@reduceSize <- F
  sp.s2@reduceSize <- F
  sp.s3@reduceSize <- F
  sp.s4@reduceSize <- F
  sp.s5@reduceSize <- F
  
  protocol <- protocol

  ## get firing rate map correlations
  print("across session spatial correlations...")
  MS_S12 <- firingRateMapCorrelation(sp.s1, sp.s2)
  MS_S13 <- firingRateMapCorrelation(sp.s1, sp.s3)
  MS_S14 <- firingRateMapCorrelation(sp.s1, sp.s4)
  MS_S15 <- firingRateMapCorrelation(sp.s1, sp.s5)
  MS_S23 <- firingRateMapCorrelation(sp.s2, sp.s3)
  MS_S24 <- firingRateMapCorrelation(sp.s2, sp.s4)
  MS_S25 <- firingRateMapCorrelation(sp.s2, sp.s5)
  MS_S34 <- firingRateMapCorrelation(sp.s3, sp.s4)
  MS_S35 <- firingRateMapCorrelation(sp.s3, sp.s5)
  MS_S45 <- firingRateMapCorrelation(sp.s4, sp.s5)
  
  # #get firing rate map correlations shuffled
  MS_S12sh <- getMapCorrShuffle(sp.s1,st.s1,pt.s1, sp.s2,st.s2,pt.s2)
  MS_S13sh <- getMapCorrShuffle(sp.s1,st.s1,pt.s1, sp.s3,st.s3,pt.s3)
  MS_S14sh <- getMapCorrShuffle(sp.s1,st.s1,pt.s1, sp.s4,st.s4,pt.s4)
  MS_S15sh <- getMapCorrShuffle(sp.s1,st.s1,pt.s1, sp.s5,st.s5,pt.s5)
  MS_S23sh <- getMapCorrShuffle(sp.s2,st.s2,pt.s2, sp.s3,st.s3,pt.s3)
  MS_S24sh <- getMapCorrShuffle(sp.s2,st.s2,pt.s2, sp.s4,st.s4,pt.s4)
  MS_S25sh <- getMapCorrShuffle(sp.s2,st.s2,pt.s2, sp.s5,st.s5,pt.s5)
  MS_S34sh <- getMapCorrShuffle(sp.s3,st.s3,pt.s3, sp.s4,st.s4,pt.s4)
  MS_S35sh <- getMapCorrShuffle(sp.s3,st.s3,pt.s3, sp.s5,st.s5,pt.s5)
  MS_S45sh <- getMapCorrShuffle(sp.s4,st.s4,pt.s4, sp.s5,st.s5,pt.s5)
  shuff.MS_S12 <- vector(length = length(st.s1@cellList))
  shuff.MS_S13 <- vector(length = length(st.s1@cellList))
  shuff.MS_S14 <- vector(length = length(st.s1@cellList))
  shuff.MS_S15 <- vector(length = length(st.s1@cellList))
  shuff.MS_S23 <- vector(length = length(st.s1@cellList))
  shuff.MS_S24 <- vector(length = length(st.s1@cellList))
  shuff.MS_S25 <- vector(length = length(st.s1@cellList))
  shuff.MS_S34 <- vector(length = length(st.s1@cellList))
  shuff.MS_S35 <- vector(length = length(st.s1@cellList))
  shuff.MS_S45 <- vector(length = length(st.s1@cellList))
  for (cell in st.s1@cellList){
    #map Correlations 95 percentile
    shuff.MS_S12[cell-1] <- as.numeric(quantile(MS_S12sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S13[cell-1] <- as.numeric(quantile(MS_S13sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S14[cell-1] <- as.numeric(quantile(MS_S14sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S15[cell-1] <- as.numeric(quantile(MS_S15sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S23[cell-1] <- as.numeric(quantile(MS_S23sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S24[cell-1] <- as.numeric(quantile(MS_S24sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S25[cell-1] <- as.numeric(quantile(MS_S25sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S34[cell-1] <- as.numeric(quantile(MS_S34sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S35[cell-1] <- as.numeric(quantile(MS_S35sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S45[cell-1] <- as.numeric(quantile(MS_S45sh[,cell-1],0.95,na.rm=T))
  }
  rm(MS_S12sh, MS_S13sh, MS_S14sh, MS_S15sh, MS_S23sh, MS_S24sh, MS_S25sh, MS_S34sh, MS_S35sh, MS_S45sh)
  #get basic spatial properties from this list: mean rate, info score, sparsity, etc
  print("map stats...")
  sp.s1<-getMapStats(sp.s1,st.s1,pt.s1)
  sp.s2<-getMapStats(sp.s2,st.s2,pt.s2)
  sp.s3<-getMapStats(sp.s3,st.s3,pt.s3)
  sp.s4<-getMapStats(sp.s4,st.s4,pt.s4)
  sp.s5<-getMapStats(sp.s5,st.s5,pt.s5)
  
  ### get within session spatial correlation ###
  #get st objects for each half
  st.s1a <- setIntervals(st.s1, s=st.s1@startInterval, e=st.s1@startInterval+((st.s1@endInterval-st.s1@startInterval)/2))
  st.s1b <- setIntervals(st.s1, s=st.s1@startInterval+((st.s1@endInterval-st.s1@startInterval)/2), e=st.s1@endInterval)
  st.s2a <- setIntervals(st.s2, s=st.s2@startInterval, e=st.s2@startInterval+((st.s2@endInterval-st.s2@startInterval)/2))
  st.s2b <- setIntervals(st.s2, s=st.s2@startInterval+((st.s2@endInterval-st.s2@startInterval)/2), e=st.s2@endInterval)
  st.s3a <- setIntervals(st.s3, s=st.s3@startInterval, e=st.s3@startInterval+((st.s3@endInterval-st.s3@startInterval)/2))
  st.s3b <- setIntervals(st.s3, s=st.s3@startInterval+((st.s3@endInterval-st.s3@startInterval)/2), e=st.s3@endInterval)
  st.s4a <- setIntervals(st.s4, s=st.s4@startInterval, e=st.s4@startInterval+((st.s4@endInterval-st.s4@startInterval)/2))
  st.s4b <- setIntervals(st.s4, s=st.s4@startInterval+((st.s4@endInterval-st.s4@startInterval)/2), e=st.s4@endInterval)
  st.s5a <- setIntervals(st.s5, s=st.s5@startInterval, e=st.s5@startInterval+((st.s5@endInterval-st.s5@startInterval)/2))
  st.s5b <- setIntervals(st.s5, s=st.s5@startInterval+((st.s5@endInterval-st.s5@startInterval)/2), e=st.s5@endInterval)
  #get pt objects for each half
  pt.s1a<-setInvalidOutsideInterval(pt,s=st.s1@startInterval, e=st.s1@startInterval+((st.s1@endInterval-st.s1@startInterval)/2))
  pt.s1b<-setInvalidOutsideInterval(pt,s=st.s1@startInterval+((st.s1@endInterval-st.s1@startInterval)/2), e=st.s1@endInterval)
  pt.s2a<-setInvalidOutsideInterval(pt,s=st.s2@startInterval, e=st.s2@startInterval+((st.s2@endInterval-st.s2@startInterval)/2))
  pt.s2b<-setInvalidOutsideInterval(pt,s=st.s2@startInterval+((st.s2@endInterval-st.s2@startInterval)/2), e=st.s2@endInterval)
  pt.s3a<-setInvalidOutsideInterval(pt,s=st.s3@startInterval, e=st.s3@startInterval+((st.s3@endInterval-st.s3@startInterval)/2))
  pt.s3b<-setInvalidOutsideInterval(pt,s=st.s3@startInterval+((st.s3@endInterval-st.s3@startInterval)/2), e=st.s3@endInterval)
  pt.s4a<-setInvalidOutsideInterval(pt,s=st.s4@startInterval, e=st.s4@startInterval+((st.s4@endInterval-st.s4@startInterval)/2))
  pt.s4b<-setInvalidOutsideInterval(pt,s=st.s4@startInterval+((st.s4@endInterval-st.s4@startInterval)/2), e=st.s4@endInterval)
  pt.s5a<-setInvalidOutsideInterval(pt,s=st.s5@startInterval, e=st.s5@startInterval+((st.s5@endInterval-st.s5@startInterval)/2))
  pt.s5b<-setInvalidOutsideInterval(pt,s=st.s5@startInterval+((st.s5@endInterval-st.s5@startInterval)/2), e=st.s5@endInterval)
  #get firing rate maps
  sp.s1a<-firingRateMap2d(sp,st.s1a,pt.s1a, nRowMap = 37,nColMap = 37)
  sp.s1b<-firingRateMap2d(sp,st.s1b,pt.s1b, nRowMap = 37,nColMap = 37)
  sp.s2a<-firingRateMap2d(sp,st.s2a,pt.s2a, nRowMap = 37,nColMap = 37)
  sp.s2b<-firingRateMap2d(sp,st.s2b,pt.s2b, nRowMap = 37,nColMap = 37)
  sp.s3a<-firingRateMap2d(sp,st.s3a,pt.s3a, nRowMap = 37,nColMap = 37)
  sp.s3b<-firingRateMap2d(sp,st.s3b,pt.s3b, nRowMap = 37,nColMap = 37)
  sp.s4a<-firingRateMap2d(sp,st.s4a,pt.s4a, nRowMap = 37,nColMap = 37)
  sp.s4b<-firingRateMap2d(sp,st.s4b,pt.s4b, nRowMap = 37,nColMap = 37)
  sp.s5a<-firingRateMap2d(sp,st.s5a,pt.s5a, nRowMap = 37,nColMap = 37)
  sp.s5b<-firingRateMap2d(sp,st.s5b,pt.s5b, nRowMap = 37,nColMap = 37)
  sp.s1a@reduceSize <- F
  sp.s1b@reduceSize <- F
  sp.s2a@reduceSize <- F
  sp.s2b@reduceSize <- F
  sp.s3a@reduceSize <- F
  sp.s3b@reduceSize <- F
  sp.s4a@reduceSize <- F
  sp.s4b@reduceSize <- F
  sp.s5a@reduceSize <- F
  sp.s5b@reduceSize <- F
  #calculate map correlation
  print("within session spatial correlations...")
  MS_S11 <- firingRateMapCorrelation(sp.s1a, sp.s1b)
  MS_S22 <- firingRateMapCorrelation(sp.s2a, sp.s2b)
  MS_S33 <- firingRateMapCorrelation(sp.s3a, sp.s3b)
  MS_S44 <- firingRateMapCorrelation(sp.s4a, sp.s4b)
  MS_S55 <- firingRateMapCorrelation(sp.s5a, sp.s5b)
  #calculate shuffled map correlation
  MS_S11sh <- getMapCorrShuffle(sp.s1a,st.s1a,pt.s1a, sp.s1b,st.s1b,pt.s1b)
  MS_S22sh <- getMapCorrShuffle(sp.s2a,st.s2a,pt.s2a, sp.s2b,st.s2b,pt.s2b)
  MS_S33sh <- getMapCorrShuffle(sp.s3a,st.s3a,pt.s3a, sp.s3b,st.s3b,pt.s3b)
  MS_S44sh <- getMapCorrShuffle(sp.s4a,st.s4a,pt.s4a, sp.s4b,st.s4b,pt.s4b)
  MS_S55sh <- getMapCorrShuffle(sp.s5a,st.s5a,pt.s5a, sp.s5b,st.s5b,pt.s5b)
  ###
  shuff.MS_S11 <- vector()
  shuff.MS_S22 <- vector()
  shuff.MS_S33 <- vector()
  shuff.MS_S44 <- vector()
  shuff.MS_S55 <- vector()
  
  #add shuffled values to each cell
  for (cell in st.s1@cellList){
    print("95th threshold...")
    shuff.MS_S11[cell-1] <- as.numeric(quantile(MS_S11sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S22[cell-1] <- as.numeric(quantile(MS_S22sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S33[cell-1] <- as.numeric(quantile(MS_S33sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S44[cell-1] <- as.numeric(quantile(MS_S44sh[,cell-1],0.95,na.rm=T))
    shuff.MS_S55[cell-1] <- as.numeric(quantile(MS_S55sh[,cell-1],0.95,na.rm=T))
  }
  rm(MS_S11sh,MS_S22sh,MS_S33sh,MS_S44sh,MS_S55sh)
  #store the results in a data frame called "cells" for each open field trial
  cells_all <- data.frame(mouse=rs@animalName, session=rs@session, cell.id=cg@id[st.s1@cellList-1],tetrode.id=cg@tetrode[st.s1@cellList-1],region=cg@brainRegion[st.s1@cellList-1],
                          clu.to.tet=cg@cluToTetrode[st.s1@cellList-1], protocol=protocol, MFR=st@meanFiringRate[st.s1@cellList-1],
                          PFR_S1= sp.s1@peakRate, MFR_S1=st.s1@meanFiringRate[st.s1@cellList-1],
                          IS_S1=sp.s1@infoScore, sparsity1=sp.s1@sparsity, 
                          PFR_S2= sp.s2@peakRate, MFR_S2=st.s2@meanFiringRate[st.s2@cellList-1], 
                          IS_S2=sp.s2@infoScore, sparsity2=sp.s2@sparsity, 
                          PFR_S3= sp.s3@peakRate, MFR_S3=st.s3@meanFiringRate[st.s3@cellList-1], 
                          IS_S3=sp.s3@infoScore, sparsity3=sp.s3@sparsity, 
                          PFR_S4= sp.s4@peakRate, MFR_S4=st.s4@meanFiringRate[st.s4@cellList-1], 
                          IS_S4=sp.s4@infoScore, sparsity4=sp.s4@sparsity, 
                          PFR_S5= sp.s5@peakRate, MFR_S5=st.s5@meanFiringRate[st.s5@cellList-1], 
                          IS_S5=sp.s5@infoScore, sparsity5=sp.s5@sparsity, 
                          MS_S12,MS_S13, MS_S14, MS_S15, MS_S23, MS_S24, MS_S25, MS_S34, MS_S35, MS_S45,
                          MS_S11,MS_S22, MS_S33, MS_S44, MS_S55,
                          shuff.MS_S12,shuff.MS_S13, shuff.MS_S14, shuff.MS_S15, shuff.MS_S23, shuff.MS_S24, shuff.MS_S25,
                          shuff.MS_S34, shuff.MS_S35, shuff.MS_S45, shuff.MS_S11,shuff.MS_S22, shuff.MS_S33, shuff.MS_S44, shuff.MS_S55)
  rm(st.s1a, st.s1b, sp.s1a, sp.s1b, pt.s1a, pt.s1b, st.s2a, st.s2b, sp.s2a, sp.s2b, pt.s2a, pt.s2b,
     st.s3a, st.s3b, sp.s3a, sp.s3b, pt.s3a, pt.s3b, st.s4a, st.s4b, sp.s4a, sp.s4b, pt.s4a, pt.s4b,
     st.s5a, st.s5b, sp.s5a, sp.s5b, pt.s5a, pt.s5b, MS_S12,MS_S13, MS_S14, MS_S15, MS_S23, MS_S24, MS_S25, MS_S34, MS_S35, MS_S45,
     MS_S11,MS_S22, MS_S33, MS_S44, MS_S55,
     shuff.MS_S12,shuff.MS_S13, shuff.MS_S14, shuff.MS_S15, shuff.MS_S23, shuff.MS_S24, shuff.MS_S25,
     shuff.MS_S34, shuff.MS_S35, shuff.MS_S45, shuff.MS_S11,shuff.MS_S22, shuff.MS_S33, shuff.MS_S44, shuff.MS_S55)
  gc()
  print(sp.s1@nShufflings)
  #get information scores shuffled
  print("get map stats shuffle...")
  sp.s1<-getMapInfoShuffle(sp.s1,st.s1,pt.s1)
  sp.s2<-getMapInfoShuffle(sp.s2,st.s2,pt.s2)
  sp.s3<-getMapInfoShuffle(sp.s3,st.s3,pt.s3)
  sp.s4<-getMapInfoShuffle(sp.s4,st.s4,pt.s4)
  sp.s5<-getMapInfoShuffle(sp.s5,st.s5,pt.s5)
  
  shuff.infoscore1 <- vector(length = length(st.s1@cellList))
  shuff.infoscore2 <- vector(length = length(st.s1@cellList))
  shuff.infoscore3 <- vector(length = length(st.s1@cellList))
  shuff.infoscore4 <- vector(length = length(st.s1@cellList))
  shuff.infoscore5 <- vector(length = length(st.s1@cellList))
  for (cell in st.s1@cellList){
    print("95th threshold...")
    # #info scores 99 percentile
    shuff.infoscore1[cell-1] <-  as.numeric(quantile(sp.s1@infoScoreShuffle[seq((cell-1), st.s1@nCells*sp.s1@nShufflings, by=st.s1@nCells)],0.99,na.rm=T))
    shuff.infoscore2[cell-1] <-  as.numeric(quantile(sp.s2@infoScoreShuffle[seq((cell-1), st.s2@nCells*sp.s2@nShufflings, by=st.s2@nCells)],0.99,na.rm=T))
    shuff.infoscore3[cell-1] <-  as.numeric(quantile(sp.s3@infoScoreShuffle[seq((cell-1), st.s3@nCells*sp.s3@nShufflings, by=st.s3@nCells)],0.99,na.rm=T))
    shuff.infoscore4[cell-1] <-  as.numeric(quantile(sp.s4@infoScoreShuffle[seq((cell-1), st.s4@nCells*sp.s4@nShufflings, by=st.s4@nCells)],0.99,na.rm=T))
    shuff.infoscore5[cell-1] <-  as.numeric(quantile(sp.s5@infoScoreShuffle[seq((cell-1), st.s5@nCells*sp.s5@nShufflings, by=st.s5@nCells)],0.99,na.rm=T))
  }
  cells_all <- cbind(cells_all, IS_S1sh=shuff.infoscore1, IS_S2sh=shuff.infoscore2, IS_S3sh=shuff.infoscore3, IS_S4sh=shuff.infoscore4,
                     IS_S5sh=shuff.infoscore5)
  
  results <-list(cells_all=cells_all)
  names(results) <- c("cells_all")
  return(results)
}


runOnSessionList(ep1,sessionList=rss1, fnct=recSessionstats_5OFbw2, save=T,overwrite=T, parallel = F, protocol="abbaa") 

#store everything as csv
load(paste(ep1@resultsDirectory,"cells_all",sep="/"))
cells_all$A1 <- NA
cells_all$A2 <- NA
cells_all$W1 <- NA
cells_all$W2 <- NA
cells_all$A1[which(cells_all$protocol=="aabba")]<-cells_all$MS_S23[which(cells_all$protocol=="aabba")]
cells_all$A1[which(cells_all$protocol=="abbaa")]<-cells_all$MS_S12[which(cells_all$protocol=="abbaa")]
cells_all$A2[which(cells_all$protocol=="aabba")]<-cells_all$MS_S45[which(cells_all$protocol=="aabba")]
cells_all$A2[which(cells_all$protocol=="abbaa")]<-cells_all$MS_S34[which(cells_all$protocol=="abbaa")]
cells_all$W1[which(cells_all$protocol=="aabba")]<-cells_all$MS_S12[which(cells_all$protocol=="aabba")]
cells_all$W1[which(cells_all$protocol=="abbaa")]<-cells_all$MS_S23[which(cells_all$protocol=="abbaa")]
cells_all$W2[which(cells_all$protocol=="aabba")]<-cells_all$MS_S34[which(cells_all$protocol=="aabba")]
cells_all$W2[which(cells_all$protocol=="abbaa")]<-cells_all$MS_S45[which(cells_all$protocol=="abbaa")]
write.csv(cells_all, "~/LEC_remapping/results/cells_allLEC_2box_subset1.csv")



