%% Load data
Directory = '~/LEC_remapping/Maps_LEC_2room'; %change accordingly

%% pick only cells ids from discriminating neurons
cids_foranalysis = readtable('~/LEC_remapping/results/cid_PVanalysis_discriminating.csv');

%get n cells per session
[d, ~, inames] = unique(cids_foranalysis.session);
Freq = histcounts(inames,numel(d)).';

d = dir(Directory); dfolders = d([d(:).isdir]);
n_s = size(d,1);

%get max number of cells in any of the sessions to preallocate the size of
%rate map
max_cells = max(Freq);

%% Create rate map structure
for a = 3:n_s
disp(a)
RateMap =  cell(5,max_cells);
cd (Directory);
cd (dfolders(a).name);
Info = readtable('cid_list.csv', 'ReadVariableNames', false);

ntrial = 5;
n_cells = size(Info,1);

%do not use sessions with less than 2 cells
if n_cells<2
    continue
end

[toinclude] = Info.Var1(ismember(Info.Var1, cids_foranalysis.cell_id));
if size(toinclude,1)> 1
cids = split(toinclude,"_");
cids_sess = cids(:,2);
% figure
    for g = 1:size(cids_sess,1)%n_cells
        for i = 1:ntrial
            Map = strcat('RateMap',num2str(i),'_',num2str(str2num(cids_sess{g})-1),'.csv');
            CurrMap = table2array(readtable(Map,"ReadVariableNames", false));
            CurrMap1 = CurrMap;
            CurrMap1(CurrMap1<=-0.1)=NaN;
            RateMap(i,g) = {CurrMap1};
        end
    end
    save RateMap RateMap
end
end

%%
RateMaps_1 = [];
RateMaps_2 = [];
for a = 3:n_s
    disp(a)
    cd (Directory) ;
    cd (dfolders(a).name);
    Info = readtable('cid_list.csv', 'ReadVariableNames', false);
    n_cells = size(Info,1);
    [toinclude] = Info.Var1(ismember(Info.Var1, cids_foranalysis.cell_id));
    if size(toinclude,1)> 1
        cids = split(toinclude,"_");
        cids_sess = cids(:,2);
        load ('RateMap')
        %add only the slots that contain data
        if Info.Var2{1} =="aabba"
            RateMaps_1 = [RateMaps_1, RateMap(:,1:size(toinclude,1))];
        elseif Info.Var2{1} =="abbaa"
            RateMaps_2 = [RateMaps_2, RateMap(:,1:size(toinclude,1))];
        end
    end

end


%% Stacks maps into a third dimension
StackMap1_1 = makeStacksMS(RateMaps_1, 1);
StackMap2_1 = makeStacksMS(RateMaps_1, 2);
StackMap3_1 = makeStacksMS(RateMaps_1, 3);
StackMap4_1 = makeStacksMS(RateMaps_1, 4);
StackMap5_1 = makeStacksMS(RateMaps_1, 5);

StackMap1_2 = makeStacksMS(RateMaps_2, 1);
StackMap2_2 = makeStacksMS(RateMaps_2, 2);
StackMap3_2 = makeStacksMS(RateMaps_2, 3);
StackMap4_2 = makeStacksMS(RateMaps_2, 4);
StackMap5_2 = makeStacksMS(RateMaps_2, 5);

%make stack maps of a1,a2,a3,b1,b2 (a=black, b=white)
stackMap_a1 = cat(3,StackMap1_1,StackMap1_2);
stackMap_a2 = cat(3,StackMap2_1,StackMap4_2);
stackMap_a3 = cat(3,StackMap5_1,StackMap5_2);
stackMap_b1 = cat(3,StackMap3_1,StackMap2_2);
stackMap_b2 = cat(3,StackMap4_1,StackMap3_2);

AverageMap_a1 = nanmean(stackMap_a1,3);
AverageMap_a2 = nanmean(stackMap_a2,3);
AverageMap_a3 = nanmean(stackMap_a3,3);
AverageMap_b1 = nanmean(stackMap_b1,3);
AverageMap_b2 = nanmean(stackMap_b2,3);

%% calculate PV correlation
PV12 = calculatePFandPVcorrMS(stackMap_a1, stackMap_a2);%W1
PV23 = calculatePFandPVcorrMS(stackMap_a2, stackMap_b1);%A1
PV34 = calculatePFandPVcorrMS(stackMap_b1, stackMap_b2);%W2
PV45 = calculatePFandPVcorrMS(stackMap_b2, stackMap_a3);%A2
PV15 = calculatePFandPVcorrMS(stackMap_a1, stackMap_a3);%W3

%change accordingly
save("~/LEC_remapping/results/PV_results_LEC_2room_disc.mat", "PV23", "PV12", "PV34", "PV45", "PV15")
