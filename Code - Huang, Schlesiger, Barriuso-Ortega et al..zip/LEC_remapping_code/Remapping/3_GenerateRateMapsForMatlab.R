
rm(list = ls())

library(relectro)
library(scales)

ep<-new("ElectroProject",directory="/data/projects/Global_Remapping_Isa/LEC_2room/") #change accordingly
ep<-setSessionList(ep)
save(ep,file=paste(ep@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep@resultsDirectory,"ep",sep="/"))
rss<-getSessionList(ep,clustered=T)

# function for all data sets except LEC_2box_subset1
GenerateDataForMatlab<-function(rs, rotation =T){
  print(rs@session)
  source('~/source_scripts/Positrack.R')
  myList = getRecSessionObjects(rs)
  cg = myList$cg
  pt = myList$pt
  st = myList$st
  sp = myList$sp
  hd = myList$hd
  
  ## so that pixels in different sp objects align
  sp@reduceSize=FALSE 
  
  ## Apply speed filter
  pt<-speedFilter(pt,minSpeed=3,maxSpeed = 80)
  
  #make coordinates match between the rooms and go from 0,70 (cm)
  pt_positrack <- setInvalidOutsideInterval(pt, s=rs@trialStartRes[c(2,4,6,8,10)], e=rs@trialEndRes[c(2,4,6,8,10)])
  int_posi <- data.frame(start=rs@trialStartRes[c(2,4,6,8,10)], end=rs@trialEndRes[c(2,4,6,8,10)])
  pt_posib <- pt_positrack
  #print(int_posi)
  for (interval in 1:length(int_posi[,1])){
    pt_posib@x <- pt_positrack@x[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@y <- pt_positrack@y[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@xWhl <- pt_positrack@xWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@yWhl <- pt_positrack@yWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    
    pt@x[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@x))] <- rescale(pt_posib@x[!is.na(pt_posib@x)], to = c(0,70), from=range(pt_posib@x, na.rm = T))
    pt@y[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@y))] <- rescale(pt_posib@y[!is.na(pt_posib@y)], to = c(0,70), from=range(pt_posib@y, na.rm = T))
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@xWhl[which(pt_posib@xWhl>=0)], to = c(0, 700), from=range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T))
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@yWhl[which(pt_posib@yWhl>=0)], to = c(0, 700), from=range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T))
  }
  #Rescale the rest box trials, use the range from one the OF trials to appropriately do so.
  int_hc <- data.frame(start=rs@trialStartRes[c(1,3,5,7,9,11)], end=rs@trialEndRes[c(1,3,5,7,9,11)]) 
  pt_hc <- setInvalidOutsideInterval(pt, s=int_hc[,1],e=int_hc[,2]) #select tracking data
  x_save <- range(pt_posib@x, na.rm = T)
  y_save <- range(pt_posib@y, na.rm = T)
  xw_save <- range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T)
  yw_save <- range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T)
  for (t in 1:nrow(int_hc)){
    #get x and y values of trial number t (of the OF trials in room 55)
    x <- pt_hc@x[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    y <- pt_hc@y[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    xWhl <- pt_hc@xWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    yWhl <- pt_hc@yWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    pt@x[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=x_save)
    pt@y[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=y_save)
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=xw_save) 
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=yw_save)
  }
  rm(x, y, yWhl, xWhl, pt_hc, int_hc, int_posi, pt_posib, pt_positrack) #free some memory
  
  print(paste('min x_cm:', min(pt@x, na.rm = T),'; max x_cm:', max(pt@x, na.rm = T)))
  print(paste('min y_cm:', min(pt@y, na.rm = T),'; max y_cm:', max(pt@y, na.rm = T)))
  
  ### IMPORTANT: recalculate speed after rescaling ## 
  ## get the speed from position
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  pt@speed[which(pt@speed==(-1.0))] <- NA
  
  
  ## Get positrack objects for the 5 open field trials
  ##only used in the spike on path
  ptsqr70.1<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[2], e=rs@trialEndRes[2])
  ptsqr70.1<-speedFilter(ptsqr70.1,minSpeed=3,maxSpeed = 80)
  
  ptsqr70.2<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[4], e=rs@trialEndRes[4])
  ptsqr70.2<-speedFilter(ptsqr70.2,minSpeed=3,maxSpeed = 80)
  
  ptsqr70.3<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[6], e=rs@trialEndRes[6])
  ptsqr70.3<-speedFilter(ptsqr70.3,minSpeed=3,maxSpeed = 80)
  
  ptsqr70.4<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[8], e=rs@trialEndRes[8])
  ptsqr70.4<-speedFilter(ptsqr70.4,minSpeed=3,maxSpeed = 80)
  
  ptsqr70.5<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[10], e=rs@trialEndRes[10])
  ptsqr70.5<-speedFilter(ptsqr70.5,minSpeed=3,maxSpeed = 80)
  ###
  
  ##get st objects for each sqr70 env
  st1<-setIntervals(st=st,s=rs@trialStartRes[2],e=rs@trialEndRes[2])
  st2<-setIntervals(st=st,s=rs@trialStartRes[4],e=rs@trialEndRes[4])
  st3<-setIntervals(st=st,s=rs@trialStartRes[6],e=rs@trialEndRes[6])
  st4<-setIntervals(st=st,s=rs@trialStartRes[8],e=rs@trialEndRes[8])
  st5<-setIntervals(st=st,s=rs@trialStartRes[10],e=rs@trialEndRes[10])
  ##
  
  #calculate firing rate maps
  sp1<-firingRateMap2d(sp,st1,ptsqr70.1, nRowMap = 37,nColMap = 37)
  sp2<-firingRateMap2d(sp,st2,ptsqr70.2, nRowMap = 37,nColMap = 37)
  sp3<-firingRateMap2d(sp,st3,ptsqr70.3, nRowMap = 37,nColMap = 37)
  sp4<-firingRateMap2d(sp,st4,ptsqr70.4, nRowMap = 37,nColMap = 37)
  sp5<-firingRateMap2d(sp,st5,ptsqr70.5, nRowMap = 37,nColMap = 37)
  
  if(rotation==T){
    # rotate 180° those maps from the other room
    if(rs@environment[2]==rs@environment[4]){
      protocol <- 'aabba'
      if(rs@environment[1]=="sqr70_55"){
        sp1 <- firingRateMapsRotation(sp1, 180)
        sp2 <- firingRateMapsRotation(sp2, 180)
        sp5 <- firingRateMapsRotation(sp5, 180)
      }else if (rs@environment[1]=="sqr70_28"){
        sp3 <- firingRateMapsRotation(sp3, 180)
        sp4 <- firingRateMapsRotation(sp4, 180)
      }
    }else if(rs@environment[2]==rs@environment[8]){
      protocol <- 'abbaa'
      if(rs@environment[1]=="sqr70_55"){
        sp1 <- firingRateMapsRotation(sp1, 180)
        sp4 <- firingRateMapsRotation(sp4, 180)
        sp5 <- firingRateMapsRotation(sp5, 180)
      }else if (rs@environment[1]=="sqr70_28"){
        sp2 <- firingRateMapsRotation(sp2, 180)
        sp3 <- firingRateMapsRotation(sp3, 180)
      }
    }
  }else{
    if(rs@environment[2]==rs@environment[4]){
      protocol <- 'aabba'
    }else if(rs@environment[2]==rs@environment[8]){
      protocol <- 'abbaa'
    }
    if(rs@environment[1]=="sqr70_55b"){
      sp1 <- firingRateMapsRotation(sp1, 180)
      sp2 <- firingRateMapsRotation(sp2, 180)
      sp3 <- firingRateMapsRotation(sp3, 180)
      sp4 <- firingRateMapsRotation(sp4, 180)
      sp5 <- firingRateMapsRotation(sp5, 180)
    }
  }
  
  ################################################################################################################################
  datadir = "~/LEC_remapping/"
  subdir =  "Maps_LEC_2room" #change accordingly
  subdir2 =  rs@session  
  setwd(datadir)
  
  if (file.exists(subdir)){
    setwd(file.path(datadir, subdir))
  } else {
    dir.create(file.path(datadir, subdir))
    
    setwd(file.path(datadir, subdir))
  }
  
  datadir2 = getwd()
  dir.create(subdir2)
  
  if (file.exists(subdir2)){
    setwd(subdir2)
  } else {
    dir.create(subdir2)
    setwd(subdir2)
  }
  #create a file with the protocol order
  write.table(data.frame(cid=cg@id, protocol=protocol), paste0("cid_list.csv"), row.names = F, col.names = F)
  
  #eliminate -1 rows appropriately
  for (i in 1:length(cg@clu)){
  if(rotation==T){
    if(rs@environment[2]==rs@environment[4]){
      protocol <- 'aabba'
      if(rs@environment[1]=="sqr70_55"){
        filename = paste0("RateMap1_",i,".csv")
        write.table(sp1@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE) 
        filename = paste0("RateMap2_",i,".csv")
        write.table(sp2@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap3_",i,".csv")
        write.table(sp3@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap4_",i,".csv")
        write.table(sp4@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap5_",i,".csv")
        write.table(sp5@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
      }else if (rs@environment[1]=="sqr70_28"){
        filename = paste0("RateMap1_",i,".csv")
        write.table(sp1@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE) 
        filename = paste0("RateMap2_",i,".csv")
        write.table(sp2@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap3_",i,".csv")
        write.table(sp3@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap4_",i,".csv")
        write.table(sp4@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap5_",i,".csv")
        write.table(sp5@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
      }
    }else if(rs@environment[2]==rs@environment[8]){
      protocol <- 'abbaa'
      if(rs@environment[1]=="sqr70_55"){
        filename = paste0("RateMap1_",i,".csv")
        write.table(sp1@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE) 
        filename = paste0("RateMap2_",i,".csv")
        write.table(sp2@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap3_",i,".csv")
        write.table(sp3@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap4_",i,".csv")
        write.table(sp4@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap5_",i,".csv")
        write.table(sp5@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
      }else if (rs@environment[1]=="sqr70_28"){
        filename = paste0("RateMap1_",i,".csv")
        write.table(sp1@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE) 
        filename = paste0("RateMap2_",i,".csv")
        write.table(sp2@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap3_",i,".csv")
        write.table(sp3@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap4_",i,".csv")
        write.table(sp4@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
        filename = paste0("RateMap5_",i,".csv")
        write.table(sp5@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
      }
    }
  }else{
    if(rs@environment[1]=="sqr70_55b"){
      filename = paste0("RateMap1_",i,".csv")
      write.table(sp1@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE) 
      filename = paste0("RateMap2_",i,".csv")
      write.table(sp2@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
      filename = paste0("RateMap3_",i,".csv")
      write.table(sp3@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
      filename = paste0("RateMap4_",i,".csv")
      write.table(sp4@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
      filename = paste0("RateMap5_",i,".csv")
      write.table(sp5@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
    }else{
      filename = paste0("RateMap1_",i,".csv")
      write.table(sp1@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE) 
      filename = paste0("RateMap2_",i,".csv")
      write.table(sp2@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
      filename = paste0("RateMap3_",i,".csv")
      write.table(sp3@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
      filename = paste0("RateMap4_",i,".csv")
      write.table(sp4@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
      filename = paste0("RateMap5_",i,".csv")
      write.table(sp5@maps[1:35,1:35,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
    }
  }
  }
}

runOnSessionList(ep, sessionList = rss, fnct = GenerateDataForMatlab, rotation=T)


#######################################################################################################################################################
##### LEC 2 box subset 1
library(relectro)
library(scales)

ep<-new("ElectroProject",directory="/data/projects/Global_Remapping/LEC_2box_subset1/")
ep<-setSessionList(ep)
save(ep,file=paste(ep@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep@resultsDirectory,"ep",sep="/"))
rss<-getSessionList(ep,clustered=T)


GenerateDataForMatlab2<-function(rs){
  print(rs@session)
  source('~/source_scripts/Positrack.R')
  myList = getRecSessionObjects(rs)
  cg = myList$cg
  pt = myList$pt
  st = myList$st
  sp = myList$sp
  hd = myList$hd
  
  ## so that pixels in different sp objects align
  sp@reduceSize=FALSE 
  
  ## Apply speed filter
  pt<-speedFilter(pt,minSpeed=3,maxSpeed = 80)
  
  #make coordinates match between the rooms and go from 0,70 (cm)
  pt_positrack <- setInvalidOutsideInterval(pt, s=rs@trialStartRes[c(1,3,5,7,9)], e=rs@trialEndRes[c(1,3,5,7,9)])
  int_posi <- data.frame(start=rs@trialStartRes[c(1,3,5,7,9)], end=rs@trialEndRes[c(1,3,5,7,9)])
  pt_posib <- pt_positrack
  for (interval in 1:length(int_posi[,1])){
    pt_posib@x <- pt_positrack@x[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@y <- pt_positrack@y[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@xWhl <- pt_positrack@xWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@yWhl <- pt_positrack@yWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt@x[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@x))] <- rescale(pt_posib@x[!is.na(pt_posib@x)], to = c(0,70), from=range(pt_posib@x, na.rm = T))
    pt@y[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@y))] <- rescale(pt_posib@y[!is.na(pt_posib@y)], to = c(0,70), from=range(pt_posib@y, na.rm = T))
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@xWhl[which(pt_posib@xWhl>=0)], to = c(0, 700), from=range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T))
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@yWhl[which(pt_posib@yWhl>=0)], to = c(0, 700), from=range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T))
  }
  #rescale the rest box trials, use the range from one the OF trials to appropriately do so.
  int_hc <- data.frame(start=rs@trialStartRes[c(2,4,6,8)], end=rs@trialEndRes[c(2,4,6,8)])
  pt_hc <- setInvalidOutsideInterval(pt, s=int_hc[,1],e=int_hc[,2])
  x_save <- range(pt_posib@x, na.rm = T)
  y_save <- range(pt_posib@y, na.rm = T)
  xw_save <- range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T)
  yw_save <- range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T)
  for (t in 1:nrow(int_hc)){
    #get x and y values of trial number t (of the OF trials in room 55)
    x <- pt_hc@x[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    y <- pt_hc@y[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    xWhl <- pt_hc@xWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    yWhl <- pt_hc@yWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    pt@x[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=x_save)
    pt@y[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=y_save)
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=xw_save)
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=yw_save)
  }
  rm(x, y, yWhl, xWhl, pt_hc, int_hc, int_posi, pt_posib, pt_positrack) #free some memory
  
  print(paste('min x_cm:', min(pt@x, na.rm = T),'; max x_cm:', max(pt@x, na.rm = T)))
  print(paste('min y_cm:', min(pt@y, na.rm = T),'; max y_cm:', max(pt@y, na.rm = T)))
  
  ### IMPORTANT: recalculate speed after rescaling ## 
  ## get the speed from position
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  pt@speed[which(pt@speed==(-1.0))] <- NA
  
  
  ## Get positrack objects for the 5 open field trials
  ptsqr70.1<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[1], e=rs@trialEndRes[1])
  ptsqr70.1<-speedFilter(ptsqr70.1,minSpeed=3,maxSpeed = 80)
  
  ptsqr70.2<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[3], e=rs@trialEndRes[3])
  ptsqr70.2<-speedFilter(ptsqr70.2,minSpeed=3,maxSpeed = 80)
  
  ptsqr70.3<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[5], e=rs@trialEndRes[5])
  ptsqr70.3<-speedFilter(ptsqr70.3,minSpeed=3,maxSpeed = 80)
  
  ptsqr70.4<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[7], e=rs@trialEndRes[7])
  ptsqr70.4<-speedFilter(ptsqr70.4,minSpeed=3,maxSpeed = 80)
  
  ptsqr70.5<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[9], e=rs@trialEndRes[9])
  ptsqr70.5<-speedFilter(ptsqr70.5,minSpeed=3,maxSpeed = 80)
  ###
  
  ##get st objects for each sqr70 env
  st1<-setIntervals(st=st,s=rs@trialStartRes[1],e=rs@trialEndRes[1])
  st2<-setIntervals(st=st,s=rs@trialStartRes[3],e=rs@trialEndRes[3])
  st3<-setIntervals(st=st,s=rs@trialStartRes[5],e=rs@trialEndRes[5])
  st4<-setIntervals(st=st,s=rs@trialStartRes[7],e=rs@trialEndRes[7])
  st5<-setIntervals(st=st,s=rs@trialStartRes[9],e=rs@trialEndRes[9])
  ##
  
  #calculate firing rate maps
  sp1<-firingRateMap2d(sp,st1,ptsqr70.1, nRowMap = 37,nColMap = 37)
  sp2<-firingRateMap2d(sp,st2,ptsqr70.2, nRowMap = 37,nColMap = 37)
  sp3<-firingRateMap2d(sp,st3,ptsqr70.3, nRowMap = 37,nColMap = 37)
  sp4<-firingRateMap2d(sp,st4,ptsqr70.4, nRowMap = 37,nColMap = 37)
  sp5<-firingRateMap2d(sp,st5,ptsqr70.5, nRowMap = 37,nColMap = 37)
  
  protocol <- 'aabba'
  
  #rotate 180° bc it was recorded in room 55
  sp1 <- firingRateMapsRotation(sp1, 180)
  sp2 <- firingRateMapsRotation(sp2, 180)
  sp3 <- firingRateMapsRotation(sp3, 180)
  sp4 <- firingRateMapsRotation(sp4, 180)
  sp5 <- firingRateMapsRotation(sp5, 180)
  
  ################################################################################################################################
  datadir = "~/LEC_remapping/"
  subdir =  "MapsMatlab_LEC_2box_subset1"
  subdir2 =  rs@session  
  setwd(datadir)
  
  if (file.exists(subdir)){
    setwd(file.path(datadir, subdir))
  } else {
    dir.create(file.path(datadir, subdir))
    
    setwd(file.path(datadir, subdir))
  }
  
  datadir2 = getwd()
  dir.create(subdir2)
  
  if (file.exists(subdir2)){
    setwd(subdir2)
  } else {
    dir.create(subdir2)
    setwd(subdir2)
  }
  #################################################################################################################################
  
  #Binned rate maps
  #eliminate -1 rows
  for (i in 1:length(cg@clu)){
    filename = paste0("RateMap1_",i,".csv")
    write.table(sp1@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE) 
    filename = paste0("RateMap2_",i,".csv")
    write.table(sp2@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
    filename = paste0("RateMap3_",i,".csv")
    write.table(sp3@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
    filename = paste0("RateMap4_",i,".csv")
    write.table(sp4@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
    filename = paste0("RateMap5_",i,".csv")
    write.table(sp5@maps[3:37,3:37,i], filename, sep="\t", row.names = FALSE, col.names = FALSE)
  }
  #create a file with the protocol order
  write.table(data.frame(cid=cg@id, protocol=protocol), paste0("cid_list.csv"), row.names = F, col.names = F)
  
}


runOnSessionList(ep, sessionList = rss, fnct = GenerateDataForMatlab2)


