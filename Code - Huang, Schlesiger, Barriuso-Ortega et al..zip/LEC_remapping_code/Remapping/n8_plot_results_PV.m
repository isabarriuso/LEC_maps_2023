%load all datasets
datadir = "~/LEC_remapping/results/";
load(strcat(datadir,"PV_results_LEC_2box_disc.mat"), "PV23", "PV12", "PV34", "PV45", "PV15")
PV12_LEC2bxa = PV12;
PV23_LEC2bxa = PV23;
PV34_LEC2bxa = PV34;
PV45_LEC2bxa = PV45;
PV15_LEC2bxa = PV15;

load(strcat(datadir,"PV_results_CA1_2box_disc.mat"), "PV23", "PV12", "PV34", "PV45","PV15")
PV12_CA12b = PV12;
PV23_CA12b = PV23;
PV34_CA12b = PV34;
PV45_CA12b = PV45;
PV15_CA12b = PV15;

load(strcat(datadir,"PV_results_LEC_2room_disc.mat"), "PV23", "PV12", "PV34", "PV45", "PV15")
PV12_LEC2r = PV12;
PV23_LEC2r = PV23;
PV34_LEC2r = PV34;
PV45_LEC2r = PV45;
PV15_LEC2r = PV15;

load(strcat(datadir,"PV_results_CA1_2room_disc.mat"), "PV23", "PV12", "PV34", "PV45", "PV15")
PV12_CA12r = PV12;
PV23_CA12r = PV23;
PV34_CA12r = PV34;
PV45_CA12r = PV45;
PV15_CA12r = PV15;

%% plot PV correlation
figure;
subplot(2,3,2);
bar([nanmean(PV12_CA12r.PVcorr), nanmean(PV23_CA12r.PVcorr), nanmean(PV34_CA12r.PVcorr), nanmean(PV45_CA12r.PVcorr), nanmean(PV15_CA12r.PVcorr)])
title("CA1 2 room"); ylim([0,1]);
subplot(2,3,1);
bar([nanmean(PV12_CA12b.PVcorr), nanmean(PV23_CA12b.PVcorr), nanmean(PV34_CA12b.PVcorr), nanmean(PV45_CA12b.PVcorr), nanmean(PV15_CA12b.PVcorr)])
title("CA1 2 box"); ylim([0,1]);
subplot(2,3,4);
bar([nanmean(PV12_LEC2r.PVcorr), nanmean(PV23_LEC2r.PVcorr), nanmean(PV34_LEC2r.PVcorr), nanmean(PV45_LEC2r.PVcorr),nanmean(PV15_LEC2r.PVcorr)])
title("LEC 2 room");ylim([0,1]);
subplot(2,3,3);
bar([nanmean(PV12_LEC2bxa.PVcorr), nanmean(PV23_LEC2bxa.PVcorr), nanmean(PV34_LEC2bxa.PVcorr), nanmean(PV45_LEC2bxa.PVcorr), nanmean(PV15_LEC2bxa.PVcorr)])
title("LEC 2 box");ylim([0,1]);
