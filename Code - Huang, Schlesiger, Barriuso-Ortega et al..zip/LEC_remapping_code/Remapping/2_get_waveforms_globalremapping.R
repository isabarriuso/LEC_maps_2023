library(relectro)

ep1<-new("ElectroProject",directory="/data/projects/Global_Remapping/LEC_2room/")
ep1<-setSessionList(ep1)
save(ep1,file=paste(ep1@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep1@resultsDirectory,"ep",sep="/"))
rss1<-getSessionList(ep1,clustered=T)
rss1<-sortRecSessionListChronologically(rss1)
sessionList <- sessionNamesFromSessionList(rss1)

ep2<-new("ElectroProject",directory="/data/projects/Global_Remapping/CA1_2room/")
ep2<-setSessionList(ep2)
save(ep2,file=paste(ep2@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep2@resultsDirectory,"ep",sep="/"))
rss2<-getSessionList(ep2,clustered=T)
rss2<-sortRecSessionListChronologically(rss2)

ep3<-new("ElectroProject",directory="/data/projects/Global_Remapping/LEC_2box/")
#ep3<-new("ElectroProject",directory="/data/projects/Global_Remapping/LEC_ctrl/")
ep3<-setSessionList(ep3)
save(ep3,file=paste(ep3@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep3@resultsDirectory,"ep",sep="/"))
rss3<-getSessionList(ep3,clustered=T)
rss3<-sortRecSessionListChronologically(rss3)

ep3b<-new("ElectroProject",directory="/data/projects/Global_Remapping/LEC_2box_subset1/") 
ep3b<-setSessionList(ep3b)
save(ep3b,file=paste(ep3b@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep3b@resultsDirectory,"ep",sep="/"))
rss3b<-getSessionList(ep3b,clustered=T)
rss3b<-sortRecSessionListChronologically(rss3b)

ep4<-new("ElectroProject",directory="/data/projects/Global_Remapping/CA1_2box/")
#ep4<-new("ElectroProject",directory="/data/projects/Global_Remapping/CA1_ctrl/")
ep4<-setSessionList(ep4)
save(ep4,file=paste(ep4@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep4@resultsDirectory,"ep",sep="/"))
rss4<-getSessionList(ep4,clustered=T)
rss4<-sortRecSessionListChronologically(rss4)

#choose one
ep <- ep1
rss <- rss1
rm(ep1,rss1)

start.time <- Sys.time()
print(start.time)

source('~/source_scripts/meanwaveform_int.R')
source("~/source_scripts/Positrack.R")

wfs.sham=list()
cell_ids=vector()

#Do this for all sessions 
for (i in 1:length(rss)) {
  rs=rss[[i]]
  print(i)
  print(rs@session)
  myList<-getRecSessionObjects(rs)
  st<-myList$st
  cg<-myList$cg
  df<-myList$df
  sw<-new("SpikeWaveform",session=rs@session)
  
  st.sham <- setIntervals(st, rs@trialStartRes[2], rs@trialEndRes[2]) #for ep3b: st.sham <- setIntervals(st, rs@trialStartRes[1], rs@trialEndRes[1]) 
  
  sw@wfMsPerBin<-.01
  
  for (clu in 1:length(cg@id)){
    if (length(which(st.sham@res[which(st.sham@clu==clu+1)] >= st.sham@startInterval & st.sham@res[which(st.sham@clu==clu+1)] <= st.sham@endInterval)==T)<2){
      print(paste("removing clu:", cg@id[clu], sep=" "))
      st.sham <- setCellList(st.sham, cellList = st.sham@cellList[which(st.sham@cellList!=clu+1)])
      cg@id <- cg@id[-clu]
      cg@clu <- cg@clu[-clu]
    }
  }
  sw.sham<-meanWaveform_int(sw,rs,st.sham,cg,df,filter=T)
  
   for(clu in cg@id){
     wf.sham<-sw.sham@wf[,sw.sham@wfCluId==clu]
     wfs.sham[[length(wfs.sham)+1]]<-wf.sham
     cell_ids[length(cell_ids)+1]<-clu
   }
  save(wfs.sham,file=paste(ep@resultsDirectory, "waveforms/Waveforms_part.Rdata", sep = "/"))
  save(cell_ids,file=paste(ep@resultsDirectory, "waveforms/cell_id_waveforms_part.Rdata", sep = "/"))
  
  rm(rs, st, cg, df, sw, myList)
  rm(st.sham, sw.sham, wf.sham)

}

save(wfs.sham,file=paste(ep@resultsDirectory, "waveforms/Waveforms_all.Rdata", sep = "/"))
save(cell_ids,file=paste(ep@resultsDirectory, "waveforms/cell_id_waveforms_all.Rdata", sep = "/"))

end.time <- Sys.time()
print(paste("Start time:", start.time, sep = " "))
print(paste("End time:", end.time, sep = " "))
print(paste("Total time:", end.time-start.time, sep = " "))

#########################################################
### spike waveform properties ###########################
#########################################################

cells <- cell_ids
wfs <- wfs.sham

find_peaks <- function (x, m = 3){
  shape <- diff(sign(diff(x, na.pad = FALSE)))
  pks <- sapply(which(shape < 0), FUN = function(i){
    z <- i - m + 1
    z <- ifelse(z > 0, z, 1)
    w <- i + m + 1
    w <- ifelse(w < length(x), w, length(x))
    if(all(x[c(z : i, (i + 2) : w)] <= x[i + 1])) return(i + 1) else return(numeric(0))
  })
  pks <- unlist(pks)
  pks
}

# identify channel with largest spike waveform deflection 
wf.all=sapply(wfs, function(x){x[,which.min(apply(x, 2, min))]})

ttp.duration=c()
ptt.duration=c()
ptp.duration=c()
sasym=c()
spike.max1.time = c()
spike.max2.time = c()
spike.min.time = c()
spike.max1.voltage = c()
spike.max2.voltage = c()
spike.min.voltage = c()
wf.all.sham=c()
tt=seq(-1.475,1.475,.05) ### == sw@wfTimePoints
time=seq(-1,1,0.01)


for (ii in 1:length(wf.all[1,])) {
  y0=approx(x=tt,y=wf.all[,ii],xout = time) 
  voltage=smooth.spline(y0$y,spar=.3)$y
  spike_min=which.min(voltage)
  spike_max2=find_peaks(voltage[spike_min:length(time)])[1]+spike_min-1
  # detect first peak in spike waveform
  n1=((length(time)-1)/4)
  spike_max1=tail(find_peaks(voltage[n1:spike_min]),n=1)+(n1-1)
  # if no clear first peak take saddle point
  if(length(spike_max1)==0){
    spike_max1 = tail(which(diff(diff(voltage[n1:spike_min]))>0),n=1)+(n1-1)
  }
  
  # calculate peak amplitude asymmetry
  a = voltage[spike_max1]
  b = voltage[spike_max2]  
  sasym_before <- length(sasym)
  sasym=c(sasym,(b-a)/(abs(b)+abs(a)))
  sasym_after <- length(sasym)
  
  ####IF no second peak is found: put NA
  
  if(sasym_after - sasym_before != 1){
    print(paste("Problem with", ii, sep = " "))
    sasym=c(sasym,NA)
    ttp.duration=c(ttp.duration,NA)
    ptt.duration=c(ptt.duration,NA)
    ptp.duration=c(ptp.duration,NA)
    wf.all.sham=rbind(wf.all.sham,voltage)
    spike.max1.time=c(spike.max1.time,NA)
    spike.max2.time=c(spike.max2.time,NA)
    spike.min.time=c(spike.min.time,NA)
    spike.max1.voltage=c(spike.max1.voltage,NA)
    spike.max2.voltage=c(spike.max2.voltage,NA)
    spike.min.voltage=c(spike.min.voltage,NA)
  } else{
    
    # calculate trough-to-peak duration + more
    ttp.duration =c(ttp.duration,time[spike_max2]-time[spike_min])
    ptt.duration = c(ptt.duration, time[spike_min]-time[spike_max1])
    ptp.duration = c(ptp.duration, time[spike_max2]- time[spike_max1])
    wf.all.sham=rbind(wf.all.sham,voltage)
    
    #collect all values
    spike.max1.time = c(spike.max1.time,time[spike_max1])
    spike.max2.time = c(spike.max2.time,time[spike_max2])
    spike.min.time  = c(spike.min.time, time[spike_min])
    spike.max1.voltage = c(spike.max1.voltage,voltage[spike_max1])
    spike.max2.voltage = c(spike.max2.voltage, voltage[spike_max2])
    spike.min.voltage = c(spike.min.voltage, voltage[spike_min])
  }
}


waveform.data.sham <- data.frame(cell.id = cells[1:length(wf.all[1,])],
                                 trough.to.peak.duration =ttp.duration,
                                 peak.to.trough.duration=ptt.duration,
                                 peak.to.peak.duration=ptp.duration,
                                 spike.asymmetry = sasym,
                                 spike.max1.time = spike.max1.time,
                                 spike.max2.time = spike.max2.time,
                                 spike.min.time = spike.min.time,
                                 spike.max1.voltage = spike.max1.voltage,
                                 spike.max2.voltage = spike.max2.voltage,
                                 spike.min.voltage = spike.min.voltage)

save(file=paste(ep@resultsDirectory,"Waveform.stats.RData",sep=""),time,wf.all.sham,waveform.data.sham)

rm(wf.all, wf.all.sham, wfs, wfs.sham, y0, a, b, ptp.duration, ptt.duration, ttp.duration, sasym, sasym_after, sasym_before, 
   spike_max1, spike_max2, spike_min, spike.max1.time, spike.max1.voltage, spike.max2.time, spike.max2.voltage,
   spike.min.time, spike.min.voltage, time, tt, voltage)

# # add spike waveform to summary table
cells_all <- read.csv("~/LEC_remapping/results/cells_allLEC_2room.csv", header = T) #change accordingly
load(file=paste(ep@resultsDirectory,"Waveform.stats.RData",sep=""))

waveform.data.sham$cell.id <- factor(waveform.data.sham$cell.id, levels = levels(cells_all$cell.id))

All_Sta_wv <- cells_all
All_Sta_wv[,names(waveform.data.sham)[-1]] <- NA
for (cid in 1:length(waveform.data.sham$cell.id)){
  print(cid)
  for (param in names(waveform.data.sham)[-1]){
    All_Sta_wv[which(All_Sta_wv$cell.id==waveform.data.sham$cell.id[cid]), param] <- waveform.data.sham[cid, param]
  }
}

write.csv(All_Sta_wv, file="~/LEC_remapping/results/cells_allLEC_2room_wv.csv", row.names = F) # change accordingly

#get all spatial neurons for matlab shuffling analysis
## load all datasets
cells_all1 <- read.csv("~/LEC_remapping/results/cells_allLEC_2room_wv.csv", header = T)
cells_all1$paradigm <- '2_room_LEC'
cells_all2 <- read.csv("~/LEC_remapping/results/cells_allCA1_2room_wv.csv", header = T)
cells_all2$paradigm <- '2_room_CA1'
cells_all31 <- read.csv("~/LEC_remapping/results/cells_allLEC_2box_wv.csv", header = T)
cells_all32 <- read.csv("~/LEC_remapping/results/cells_allLEC_2box_subset1_wv.csv", header = T)
cells_all3 <- rbind(cells_all31, cells_all32)
cells_all3$paradigm <- '2_box_LEC'
cells_all4 <- read.csv("~/LEC_remapping/results/cells_allCA1_2box_wv.csv", header = T)
cells_all4$paradigm <- '2_box_CA1'

cells_all <- rbind(cells_all1, cells_all2, cells_all3, cells_all4)

cells_all$MFR_A1 <- NA
cells_all$MFR_A2 <- NA
cells_all$MFR_W1 <- NA
cells_all$MFR_W2 <- NA
cells_all$shuff.MS_A1 <- NA
cells_all$shuff.MS_A2 <- NA
cells_all$shuff.MS_W1 <- NA
cells_all$shuff.MS_W2 <- NA
# add across and within shuff map stability depending on the protocol
for (i in 1:length(cells_all$cell.id)){
  if (cells_all$protocol[i]=="aabba"){
    cells_all$shuff.MS_A1[i] <-cells_all$shuff.MS_S23[i]
    cells_all$shuff.MS_A2[i] <-cells_all$shuff.MS_S45[i]
    cells_all$shuff.MS_W1[i] <-cells_all$shuff.MS_S12[i]
    cells_all$shuff.MS_W2[i] <-cells_all$shuff.MS_S34[i]
    cells_all$MFR_A1[i] <- (cells_all$MFR_S2[i]-cells_all$MFR_S3[i])/(cells_all$MFR_S2[i]+cells_all$MFR_S3[i])
    cells_all$MFR_A2[i] <- (cells_all$MFR_S4[i]-cells_all$MFR_S5[i])/(cells_all$MFR_S4[i]+cells_all$MFR_S5[i])
    cells_all$MFR_W1[i] <- (cells_all$MFR_S1[i]-cells_all$MFR_S2[i])/(cells_all$MFR_S1[i]+cells_all$MFR_S2[i])
    cells_all$MFR_W2[i] <- (cells_all$MFR_S3[i]-cells_all$MFR_S4[i])/(cells_all$MFR_S3[i]+cells_all$MFR_S4[i])
  }else if (cells_all$protocol[i]=="abbaa"){
    cells_all$shuff.MS_A1[i] <-cells_all$shuff.MS_S12[i]
    cells_all$shuff.MS_A2[i] <-cells_all$shuff.MS_S34[i]
    cells_all$shuff.MS_W1[i] <-cells_all$shuff.MS_S23[i]
    cells_all$shuff.MS_W2[i] <-cells_all$shuff.MS_S45[i]
    cells_all$MFR_A1[i] <- (cells_all$MFR_S1[i]-cells_all$MFR_S2[i])/(cells_all$MFR_S1[i]+cells_all$MFR_S2[i])
    cells_all$MFR_A2[i] <- (cells_all$MFR_S3[i]-cells_all$MFR_S4[i])/(cells_all$MFR_S3[i]+cells_all$MFR_S4[i])
    cells_all$MFR_W1[i] <- (cells_all$MFR_S2[i]-cells_all$MFR_S3[i])/(cells_all$MFR_S2[i]+cells_all$MFR_S3[i])
    cells_all$MFR_W2[i] <- (cells_all$MFR_S4[i]-cells_all$MFR_S5[i])/(cells_all$MFR_S4[i]+cells_all$MFR_S5[i])
  }
}

## filter excitatory neurons only
cells_all_f <- cells_all[which(cells_all$MFR_S1>0.1 & cells_all$MFR_S2>0.1 & cells_all$MFR_S3>0.1 & cells_all$MFR_S4>0.1 &
                                 cells_all$MFR_S5> 0.1 & cells_all$MFR_S1<5 & cells_all$MFR_S2<5 & cells_all$MFR_S3<5 & cells_all$MFR_S4<5 &
                                 cells_all$MFR_S5<5),]
cells_all_f <- cells_all_f[which(cells_all_f$trough.to.peak.duration>0.4 & cells_all_f$spike.asymmetry<0.1),]

#filter spatial neurons only
cells_all_a <- cells_all_f[which(cells_all_f$protocol=='aabba' & (((cells_all_f$IS_S1sh < cells_all_f$IS_S1 & cells_all_f$IS_S2sh < cells_all_f$IS_S2 & cells_all_f$IS_S5sh < cells_all_f$IS_S5) & (cells_all_f$shuff.MS_S11 < cells_all_f$MS_S11 & cells_all_f$shuff.MS_S22 < cells_all_f$MS_S22 & cells_all_f$shuff.MS_S55 < cells_all_f$MS_S55))|
                                                                    ((cells_all_f$IS_S4sh < cells_all_f$IS_S4 & cells_all_f$IS_S3sh < cells_all_f$IS_S3) &(cells_all_f$shuff.MS_S44 < cells_all_f$MS_S44 & cells_all_f$shuff.MS_S33 < cells_all_f$MS_S33)))),]
cells_all_b <- cells_all_f[which(cells_all_f$protocol=='abbaa' & (((cells_all_f$IS_S2sh < cells_all_f$IS_S2 & cells_all_f$IS_S3sh < cells_all_f$IS_S3) &(cells_all_f$shuff.MS_S22 < cells_all_f$MS_S22 & cells_all_f$shuff.MS_S33 < cells_all_f$MS_S33))|
                                                                    ((cells_all_f$IS_S1sh < cells_all_f$IS_S1 &cells_all_f$IS_S4sh < cells_all_f$IS_S4 & cells_all_f$IS_S5sh < cells_all_f$IS_S5) & (cells_all_f$shuff.MS_S11 < cells_all_f$MS_S11 & cells_all_f$shuff.MS_S44 < cells_all_f$MS_S44 & cells_all_f$shuff.MS_S55 < cells_all_f$MS_S55)))),]
cells_all_f <- rbind(cells_all_a, cells_all_b)

#save as csv for shuffling analysis
write.csv(cells_all_f[,c("cell.id", "session")], file = "~/LEC_remapping/results/cid_spatial_remapping.csv")

