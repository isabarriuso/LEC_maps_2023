library(relectro)
library(ggplot2)
library(scales)
library(gridBase)
library(grid)
library(vctrs)

ep1<-new("ElectroProject",directory="/data/projects/Global_Remapping/LEC_2room/")
ep1<-setSessionList(ep1)
save(ep1,file=paste(ep1@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep1@resultsDirectory,"ep",sep="/"))
rss1<-getSessionList(ep1,clustered=T)
rss1<-sortRecSessionListChronologically(rss1)
sessionList <- sessionNamesFromSessionList(rss1)

ep2<-new("ElectroProject",directory="/data/projects/Global_Remapping/CA1_2room/")
ep2<-setSessionList(ep2)
save(ep2,file=paste(ep2@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep2@resultsDirectory,"ep",sep="/"))
rss2<-getSessionList(ep2,clustered=T)
rss2<-sortRecSessionListChronologically(rss2)

ep3<-new("ElectroProject",directory="/data/projects/Global_Remapping/LEC_2box/")
#ep3<-new("ElectroProject",directory="/data/projects/Global_Remapping/LEC_ctrl/")
ep3<-setSessionList(ep3)
save(ep3,file=paste(ep3@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep3@resultsDirectory,"ep",sep="/"))
rss3<-getSessionList(ep3,clustered=T)
rss3<-sortRecSessionListChronologically(rss3)

ep3b<-new("ElectroProject",directory="/data/projects/Global_Remapping/LEC_2box_subset1/") 
ep3b<-setSessionList(ep3b)
save(ep3b,file=paste(ep3b@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep3b@resultsDirectory,"ep",sep="/"))
rss3b<-getSessionList(ep3b,clustered=T)
rss3b<-sortRecSessionListChronologically(rss3b)

ep4<-new("ElectroProject",directory="/data/projects/Global_Remapping/CA1_2box/")
#ep4<-new("ElectroProject",directory="/data/projects/Global_Remapping/CA1_ctrl/")
ep4<-setSessionList(ep4)
save(ep4,file=paste(ep4@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep4@resultsDirectory,"ep",sep="/"))
rss4<-getSessionList(ep4,clustered=T)
rss4<-sortRecSessionListChronologically(rss4)

source('~/source_scripts/MapCorrShuffle.R')
source('~/source_scripts/MapInfoShuffle.R')
source('~/source_scripts/Positrack.R')

rotationCorrelation <- function(rs, rotation=T, stepsize=10){
  print(rs@session)
  ## load the data in R
  myList<-getRecSessionObjects(rs)
  st<-myList$st
  pt<-myList$pt
  cg<-myList$cg
  sp<-myList$sp
  
  #make coordinates match between the rooms and go from 0,70 (cm)
  pt_positrack <- setInvalidOutsideInterval(pt, s=rs@trialStartRes[c(2,4,6,8,10)], e=rs@trialEndRes[c(2,4,6,8,10)])
  int_posi <- data.frame(start=rs@trialStartRes[c(2,4,6,8,10)], end=rs@trialEndRes[c(2,4,6,8,10)])
  pt_posib <- pt_positrack
  for (interval in 1:length(int_posi[,1])){
    pt_posib@x <- pt_positrack@x[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@y <- pt_positrack@y[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@xWhl <- pt_positrack@xWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@yWhl <- pt_positrack@yWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt@x[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@x))] <- rescale(pt_posib@x[!is.na(pt_posib@x)], to = c(0,70), from=range(pt_posib@x, na.rm = T))
    pt@y[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@y))] <- rescale(pt_posib@y[!is.na(pt_posib@y)], to = c(0,70), from=range(pt_posib@y, na.rm = T))
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@xWhl[which(pt_posib@xWhl>=0)], to = c(0, 700), from=range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T))
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@yWhl[which(pt_posib@yWhl>=0)], to = c(0, 700), from=range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T))
  }
  #rescale the rest box trials, use the range from one the OF trials to appropriately do so.
  int_hc <- data.frame(start=rs@trialStartRes[c(1,3,5,7,9,11)], end=rs@trialEndRes[c(1,3,5,7,9,11)])
  pt_hc <- setInvalidOutsideInterval(pt, s=int_hc[,1],e=int_hc[,2])
  x_save <- range(pt_posib@x, na.rm = T)
  y_save <- range(pt_posib@y, na.rm = T)
  xw_save <- range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T)
  yw_save <- range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T)
  for (t in 1:nrow(int_hc)){
    #get x and y values of trial number t (of the OF trials in room 55)
    x <- pt_hc@x[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    y <- pt_hc@y[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    xWhl <- pt_hc@xWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    yWhl <- pt_hc@yWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    pt@x[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=x_save)
    pt@y[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=y_save)
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=xw_save) 
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=yw_save)
  }
  rm(x, y, yWhl, xWhl, pt_hc, int_hc, int_posi, pt_posib, pt_positrack) #free some memory
  
  print(paste('min x_cm:', min(pt@x, na.rm = T),'; max x_cm:', max(pt@x, na.rm = T)))
  print(paste('min y_cm:', min(pt@y, na.rm = T),'; max y_cm:', max(pt@y, na.rm = T)))
  
  ### IMPORTANT: recalculate speed after rescaling ## 
  ## get the speed from position
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  pt@speed[which(pt@speed==(-1.0))] <- NA

  # create st objects for each open field trial in the session
  st.s1 <- setIntervals(st, s=rs@trialStartRes[2], e=rs@trialEndRes[2])
  st.s2 <- setIntervals(st, s=rs@trialStartRes[4], e=rs@trialEndRes[4])
  st.s3 <- setIntervals(st, s=rs@trialStartRes[6], e=rs@trialEndRes[6])
  st.s4 <- setIntervals(st, s=rs@trialStartRes[8], e=rs@trialEndRes[8])
  st.s5 <- setIntervals(st, s=rs@trialStartRes[10], e=rs@trialEndRes[10])
  # create a positrack object for each open field trial in the session
  pt.s1<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[2], e=rs@trialEndRes[2])
  pt.s2<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[4], e=rs@trialEndRes[4])
  pt.s3<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[6], e=rs@trialEndRes[6])
  pt.s4<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[8], e=rs@trialEndRes[8])
  pt.s5<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[10], e=rs@trialEndRes[10])
  #filter by speed
  pt.s1<-speedFilter(pt.s1,minSpeed = 3,maxSpeed = 100)
  pt.s2<-speedFilter(pt.s2,minSpeed = 3,maxSpeed = 100)
  pt.s3<-speedFilter(pt.s3,minSpeed = 3,maxSpeed = 100)
  pt.s4<-speedFilter(pt.s4,minSpeed = 3,maxSpeed = 100)
  pt.s5<-speedFilter(pt.s5,minSpeed = 3,maxSpeed = 100)
  
  # Create firing rate maps for each cell of the list in each open field trial #
  sp.s1<-firingRateMap2d(sp,st.s1,pt.s1, nRowMap = 37, nColMap = 37)
  sp.s2<-firingRateMap2d(sp,st.s2,pt.s2, nRowMap = 37, nColMap = 37)
  sp.s3<-firingRateMap2d(sp,st.s3,pt.s3, nRowMap = 37, nColMap = 37)
  sp.s4<-firingRateMap2d(sp,st.s4,pt.s4, nRowMap = 37, nColMap = 37)
  sp.s5<-firingRateMap2d(sp,st.s5,pt.s5, nRowMap = 37, nColMap = 37)
  sp.s1@reduceSize <- F
  sp.s2@reduceSize <- F
  sp.s3@reduceSize <- F
  sp.s4@reduceSize <- F
  sp.s5@reduceSize <- F
  
  # rotate 180° those maps from the other room
  if(rs@environment[2]==rs@environment[4]){
    protocol <- 'aabba'
    if(rotation==T){
      sp.s3<-firingRateMapsRotation(sp.s3,180)
      sp.s4<-firingRateMapsRotation(sp.s4,180)
    }
  }else if(rs@environment[2]==rs@environment[8]){
    protocol <- 'abbaa'
    if(rotation==T){
      sp.s2<-firingRateMapsRotation(sp.s2,180)
      sp.s3<-firingRateMapsRotation(sp.s3,180)
    }
  }
  
  print("across session spatial correlations...")
  MS_S12_0 <- firingRateMapCorrelation(sp.s1, sp.s2)
  MS_S13_0 <- firingRateMapCorrelation(sp.s1, sp.s3)
  MS_S14_0 <- firingRateMapCorrelation(sp.s1, sp.s4)
  MS_S15_0 <- firingRateMapCorrelation(sp.s1, sp.s5)
  MS_S23_0 <- firingRateMapCorrelation(sp.s2, sp.s3)
  MS_S24_0 <- firingRateMapCorrelation(sp.s2, sp.s4)
  MS_S25_0 <- firingRateMapCorrelation(sp.s2, sp.s5)
  MS_S34_0 <- firingRateMapCorrelation(sp.s3, sp.s4)
  MS_S35_0 <- firingRateMapCorrelation(sp.s3, sp.s5)
  MS_S45_0 <- firingRateMapCorrelation(sp.s4, sp.s5)
  
  if(protocol=="aabba"){
    MS_A1_0<-MS_S23_0
    MS_A2_0<-MS_S45_0
    MS_W1_0<-MS_S12_0
    MS_W2_0<-MS_S34_0
  }else if (protocol=="abbaa"){
    MS_A1_0<-MS_S12_0
    MS_A2_0<-MS_S34_0
    MS_W1_0<-MS_S23_0
    MS_W2_0<-MS_S45_0
  }
  
  #for 10°steps
  correlation_rotation <- data.frame(mouse=rs@animalName, session=rs@session, cell.id=cg@id[st.s1@cellList-1],tetrode.id=cg@tetrode[st.s1@cellList-1],region=cg@brainRegion[st.s1@cellList-1],
                                     clu.to.tet=cg@cluToTetrode[st.s1@cellList-1], protocol=protocol, MS_A1=MS_A1_0, MS_A2=MS_A2_0, MS_W1=MS_W1_0, MS_W2=MS_W2_0, rotation_angle=rep('0°',length(cg@id[st.s1@cellList-1])))
  
  
  for (deg in seq(0+stepsize,360-stepsize,stepsize)){
    sp.s1tmp <- firingRateMapsRotation(sp.s1, deg)
    MS_S12 <- firingRateMapCorrelation(sp.s1tmp, sp.s2)
    MS_S13 <- firingRateMapCorrelation(sp.s1tmp, sp.s3)
    MS_S14 <- firingRateMapCorrelation(sp.s1tmp, sp.s4)
    MS_S15 <- firingRateMapCorrelation(sp.s1tmp, sp.s5)
    sp.s2tmp <- firingRateMapsRotation(sp.s2, deg)
    MS_S23 <- firingRateMapCorrelation(sp.s2tmp, sp.s3)
    MS_S24 <- firingRateMapCorrelation(sp.s2tmp, sp.s4)
    MS_S25 <- firingRateMapCorrelation(sp.s2tmp, sp.s5)
    sp.s3tmp <- firingRateMapsRotation(sp.s3, deg)
    MS_S34 <- firingRateMapCorrelation(sp.s3tmp, sp.s4)
    MS_S35 <- firingRateMapCorrelation(sp.s3tmp, sp.s5)
    sp.s4tmp <- firingRateMapsRotation(sp.s4, deg)
    MS_S45 <- firingRateMapCorrelation(sp.s4tmp, sp.s5)
    
    if(protocol=="aabba"){
      MS_A1<-MS_S23
      MS_A2<-MS_S45
      MS_W1<-MS_S12
      MS_W2<-MS_S34
    }else if (protocol=="abbaa"){
      MS_A1<-MS_S12
      MS_A2<-MS_S34
      MS_W1<-MS_S23
      MS_W2<-MS_S45
    }
    correlation_rotationtmp <- data.frame(mouse=rs@animalName, session=rs@session, cell.id=cg@id[st.s1@cellList-1],tetrode.id=cg@tetrode[st.s1@cellList-1],region=cg@brainRegion[st.s1@cellList-1],
                                          clu.to.tet=cg@cluToTetrode[st.s1@cellList-1], protocol=protocol, MS_A1=MS_A1, MS_A2=MS_A2, MS_W1=MS_W1, MS_W2=MS_W2, rotation_angle=rep(paste(deg,'°',sep=""),length(cg@id[st.s1@cellList-1])))
    
    correlation_rotation <- rbind(correlation_rotation, correlation_rotationtmp)
  }
  
  results <-list(correlation_rotation=correlation_rotation)
  names(results) <- c("correlation_rotation")
  return(results)
}

######### 2 box LEC subset1 #######
rotationCorrelation_subset1 <- function(rs, rotation=F, stepsize=10){
  print(rs@session)
  myList<-getRecSessionObjects(rs)
  st<-myList$st
  pt<-myList$pt
  cg<-myList$cg
  sp<-myList$sp
  
  #make coordinates match between the rooms and go from 0,70 (cm)
  pt_positrack <- setInvalidOutsideInterval(pt, s=getIntervalsEnvironment(rs, environment = "sqr70"))
  int_posi <- data.frame(start=getIntervalsEnvironment(rs, environment = "sqr70")[,1], end=getIntervalsEnvironment(rs, environment = "sqr70")[,2])
  pt_posib <- pt_positrack
  #print(int_posi)
  for (interval in 1:length(int_posi[,1])){
    pt_posib@x <- pt_positrack@x[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@y <- pt_positrack@y[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@xWhl <- pt_positrack@xWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@yWhl <- pt_positrack@yWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt@x[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@x))] <- rescale(pt_posib@x[!is.na(pt_posib@x)], to = c(0,70), from=range(pt_posib@x, na.rm = T))
    pt@y[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@y))] <- rescale(pt_posib@y[!is.na(pt_posib@y)], to = c(0,70), from=range(pt_posib@y, na.rm = T))
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@xWhl[which(pt_posib@xWhl>=0)], to = c(0, 700), from=range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T))
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@yWhl[which(pt_posib@yWhl>=0)], to = c(0, 700), from=range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T))
  }
  #Rescale the rest box trials, use the range from one the OF trials to appropriately do so.
  int_hc <- data.frame(start=getIntervalsEnvironment(rs, environment = "hc")[,1], end=getIntervalsEnvironment(rs, environment = "hc")[,2])
  pt_hc <- setInvalidOutsideInterval(pt, s=int_hc[,1],e=int_hc[,2])
  x_save <- range(pt_posib@x, na.rm = T)
  y_save <- range(pt_posib@y, na.rm = T)
  xw_save <- range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T)
  yw_save <- range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T)
  for (t in 1:nrow(int_hc)){
    x <- pt_hc@x[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    y <- pt_hc@y[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    xWhl <- pt_hc@xWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    yWhl <- pt_hc@yWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    pt@x[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=x_save)
    pt@y[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=y_save)
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=xw_save)
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=yw_save)
  }
  rm(x, y, yWhl, xWhl, pt_hc, int_hc, int_posi, pt_posib, pt_positrack) #free some memory
  
  ### IMPORTANT: recalculate speed after rescaling ## 
  ## get the speed from position
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  
  pt@speed[which(pt@speed==(-1.0))] <- NA
  
  print(paste('min x_cm:', min(pt@x, na.rm = T),'; max x_cm:', max(pt@x, na.rm = T)))
  print(paste('min y_cm:', min(pt@y, na.rm = T),'; max y_cm:', max(pt@y, na.rm = T)))
  
  # create st objects for each open field trial in the session
  st.s1 <- setIntervals(st, s=rs@trialStartRes[1], e=rs@trialEndRes[1])
  st.s2 <- setIntervals(st, s=rs@trialStartRes[3], e=rs@trialEndRes[3])
  st.s3 <- setIntervals(st, s=rs@trialStartRes[5], e=rs@trialEndRes[5])
  st.s4 <- setIntervals(st, s=rs@trialStartRes[7], e=rs@trialEndRes[7])
  st.s5 <- setIntervals(st, s=rs@trialStartRes[9], e=rs@trialEndRes[9])
  # create a positrack object for each open field trial in the session
  pt.s1<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[1], e=rs@trialEndRes[1])
  pt.s2<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[3], e=rs@trialEndRes[3])
  pt.s3<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[5], e=rs@trialEndRes[5])
  pt.s4<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[7], e=rs@trialEndRes[7])
  pt.s5<-setInvalidOutsideInterval(pt,s=rs@trialStartRes[9], e=rs@trialEndRes[9])
  #filter by speed
  pt.s1<-speedFilter(pt.s1,minSpeed = 3,maxSpeed = 100)
  pt.s2<-speedFilter(pt.s2,minSpeed = 3,maxSpeed = 100)
  pt.s3<-speedFilter(pt.s3,minSpeed = 3,maxSpeed = 100)
  pt.s4<-speedFilter(pt.s4,minSpeed = 3,maxSpeed = 100)
  pt.s5<-speedFilter(pt.s5,minSpeed = 3,maxSpeed = 100)
  
  # Create firing rate maps for each cell of the list in each open field trial #
  sp.s1<-firingRateMap2d(sp,st.s1,pt.s1, nRowMap = 37, nColMap = 37)
  sp.s2<-firingRateMap2d(sp,st.s2,pt.s2, nRowMap = 37, nColMap = 37)
  sp.s3<-firingRateMap2d(sp,st.s3,pt.s3, nRowMap = 37, nColMap = 37)
  sp.s4<-firingRateMap2d(sp,st.s4,pt.s4, nRowMap = 37, nColMap = 37)
  sp.s5<-firingRateMap2d(sp,st.s5,pt.s5, nRowMap = 37, nColMap = 37)
  sp.s1@reduceSize <- F
  sp.s2@reduceSize <- F
  sp.s3@reduceSize <- F
  sp.s4@reduceSize <- F
  sp.s5@reduceSize <- F
  
  # rotate 180° those maps from the other room
  protocol <- 'abbaa'
  
  ## get firing rate map correlations
  print("across session spatial correlations...")
  MS_S12_0 <- firingRateMapCorrelation(sp.s1, sp.s2)
  MS_S13_0 <- firingRateMapCorrelation(sp.s1, sp.s3)
  MS_S14_0 <- firingRateMapCorrelation(sp.s1, sp.s4)
  MS_S15_0 <- firingRateMapCorrelation(sp.s1, sp.s5)
  MS_S23_0 <- firingRateMapCorrelation(sp.s2, sp.s3)
  MS_S24_0 <- firingRateMapCorrelation(sp.s2, sp.s4)
  MS_S25_0 <- firingRateMapCorrelation(sp.s2, sp.s5)
  MS_S34_0 <- firingRateMapCorrelation(sp.s3, sp.s4)
  MS_S35_0 <- firingRateMapCorrelation(sp.s3, sp.s5)
  MS_S45_0 <- firingRateMapCorrelation(sp.s4, sp.s5)
  
  if(protocol=="aabba"){
    MS_A1_0<-MS_S23_0
    MS_A2_0<-MS_S45_0
    MS_W1_0<-MS_S12_0
    MS_W2_0<-MS_S34_0
  }else if (protocol=="abbaa"){
    MS_A1_0<-MS_S12_0
    MS_A2_0<-MS_S34_0
    MS_W1_0<-MS_S23_0
    MS_W2_0<-MS_S45_0
  }
  
  #for 10°steps
  correlation_rotation <- data.frame(mouse=rs@animalName, session=rs@session, cell.id=cg@id[st.s1@cellList-1],tetrode.id=cg@tetrode[st.s1@cellList-1],region=cg@brainRegion[st.s1@cellList-1],
                                     clu.to.tet=cg@cluToTetrode[st.s1@cellList-1], protocol=protocol, MS_A1=MS_A1_0, MS_A2=MS_A2_0, MS_W1=MS_W1_0, MS_W2=MS_W2_0, rotation_angle=rep('0°',length(cg@id[st.s1@cellList-1])))
  
  
  for (deg in seq(0+stepsize,360-stepsize,stepsize)){
    sp.s1tmp <- firingRateMapsRotation(sp.s1, deg)
    MS_S12 <- firingRateMapCorrelation(sp.s1tmp, sp.s2)
    MS_S13 <- firingRateMapCorrelation(sp.s1tmp, sp.s3)
    MS_S14 <- firingRateMapCorrelation(sp.s1tmp, sp.s4)
    MS_S15 <- firingRateMapCorrelation(sp.s1tmp, sp.s5)
    sp.s2tmp <- firingRateMapsRotation(sp.s2, deg)
    MS_S23 <- firingRateMapCorrelation(sp.s2tmp, sp.s3)
    MS_S24 <- firingRateMapCorrelation(sp.s2tmp, sp.s4)
    MS_S25 <- firingRateMapCorrelation(sp.s2tmp, sp.s5)
    sp.s3tmp <- firingRateMapsRotation(sp.s3, deg)
    MS_S34 <- firingRateMapCorrelation(sp.s3tmp, sp.s4)
    MS_S35 <- firingRateMapCorrelation(sp.s3tmp, sp.s5)
    sp.s4tmp <- firingRateMapsRotation(sp.s4, deg)
    MS_S45 <- firingRateMapCorrelation(sp.s4tmp, sp.s5)
    
    if(protocol=="aabba"){
      MS_A1<-MS_S23
      MS_A2<-MS_S45
      MS_W1<-MS_S12
      MS_W2<-MS_S34
    }else if (protocol=="abbaa"){
      MS_A1<-MS_S12
      MS_A2<-MS_S34
      MS_W1<-MS_S23
      MS_W2<-MS_S45
    }
    correlation_rotationtmp <- data.frame(mouse=rs@animalName, session=rs@session, cell.id=cg@id[st.s1@cellList-1],tetrode.id=cg@tetrode[st.s1@cellList-1],region=cg@brainRegion[st.s1@cellList-1],
                                       clu.to.tet=cg@cluToTetrode[st.s1@cellList-1], protocol=protocol, MS_A1=MS_A1, MS_A2=MS_A2, MS_W1=MS_W1, MS_W2=MS_W2, rotation_angle=rep(paste(deg,'°',sep=""),length(cg@id[st.s1@cellList-1])))
    
    correlation_rotation <- rbind(correlation_rotation, correlation_rotationtmp)
  }
  
  results <-list(correlation_rotation=correlation_rotation)
  names(results) <- c("correlation_rotation")
  return(results)
}


#result <-rotationCorrelation(rs)
runOnSessionList(ep1,sessionList=rss1, fnct=rotationCorrelation, save=T,overwrite=T, rotation=T,stepsize=10) 
runOnSessionList(ep2,sessionList=rss2, fnct=rotationCorrelation, save=T,overwrite=T, rotation=T,stepsize=10) 
runOnSessionList(ep3,sessionList=rss3, fnct=rotationCorrelation, save=T,overwrite=T, rotation=F,stepsize=10) 
runOnSessionList(ep3b,sessionList=rss3b, fnct=rotationCorrelation_subset1, save=T,overwrite=T, rotation=F,stepsize=10) 
runOnSessionList(ep4,sessionList=rss4, fnct=rotationCorrelation, save=T,overwrite=T, rotation=F,stepsize=10)



load(paste(ep1@resultsDirectory,"correlation_rotation",sep="/"))
correlation_rotation1 <- correlation_rotation
correlation_rotation1$context <- "2room"
write.csv(correlation_rotation, "~/LEC_remapping/results/correlation_rotationLEC.csv")

load(paste(ep2@resultsDirectory,"correlation_rotation",sep="/"))
correlation_rotation2 <- correlation_rotation
correlation_rotation2$context <- "2room"
write.csv(correlation_rotation, "~/LEC_remapping/results/correlation_rotationCA1.csv")

load(paste(ep3@resultsDirectory,"correlation_rotation",sep="/"))
correlation_rotation3 <- correlation_rotation
correlation_rotation3$context <- "2box"
write.csv(correlation_rotation, "~/LEC_remapping/results/correlation_rotationLECbw.csv")

load(paste(ep3b@resultsDirectory,"correlation_rotation",sep="/"))
correlation_rotation3b <- correlation_rotation
correlation_rotation3b$context <- "2box"
write.csv(correlation_rotation, "~/LEC_remapping/results/correlation_rotationLECbw_subset1.csv")

load(paste(ep4@resultsDirectory,"correlation_rotation",sep="/"))
correlation_rotation4 <- correlation_rotation
correlation_rotation4$context <- "2box"
write.csv(correlation_rotation, "~/LEC_remapping/results/correlation_rotationCA1bw.csv")
