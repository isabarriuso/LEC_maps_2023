
library(ggplot2)
library(ggridges)
library(scales)
library(ggpubr)
library(FSA)


#get all spatial neurons for matlab shuffling analysis
## load all datasets
cells_all1 <- read.csv("~/LEC_remapping/results/cells_allLEC_2room_wv.csv", header = T)
cells_all1$paradigm <- '2_room_LEC'
cells_all2 <- read.csv("~/LEC_remapping/results/cells_allCA1_2room_wv.csv", header = T)
cells_all2$paradigm <- '2_room_CA1'
cells_all31 <- read.csv("~/LEC_remapping/results/cells_allLEC_2box_wv.csv", header = T)
cells_all32 <- read.csv("~/LEC_remapping/results/cells_allLEC_2box_subset1_wv.csv", header = T)
cells_all3 <- rbind(cells_all31, cells_all32)
cells_all3$paradigm <- '2_box_LEC'
cells_all4 <- read.csv("~/LEC_remapping/results/cells_allCA1_2box_wv.csv", header = T)
cells_all4$paradigm <- '2_box_CA1'

cells_all <- rbind(cells_all1, cells_all2, cells_all3, cells_all4)
cells_all$paradigm <- factor(cells_all$paradigm, levels=c('2_room_LEC','2_box_LEC', '2_room_CA1','2_box_CA1'))

cells_all$MFR_A1 <- NA
cells_all$MFR_A2 <- NA
cells_all$MFR_W1 <- NA
cells_all$MFR_W2 <- NA
cells_all$shuff.MS_A1 <- NA
cells_all$shuff.MS_A2 <- NA
cells_all$shuff.MS_W1 <- NA
cells_all$shuff.MS_W2 <- NA
# add across and within shuff map stability depending on the protocol
for (i in 1:length(cells_all$cell.id)){
  if (cells_all$protocol[i]=="aabba"){
    cells_all$shuff.MS_A1[i] <-cells_all$shuff.MS_S23[i]
    cells_all$shuff.MS_A2[i] <-cells_all$shuff.MS_S45[i]
    cells_all$shuff.MS_W1[i] <-cells_all$shuff.MS_S12[i]
    cells_all$shuff.MS_W2[i] <-cells_all$shuff.MS_S34[i]
    cells_all$MFR_A1[i] <- (cells_all$MFR_S2[i]-cells_all$MFR_S3[i])/(cells_all$MFR_S2[i]+cells_all$MFR_S3[i])
    cells_all$MFR_A2[i] <- (cells_all$MFR_S4[i]-cells_all$MFR_S5[i])/(cells_all$MFR_S4[i]+cells_all$MFR_S5[i])
    cells_all$MFR_W1[i] <- (cells_all$MFR_S1[i]-cells_all$MFR_S2[i])/(cells_all$MFR_S1[i]+cells_all$MFR_S2[i])
    cells_all$MFR_W2[i] <- (cells_all$MFR_S3[i]-cells_all$MFR_S4[i])/(cells_all$MFR_S3[i]+cells_all$MFR_S4[i])
  }else if (cells_all$protocol[i]=="abbaa"){
    cells_all$shuff.MS_A1[i] <-cells_all$shuff.MS_S12[i]
    cells_all$shuff.MS_A2[i] <-cells_all$shuff.MS_S34[i]
    cells_all$shuff.MS_W1[i] <-cells_all$shuff.MS_S23[i]
    cells_all$shuff.MS_W2[i] <-cells_all$shuff.MS_S45[i]
    cells_all$MFR_A1[i] <- (cells_all$MFR_S1[i]-cells_all$MFR_S2[i])/(cells_all$MFR_S1[i]+cells_all$MFR_S2[i])
    cells_all$MFR_A2[i] <- (cells_all$MFR_S3[i]-cells_all$MFR_S4[i])/(cells_all$MFR_S3[i]+cells_all$MFR_S4[i])
    cells_all$MFR_W1[i] <- (cells_all$MFR_S2[i]-cells_all$MFR_S3[i])/(cells_all$MFR_S2[i]+cells_all$MFR_S3[i])
    cells_all$MFR_W2[i] <- (cells_all$MFR_S4[i]-cells_all$MFR_S5[i])/(cells_all$MFR_S4[i]+cells_all$MFR_S5[i])
  }
}


#histogram firing rate for FS neurons
ggplot(cells_all[which(cells_all$trough.to.peak.duration<=0.4 & cells_all$spike.asymmetry>=0.1),], mapping = aes(x=MFR, color=paradigm, fill=paradigm))+
  geom_histogram(binwidth = 0.1)+ facet_wrap(.~paradigm)+
  scale_color_manual(values=c('#AA510e', '#F4AE52','#164060', '#50a1d9', 'black','grey'))+
  scale_fill_manual(values=c('#AA510e', '#F4AE52','#164060', '#50a1d9', 'black','grey'))+
  scale_x_log10()+
  geom_vline(xintercept=log10(5), linetype="dashed")+
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

############ excitatory neurons only ##################################
cells_all_f <- cells_all[which(cells_all$MFR_S1>0.1 & cells_all$MFR_S2>0.1 & cells_all$MFR_S3>0.1 & cells_all$MFR_S4>0.1 &
                                 cells_all$MFR_S5> 0.1 & cells_all$MFR_S1<5 & cells_all$MFR_S2<5 & cells_all$MFR_S3<5 & cells_all$MFR_S4<5 &
                                 cells_all$MFR_S5<5),]
cells_all_f <- cells_all_f[which(cells_all_f$trough.to.peak.duration>0.4 & cells_all_f$spike.asymmetry<0.1),]
######################################################################

############### FS neurons ####################
cells_all_f <- cells_all[which(cells_all$MFR_S1>0.1 & cells_all$MFR_S2>0.1 & cells_all$MFR_S3>0.1 & cells_all$MFR_S4>0.1 & cells_all$MFR_S5> 0.1 & 
                                 (cells_all$MFR_S1>=5 & cells_all$MFR_S2>=5 & cells_all$MFR_S3>=5 & cells_all$MFR_S4>=5 & cells_all$MFR_S5>=5) &
                                    (cells_all$trough.to.peak.duration<=0.4 & cells_all$spike.asymmetry>=0.1)),]
################################################

##### spatial neurons only ######################
cells_all_a <- cells_all_f[which(cells_all_f$protocol=='aabba' & (((cells_all_f$IS_S1sh < cells_all_f$IS_S1 & cells_all_f$IS_S2sh < cells_all_f$IS_S2 & cells_all_f$IS_S5sh < cells_all_f$IS_S5) & (cells_all_f$shuff.MS_S11 < cells_all_f$MS_S11 & cells_all_f$shuff.MS_S22 < cells_all_f$MS_S22 & cells_all_f$shuff.MS_S55 < cells_all_f$MS_S55))|
                                                                    ((cells_all_f$IS_S4sh < cells_all_f$IS_S4 & cells_all_f$IS_S3sh < cells_all_f$IS_S3) &(cells_all_f$shuff.MS_S44 < cells_all_f$MS_S44 & cells_all_f$shuff.MS_S33 < cells_all_f$MS_S33)))),]
cells_all_b <- cells_all_f[which(cells_all_f$protocol=='abbaa' & (((cells_all_f$IS_S2sh < cells_all_f$IS_S2 & cells_all_f$IS_S3sh < cells_all_f$IS_S3) &(cells_all_f$shuff.MS_S22 < cells_all_f$MS_S22 & cells_all_f$shuff.MS_S33 < cells_all_f$MS_S33))|
                                                                    ((cells_all_f$IS_S1sh < cells_all_f$IS_S1 &cells_all_f$IS_S4sh < cells_all_f$IS_S4 & cells_all_f$IS_S5sh < cells_all_f$IS_S5) & (cells_all_f$shuff.MS_S11 < cells_all_f$MS_S11 & cells_all_f$shuff.MS_S44 < cells_all_f$MS_S44 & cells_all_f$shuff.MS_S55 < cells_all_f$MS_S55)))),]
cells_all_f <- rbind(cells_all_a, cells_all_b)

# for 2box_LEC_subset1 mice, only take the session with most cells
cells_all_f <- cells_all_f[which( cells_all_f$region=="ca1" | cells_all_f$mouse=="ib5718" | cells_all_f$mouse=="ib5719" | cells_all_f$mouse=="ib5721" |
                                  cells_all_f$mouse=="ib1224" | cells_all_f$session=="ms1323-09092020-0107"|
                                  cells_all_f$session=="ms6769-15012019-0107" |cells_all_f$session=="ms6770-01122018-0107"|
                                  cells_all_f$session=="ms6912-20032019-0107" |cells_all_f$session=="ms7026-04052019-0107"|
                                  cells_all_f$session=="ms7053-05072019-0107" |cells_all_f$session=="ms7866-12032020-0107"|
                                  cells_all_f$session=="ms8089-07082020-0107"),]

#remapping groups
wth <- 0.4271183 #median 95th percentile of W1/W2 shuffled distribution of all 4 datasets 
ath <- 0.4039432 #median 95th percentile of A1/A2 shuffled distribution of all 4 datasets
cells_all_f$disc_group <- "unstable"
cells_all_f$disc_group[which((cells_all_f$A1<ath | cells_all_f$A2<ath) & (cells_all_f$W1>wth | cells_all_f$W2>wth))] <- "discriminating"
cells_all_f$disc_group[which((cells_all_f$A1>ath |cells_all_f$A2>ath) & (cells_all_f$W1>wth | cells_all_f$W2>wth))] <- "stable"

cells_all_f$MFR_W3 <- (cells_all_f$MFR_S1-cells_all_f$MFR_S5)/(cells_all_f$MFR_S1+cells_all_f$MFR_S5)

toplot_f <- rbind(cells_all_f[,1:(length(cells_all_f)-4)],cells_all_f[,1:(length(cells_all_f)-4)],cells_all_f[,1:(length(cells_all_f)-4)],cells_all_f[,1:(length(cells_all_f)-4)],cells_all_f[,1:(length(cells_all_f)-4)])
toplot_f$Stability <- c(cells_all_f$W1, cells_all_f$W2, cells_all_f$A1, cells_all_f$A2, cells_all_f$MS_S15)
toplot_f$ratechange <- c(cells_all_f$MFR_W1, cells_all_f$MFR_W2, cells_all_f$MFR_A1, cells_all_f$MFR_A2, cells_all_f$MFR_W3)
toplot_f$absratechange <- abs(toplot_f$ratechange)
toplot_f$disc_group <-  c(cells_all_f$disc_group, cells_all_f$disc_group, cells_all_f$disc_group, cells_all_f$disc_group, cells_all_f$disc_group)
toplot_f$stab_group <- c(rep('W1', length(cells_all_f$cell.id)), rep('W2', length(cells_all_f$cell.id)), rep('A1', length(cells_all_f$cell.id)), rep('A2', length(cells_all_f$cell.id)), rep('W3', length(cells_all_f$cell.id)))
toplot_f$stab_group <- factor(toplot_f$stab_group, levels = c("W1","W2","A1","A2","W3"))

ggplot(toplot_f, mapping = aes(x=stab_group, y=Stability))+
  geom_point(aes(color=paradigm),position = position_jitterdodge(jitter.width = 1.2), size=0.5)+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+facet_wrap(.~paradigm)+
  scale_y_continuous(breaks=seq(-0.6,1,0.2))+
  scale_color_manual(values=c('#AA510e', '#F4AE52','#164060', '#50a1d9', 'black','grey'))+
  geom_hline(yintercept=0, linetype="dashed")+
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

ggplot(toplot_f[which(toplot_f$disc_group=="discriminating"),], mapping = aes(x=stab_group, y=absratechange))+
  geom_point(aes(color=paradigm),position = position_jitterdodge(jitter.width = 1.2), size=0.5)+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+facet_wrap(.~paradigm)+
  scale_color_manual(values=c('#AA510e', '#F4AE52','#164060', '#50a1d9', 'black','grey'))+
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())#+

#### difference in A1
ggplot(cells_all_f[which(cells_all_f$region=="lec" & cells_all_f$disc_group=="discriminating"),], mapping = aes(x=paradigm, y=A1))+
  geom_point(aes(color=paradigm),position = position_jitterdodge(jitter.width = 1.2), size=0.5)+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+
  scale_color_manual(values=c('#164060', '#50a1d9', 'grey'))+ 
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  geom_hline(yintercept=0, linetype="dashed")

ggplot(cells_all_f[which(cells_all_f$region=="lec" & cells_all_f$disc_group=="discriminating"),], mapping = aes(x=paradigm, y=abs(MFR_A1)))+
  geom_point(aes(color=paradigm),position = position_jitterdodge(jitter.width = 1.2), size=0.5)+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+facet_wrap(.~paradigm)+
  scale_color_manual(values=c('#AA510e', '#F4AE52','#164060', '#50a1d9', 'black','grey'))+
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())#+

write.csv(cells_all_f[which(cells_all_f$disc_group=="discriminating"), c("cell.id", "session")], file = "~/LEC_remapping/results/cid_PVanalysis_discriminating.csv")

#pie charts
library(stringr)
library(dplyr)
plot_data <- cells_all_f %>% 
  group_by(paradigm, disc_group) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = "", y = percent, fill=disc_group)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 0),'%', sep = "")), position = position_stack(vjust=0.5), color="white") +#,vjust = 1.2
  coord_polar(theta="y",start = 0, direction = 1)+
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_void()+ 
  facet_wrap(.~paradigm)+
  scale_fill_manual(values = c('#B1B1B1','#16301B',"#A2D5D9", '#ff7f11', '#FFB370', '#A21632'))#+

#pie chart per mouse
library(stringr)
library(dplyr)
plot_data <- cells_all_f[,] %>% 
  group_by(paradigm, mouse, disc_group) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = "", y = percent, fill=disc_group)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 0),'%', sep = "")), position = position_stack(vjust=0.5), color="white") +#,vjust = 1.2
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_void() + 
  facet_wrap(mouse~paradigm)+
  scale_fill_manual(values = c('#B1B1B1','#16301B',"#A2D5D9", '#ff7f11', '#FFB370', '#A21632'))#+


#### correlation rotation plots
library(vctrs)
res_dir <- "~/LEC_remapping/results/"
correlation_rotation1<- read.csv(paste(res_dir, "correlation_rotationLEC.csv", sep = ""), header = T)
correlation_rotation1$context <- "2room"
correlation_rotation2<- read.csv(paste(res_dir, "correlation_rotationCA1.csv", sep = ""), header = T)
correlation_rotation2$context <- "2room"
correlation_rotation3<- read.csv(paste(res_dir, "correlation_rotationLECbw.csv", sep = ""), header = T)
correlation_rotation3$context <- "2box"
correlation_rotation3b<- read.csv(paste(res_dir, "correlation_rotationLECbw_subset1.csv", sep = ""), header = T)
correlation_rotation3b$context <- "2box"
correlation_rotation4<- read.csv(paste(res_dir, "correlation_rotationCA1bw.csv", sep = ""), header = T)
correlation_rotation4$context <- "2box"

correlation_rotation_all <- rbind(correlation_rotation1,correlation_rotation2,correlation_rotation3,correlation_rotation3b,correlation_rotation4)



toplot <- data.frame(cell.id=vec_rep(correlation_rotation_all$cell.id, 4), region=vec_rep(correlation_rotation_all$region, 4),
                     rotation=vec_rep(correlation_rotation_all$rotation_angle, 4),
                     MS=c(correlation_rotation_all$MS_A1, correlation_rotation_all$MS_A2, correlation_rotation_all$MS_W1, correlation_rotation_all$MS_W2),
                     AW=c(rep('A1', length(correlation_rotation_all$cell.id)), rep('A2', length(correlation_rotation_all$cell.id)),rep('W1', length(correlation_rotation_all$cell.id)),rep('W2', length(correlation_rotation_all$cell.id))),
                     context=vec_rep(correlation_rotation_all$context,4))

#+++++++++++++++++++++++++
# Calculate the mean and the standard deviation for each group
#+++++++++++++++++++++++++
data_summary <- function(data, varname, groupnames){
  require(plyr)
  summary_func <- function(x, col){
    c(mean = mean(x[[col]], na.rm=TRUE),
      sd = sem(x[[col]]))
  }
  data_sum<-ddply(data, groupnames, .fun=summary_func,
                  varname)
  data_sum <- rename(data_sum, c("mean" = varname))
  return(data_sum)
}

df2 <- data_summary(toplot[which((toplot$AW=="A1" | toplot$AW=="W1") & toplot$cell.id %in% cells_all_f$cell.id[which(cells_all_f$disc_group=="discriminating")]),], varname="MS", 
                    groupnames=c("context", "region", "rotation", "AW"))

##### plot with errorbar ####
ggplot(data=df2[which(df2$context=="2room"),], mapping = aes(x=rotation, y=MS, color=region, shape=AW))+
  geom_errorbar(aes(ymin=MS-sd, ymax=MS+sd), width=0.6,position=position_dodge(0.05))+
  stat_summary(fun="median",aes(group=AW), geom = "line", linetype="dashed")+
  stat_summary(fun="median",aes(group=AW), geom = "point")+
  theme_classic()+theme(axis.text.x = element_text(angle = 45, hjust=1))+
  ylab('Map stability')+
  scale_color_manual(values=c('#aa510E','#134869'))+
  facet_grid(region~.)

ggplot(data=df2[which(df2$context=="2box"),], mapping = aes(x=rotation, y=MS, color=region, shape=AW))+
  geom_errorbar(aes(ymin=MS-sd, ymax=MS+sd), width=0.6,position=position_dodge(0.05))+
  stat_summary(fun="median",aes(group=AW), geom = "line", linetype="dashed")+
  stat_summary(fun="median",aes(group=AW), geom = "point")+
  theme_classic()+theme(axis.text.x = element_text(angle = 45, hjust=1))+
  ylab('Map stability')+
  scale_color_manual(values=c('#f4ae52','#50a1d9'))+
  facet_grid(region~.)

