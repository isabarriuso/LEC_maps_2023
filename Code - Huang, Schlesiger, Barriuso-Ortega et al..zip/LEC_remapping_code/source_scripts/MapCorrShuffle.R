#' Calculate random spatial correlation statistics of the firing rate maps of neurons
#'
#' The random values are obtained by shifting the position data.
#' The number of shufflings is nShufflings of the SpatialProperties2d object.

getMapCorrShuffle <- function(sp1,st1,pt1,sp2,st2,pt2,border="rectangular",triggered=F){
  if(border!="rectangular" & border!= "circular")
    stop(paste("getMapcorrShuffle, value of border can be \"rectangular\" or \"circular\" but is", border))
  
  if(sp1@nShufflings==0)            
    stop("sp@nShufflings==0")
  
  mapCorrShuffle=matrix(ncol = length(sp1@cellList), nrow = sp1@nShufflings)
  
  for(i in 1:sp1@nShufflings){
    pt1s<-shiftPositionRandom(pt1)
    pt2s<-shiftPositionRandom(pt2)
    ## make the maps
    if(triggered==FALSE){
      sp1<-firingRateMap2d(sp1,st1,pt1s,nRowMap = sp1@nRowMap,nColMap = sp1@nRowMap)
      sp2<-firingRateMap2d(sp2,st2,pt2s,nRowMap = sp2@nRowMap,nColMap = sp2@nRowMap)
    }else{
      sp1<-spikeTriggeredFiringRateMap2d(sp1,st1,pt1s)
      sp2<-spikeTriggeredFiringRateMap2d(sp2,st2,pt2s)
    }
    sp1@reduceSize <- F
    sp2@reduceSize <- F
    # make spatial correlation
    mapCorrShuffle[i,1:length(sp1@cellList)] <- firingRateMapCorrelation(sp1,sp2)
  }
  return(mapCorrShuffle)
}


