function data = calculatePFandPVcorrMS(stackMap1,stackMap2)

% disp([comparison,' Comparison'])
gridsize=size(stackMap1,1);
N=size(stackMap1,3);
disp(['number of cells in stack: ',num2str(N)]);

%% used for all calculations except PV
% if nargin <5
    cutoff3 = 0.1; %cutoff by peak, for PF corr and PV corrlation, currently used %changed from 1 to 0.1 (Isa March 2023)
% end

nonzero = 0; %0.1; %exclude pairs of 0-0 Hz pixels in spatial correlation, currently used

%%% used only for plotting center of mass shifts
cutoff = 0.1; %max > cutoff, by rate, for PF corr
cutoff2 = 1; % min > cutoff2, by rate, for PF corr


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PVcorr = zeros(gridsize, gridsize);
PV1mean=PVcorr;
PV2mean=PV1mean;
PV1 = zeros(N,1);
PV2 = PV1;

s1=0;s2=0;    % variables to hold sums of population vectors
PF_sparsity_1 = zeros(1,N);
PF_sparsity_2 = PF_sparsity_1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%main code
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

MeanRates1 = zeros(1,N);
MeanRates2 = MeanRates1;

for Z=1:1:N
    MeanRates1(Z)=nanmean(nanmean(stackMap1(:,:,Z)));
    MeanRates2(Z)=nanmean(nanmean(stackMap2(:,:,Z)));
end
RateVec=sqrt(MeanRates1.^2 + MeanRates2.^2);

%%%%%%%%%%%%%%%%%%%%%%%%%      compute N, PF correlations
PFcorr = zeros(1,N);
for k = 1:N
    peak(k) = nanmax(nanmax(nanmax((stackMap1(:,:,k)))),nanmax(nanmax((stackMap2(:,:,k)))));
    if peak(k) >= cutoff3
        RSstackMap1 = reshape(stackMap1(:,:,k),[],1);
        RSstackMap2 = reshape(stackMap2(:,:,k),[],1);
        
        usableInd = find(~isnan(RSstackMap1) & ~isnan(RSstackMap2));
        
        if ~isempty(usableInd)
            
            RSstackMap1 = RSstackMap1(usableInd);
            RSstackMap2 = RSstackMap2(usableInd);
            
            spatial_corr = corrcoef(RSstackMap1,RSstackMap2); %spatial_corr = corrcoef(reshape(stackMap1(:,:,k),[],1),reshape(stackMap2(:,:,k),[],1));
            PFcorr(k)= spatial_corr(1,2);
        else
            PFcorr(k) = NaN;
        end
    else
        PFcorr(k) = NaN;
    end
end

% Don't really like indexing in this way as it will/could misalign correlation values across
% comparisons which would throw off avging across sessions or scatter plots

%Segregated Active from Default of PF and COM values

active_index = find(isnan(PFcorr)==0);
N = size(stackMap1,3);
stackMap1_Active = stackMap1(:,:,active_index);
stackMap2_Active = stackMap2(:,:,active_index);

N_Active = size(stackMap1_Active,3);
disp(['Number of active cells: ',num2str(N_Active),' of ',num2str(N),' Total cells']);

PFcorr_active = PFcorr(active_index);
meanPFcorr_active = mean(PFcorr_active);
disp(['PFCorrelation: ',num2str(meanPFcorr_active)]);
%PFcorr_active = PFcorr(find(max(rateStack,[],1) > cutoff & min(rateStack,[],1) >= cutoff2)); %PFcorr();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%         Compute PV autocorrelations
disp('Calculating the cross-correlation');
% Do a cross-correlation analysis of the population vectors
numBins2 = 25;
if ~mod(numBins2,2)
    % Number of bins in the correlation map must be a odd number to
    % obtain symmetry
    numBins2 = numBins2 - 1;
end

numBins = size(stackMap1_Active,1);
if numBins2 > numBins*2-1;
    numBins2 = numBins*2-1; end %maximum number of bins

% Index for the centre bin in the correlation map
centreBin = (numBins2+1)/2;
% turn dot product on/off
dot = 'off';
% Allocate memory for the cross-correlation map
Rxy = zeros(numBins2);
Rdistance = zeros(numBins2);
% Do the correlation calculation with a 4 times nested for-loop
for ii = 1:numBins2
    % Offset in the x-direction for the second map
    xi = ii-centreBin;
    for jj = 1:numBins2
        % Offset in the y-direction for the second map
        yi = jj-centreBin;
        % Counts number of bins that contribute to the current point of
        % the cross-correlation map
        NB = 0;
        average_map1 = NaN(numBins);
        average_map2 = NaN(numBins);
        for k = 1:numBins
            for l = 1:numBins
                
                if (k-xi)>0 && (k-xi)<=numBins && (l-yi)>0 && (l-yi)<=numBins
                    usableInd = find(~isnan(stackMap1_Active(k,l,:)) & ~isnan(stackMap2_Active(k-xi,l-yi,:)));
                    if ~isempty(usableInd)
                        NB = NB +1;
                        if N_Active > 1
                            if strcmp(dot,'on')
                                %disp('normalize');
                                norm = sqrt(sum(stackMap1_Active(k,l,:).*stackMap1_Active(k,l,:))) * sqrt(sum(stackMap2_Active(k-xi,l-yi,:).*stackMap2_Active(k-xi,l-yi,:)));
                                Rxy(ii,jj) = Rxy(ii,jj) + (sum(stackMap1_Active(k,l,:).*stackMap2_Active(k-xi,l-yi,:)))/norm;
                                %Rxy(ii,jj) = Rxy(ii,jj) + sum(stackMap1_Active(k,l,:).*stackMap2_Active(k-xi,l-yi,:));
                            else
                                %disp('Pearson');
                                
                                corr_coeff = corrcoef(stackMap1_Active(k,l,usableInd), stackMap2_Active(k-xi,l-yi,usableInd));
                                if size(corr_coeff,2) == 2
                                    Rxy(ii,jj) = nansum([Rxy(ii,jj)  corr_coeff(1,2)]);
                                end
                                
                            end
                        end
                        
                        average_map1(k,l) = nanmean(stackMap1_Active(k,l,:));
                        average_map2(k,l) = nanmean(stackMap2_Active(k-xi,l-yi,:));
                        %use loops to calcuate a shifted map
                    end
                end
            end
        end
        if N_Active > 1
            Rxy(ii,jj) = Rxy(ii,jj)/NB;
        else
            corr_index = find(average_map1 >= 0 | average_map2 >= 0);
            corr_index = corr_index(~isnan(average_map1(corr_index)) & ~isnan (average_map2(corr_index)));
            if length(corr_index) > 1
                spatial_corr = corrcoef(average_map1(corr_index),average_map2(corr_index));
                Rxy(ii,jj) = spatial_corr(1,2);
                %disp([ii jj length(find(average_map1 >= 0)) length(find(average_map2 >= 0)) Rxy(ii,jj)] );
            else
                Rxy(ii,jj) = 0;
            end
        end
        if (xi == 0 && yi == 0)
            Rdistance(ii,jj) = 0;
        else
            Rdistance(ii,jj) = sqrt(xi*xi+yi*yi);
        end
    end
end

for i = 1:20
    distance_bin = 0.50001;
    Rvalues = Rxy(find(Rdistance >= distance_bin*(i-1) & Rdistance < distance_bin*i));
    Rmean(i) = mean(Rvalues);
    Rsem(i) = std(Rvalues)/sqrt(length(Rvalues));
end

% if plotFigures% Draw the cross-correlation map
%     figure;
%     binWidth = 5;
%     sLength = binWidth * numBins;
%     mapAxis = -sLength/2+binWidth/2:5:sLength/2-binWidth/2;
%     
%     Ncorr = size(Rxy,1);
%     start = -(floor(Ncorr/2)*binWidth);
%     stop = floor(Ncorr/2)*binWidth;
%     rxyAxis = start:binWidth:stop;
%     Rdraw = Rxy; Rdraw(find(Rxy < 0)) = 0;
%     drawfield(Rdraw,rxyAxis,'jet',1,'Population Cross-Correlation')%max(max(Rxy)));
%     axis square
%     
%     figure; hold on;
%     
%     plot(1:20,Rmean)
%     %errorbar(1:20,Rmean,Rsem)
%     axis([1 20 -0.5 1]);
%     hold off;
% end

%return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%         Compute PV correlations
% compute the correlations between corresponding columns of stackMap1_Active and stackMap2_Active
% this gives the correlations between corresponding spatial pop vectors

%step_sub = [2 3 4 5 10 20 30 40 50 100 200 300 400 500 1000];
step_sub = 1000;
subsampling = 1; kk = 0;
repetitions = 1; %1000;
while subsampling
    kk = kk+1;
    if step_sub(kk) > N_Active
        subsampling = 0;
        step_sub(kk) = N_Active;
    end
    for rr = 1:repetitions;
        sub = 1:N_Active; %sub = randperm(N_Active);
        sub = sub(1:step_sub(kk));
        stackMap1_Active_sub = stackMap1_Active(:,:,sub);
        stackMap2_Active_sub = stackMap2_Active(:,:,sub);
        N_sub = size(stackMap1_Active_sub,3);
        
        for x=1:1:gridsize
            for y=1:1:gridsize
                PV1= reshape(stackMap1_Active_sub(x,y,:),N_sub,1);
                PV2= reshape(stackMap2_Active_sub(x,y,:),N_sub,1);
                %         xr = randperm(gridsize); yr = randperm(gridsize);
                %         PV2= reshape(stackMap2_Active(xr(1),yr(1),:),N_Active,1);
                %         %PV1mean(x,y)= mean(PV1); PV2mean(x,y)= mean(PV2);
                usableInd = find(~isnan(PV1) & ~isnan(PV2));
                if (N_Active > 1) && (length(usableInd) > 1)
                    
                    cor = corrcoef(PV1(usableInd), PV2(usableInd));
                    PVcorr(x,y)=cor(1,2);
                else
                    PVcorr(x,y) = nan;
                end
            end
        end
        
        PVcorrlist(:,kk,rr) = reshape(PVcorr, 1, gridsize.^2);
        meanPVcorrlist = nanmean(PVcorrlist);
        disp(['PVCorrelation: ',num2str(meanPVcorrlist)]);
    end
end

% Center of Mass Differences
% compute the center of mass differences for the place field planes of the P1 and P2 stacks
com1 = zeros(N,2);com2 = com1; % com == center of mass ** in units of bins ** 
delcom=zeros(1,N);moment=[1:1:gridsize];
for z=1:N
    if isnan(PFcorr(z))
        delcom(1,z) = NaN; %If firing rate did not meet the cutoff don't calc COM but use a NaN so as to not throw off ordering
    else
        warning off
        PF1= reshape(stackMap1(:,:,z),gridsize,gridsize);
        com1(z,1)=(nansum(nansum(PF1).*moment))./(nansum(nansum(PF1)));
        com1(z,2)=(nansum(nansum(PF1').*moment))./(nansum(nansum(PF1)));
        
        PF2= reshape(stackMap2(:,:,z),gridsize,gridsize);
        com2(z,1)=(nansum(nansum(PF2).*moment))./(nansum(nansum(PF2)));
        com2(z,2)=(nansum(nansum(PF2').*moment))./(nansum(nansum(PF2)));
        warning on
        delcom(1,z)=sqrt(((com1(z,1)-com2(z,1)).^2)+((com1(z,2)-com2(z,2)).^2));
    end
end

delcom_Active = delcom(active_index);

data = struct('RateVector',RateVec,'PFcorr_Active',PFcorr_active,'PFcorr',PFcorr,'PVcorr',PVcorrlist,'COM',delcom,...
    'COM_Active',delcom_Active,'correlation',Rxy,'correlation_by_distance',Rmean,'sem_by_distance',Rsem,'peakRate',peak,'meanRate1',MeanRates1, 'meanRate2',MeanRates2);
end
