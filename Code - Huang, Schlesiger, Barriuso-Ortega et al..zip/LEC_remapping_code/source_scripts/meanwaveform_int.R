############## mean Waveform function that respects st intervals, adapted from meanWaveform

############## For getting intervals set to laser puls check out compare_meanwaveform_laser.R
#############################################################################################
############ Beginning copied from getMethod("meanWaveform", "SpikeWaveform") ###############

meanWaveform_int <- function (sw, rs, st, cg, df, windowSizeMs = 3, divisorToMicroVolt = 7, 
          numberSpikes = 500, minInterSpikeIntervalMs = 2, minPassHz = 500, 
          maxPassHz = 10000, filter = FALSE) 
{
  if (rs@session == "") {
    stop("RecSession object not set in meanWaveform()")
  }
  if (st@session == "") {
    stop("SpikeTrain object not set in meanWaveform()")
  }
  if (windowSizeMs < 1000/rs@samplingRate) {
    stop(paste("windowSizeMs of", windowSizeMs, "is smaller than one data point given the sampling rate of", 
               rs@samplingRate, "in meanWaveform()"))
  }
  if (numberSpikes < 1) {
    stop(paste("numberSpikes", numberSpikes, "is smaller than 1 in meanWavefrom()"))
  }
  if (st@nCells < 1) {
    stop(paste("st@nCells is smaller than 1 in meanWaveform()"))
  }
  if (length(df@fileNames) == 0) {
    stop(paste("df@fileNames has a length of 0 in meanWaveform"))
  }
  sw@samplingRate = rs@samplingRate
  sw@path = rs@path
  sw@session = rs@session
  sw@cellList = st@cellList
  sw@wfCluId <- character()
  for (clu in st@cellList) {
    print(clu)
    spikeTimes <- st@res[which(st@clu == clu)]

###### Changes from here ########################################################################
    
     
    #### Make subsetting vector 
    #### for each res in spikeTimes give TRUE if it should be included and FALSE if not
    #### all res that are within one of the intervals in st@startInterval to st@endInterval should get TRUE
    
    vec <- rep(F,length(spikeTimes))          #new vector with length of spikeTimes 
    for(i in 1:length(st@startInterval)){     #loop through all intervals
      vec2 <- spikeTimes >= st@startInterval[i] & spikeTimes <= st@endInterval[i] #make vector where res within this interval are TRUE and all others FALSE
      vec <- vec | vec2                       #combine new vector with old one (with OR, so that TRUE's are added)
    }
    
    #spikeTimes <- spikeTimes[(c(FALSE, vec))] #subset spikeTimes with subsetting vector
    spikeTimes <- spikeTimes[vec]
    #######################################################################################################
    ##### From original Method (only one change)
    spikeTimes <- spikeTimes[(c(FALSE, diff(spikeTimes) > 
                                  minInterSpikeIntervalMs * st@samplingRate/1000))] #changed sw@samplingRate to st@samplingRate
    
    #######################################################################################################
    ##### Warning if too few spikes, take all spikes you can get
    if(length(spikeTimes) < numberSpikes){
      
      print(paste("WARNING: Not enough spikes in spikeTimes, taking", length(spikeTimes), "spikes", sep = " "))
    } else{
      spikeTimes <- head(spikeTimes, n = numberSpikes)
    }
    
    #######################################################################################################
    ##### New start and end indices (original commented out)
    
    startIndex <- min(spikeTimes) - (windowSizeMs*rs@samplingRate/1000)
    endIndex <- max(spikeTimes) + (windowSizeMs*rs@samplingRate/1000)
    #startIndex <- 0
    #endIndex = tail(spikeTimes, n = 1)+ st@startInterval + (windowSizeMs *  #have to add st@startInterval again
    #                                        rs@samplingRate/1000)
    
    #since I'm going to start getting my traces from startIndex, need to shift my spikeTimes by the same amount 
    spikeTimes <- spikeTimes - startIndex
    
    ########################################################################################################
    #### From original method, no other changes
    
    tetrode <- cg@tetrode[which(cg@clu == clu)]
    channels <- rs@channelsTetrode[tetrode, ]
    channels <- channels[which(!is.na(channels))]
    
   
    traces <- datFilesGetChannels(df, channels, firstSample = startIndex, 
                                  lastSample = endIndex)
    if (filter == TRUE) 
      for (chan in 1:length(channels)) traces[, chan] <- bandPassFilter(as.numeric(traces[, 
                                                                                          chan]), rs@samplingRate, minPassHz, maxPassHz)
    wf <- spikeWaveformFromTraces(traces, spikeTimes, as.integer(windowSizeMs * 
                                                                   rs@samplingRate/1000))
    mwf <- apply(wf, c(2, 3), mean)
    if (length(sw@wfCluId) == 0) {
      sw@wf <- mwf
      sw@wfCluId <- rep(cg@id[which(cg@clu == clu)], length(channels))
    }else {
      sw@wf <- cbind(sw@wf, mwf)
      sw@wfCluId <- c(sw@wfCluId, rep(cg@id[which(cg@clu == clu)], length(channels)))
    }
  }
  sw@wfMsPerBin <- 1000/rs@samplingRate
  sw@wfTimePoints <- seq(from = -sw@wfMsPerBin * dim(sw@wf)[1]/2 + 
                           sw@wfMsPerBin/2, to = sw@wfMsPerBin * dim(sw@wf)[1]/2 - 
                           sw@wfMsPerBin/2, by = sw@wfMsPerBin)
  rownames(sw@wf) <- sw@wfTimePoints
  if (length(sw@wfCluId) != dim(sw@wf)[2]) 
    stop("problem with the dimensions of sw@wf and length of sw@wfCluId in meanWaveform()")
  if (length(sw@wfTimePoints) != dim(sw@wf)[1]) 
    stop("problem with the dimensions of sw@wf and length of sw@wfTimePoints in meanWaveform()")
  return(sw)
}

############ To do #######################################
#
# Print error message when there's not enough spikes in spikeTimes. 