function stackedMap = makeStacksMS(rateMap,session)
% cd(path);
% load(
cells = size(rateMap,2);
%disp(cells)
sampleMap = rateMap{1};
mapSize = 35;


sizeDif = size(sampleMap,1)-mapSize;

stackedMap = zeros(mapSize,mapSize);
for i = 1:cells
    %disp(i)
    stackedMap(:,:,i) = rateMap{session,i}(1+floor(sizeDif/2):floor(sizeDif/2)+mapSize,1+floor(sizeDif/2):floor(sizeDif/2)+mapSize);
    
   
end

