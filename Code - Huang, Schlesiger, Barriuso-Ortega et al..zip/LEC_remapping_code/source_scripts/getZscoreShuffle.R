getZscoreShuffle <- function(rs,sp1,st1,pt1,cg,zone=1){
  
  if(sp1@nShufflings==0)            
    stop("sp@nShufflings==0")
  
  zscoreShuffle=matrix(ncol = length(sp1@cellList), nrow = sp1@nShufflings)
  
  for(i in 1:sp1@nShufflings){
    pt1s<-shiftPositionRandom(pt1)
    ## make the maps
    sp.s1<-firingRateMap2d(sp1,st1,pt1s,nRowMap = sp1@nRowMap,nColMap = sp1@nRowMap)
    sp.s1@reduceSize <- F
    
    ### z score object ###
    #object zone boundaries for position 1 and 2
    map.df1 <- mapsAsDataFrame(sp.s1) 
    map.df1$rate[map.df1$rate == -1] <- NA
    #position 1 --> object in zone 1
    xmin1<-7
    xmax1<-12
    ymin1<-26
    ymax1<-31
    #position 2 --> object in zone 2
    xmin2<-27
    xmax2<-32
    ymin2<-7
    ymax2<-12

    #add some surrounding area
    if (zone == 1){
      zone1 <- c(xmin1-2,xmax1+4,ymin1-4, ymax1+2)
      if (rs@animalName=="ib10079" | rs@animalName=="ib10220"){ #camera was rotated 180°
        zone1 <- c(xmin2-4,xmax2+2,ymin2-2, ymax2+4)
      } 
    }else if (zone == 2){
      zone1 <- c(xmin2-4,xmax2+2,ymin2-2, ymax2+4)
      if (rs@animalName=="ib10079" | rs@animalName=="ib10220"){ #camera was rotated 180°
        zone2 <- c(xmin1-2,xmax1+4,ymin1-4, ymax1+2)
      } 
    }
    
    #create maps of the object zone and no zone (the rest) 
    map.zone1 <- map.df1[which(map.df1$x > zone1[1] & map.df1$x < zone1[2]  & map.df1$y > zone1[3] & map.df1$y < zone1[4]),]
    n.zone1 <- sum(!is.na(map.zone1$rate[map.zone1$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
    map.nozone1 <- map.df1[which(!(map.df1$x > zone1[1] & map.df1$x < zone1[2]  & map.df1$y > zone1[3] & map.df1$y < zone1[4])),]
    
    # calculate mean rate in each of those zones for each cell
    mean_fr.zone1 <- c()
    mean_fr.nozone1 <- c() 
    sd_fr.nozone1 <- c()
    for(j in 1:st1@nCells){
      mean_fr.zone1[j] <- mean(map.zone1$rate[map.zone1$clu.id == paste(rs@session, "_",cg@clu[j],sep = "")], na.rm = TRUE)
      map.nozone1_sample <- sample(map.nozone1$rate[which(map.nozone1$clu.id == paste(rs@session, "_",cg@clu[j],sep = "") & !is.na(map.nozone1$rate))], size = n.zone1)#from a random sample of pixels as big as the object zone, as in Tsao et.al, 2013
      mean_fr.nozone1[j] <- mean(map.nozone1_sample, na.rm = TRUE)
      sd_fr.nozone1[j] <- sd(map.nozone1_sample, na.rm = TRUE)
      
    }
    
    #Calculate z score for session 
    z.score1 <- (mean_fr.zone1 - mean_fr.nozone1)/(sd_fr.nozone1/sqrt(n.zone1))
    
    #add to matrix
    zscoreShuffle[i,] <- z.score1
  }
  return(list(zscoreShuffle))
}



getZscoreShuffle_2obj <- function(rs,sp1,st1,pt1,cg){
  
  if(sp1@nShufflings==0)            
    stop("sp@nShufflings==0")
  
  zscoreShuffle_bl=matrix(ncol = length(sp1@cellList), nrow = sp1@nShufflings)
  oriShuffle_bl=matrix(ncol = length(sp1@cellList), nrow = sp1@nShufflings)
  zscoreShuffle_br=matrix(ncol = length(sp1@cellList), nrow = sp1@nShufflings)
  oriShuffle_br=matrix(ncol = length(sp1@cellList), nrow = sp1@nShufflings)
  zscoreShuffle_tl=matrix(ncol = length(sp1@cellList), nrow = sp1@nShufflings)
  oriShuffle_tl=matrix(ncol = length(sp1@cellList), nrow = sp1@nShufflings)
  zscoreShuffle_tr=matrix(ncol = length(sp1@cellList), nrow = sp1@nShufflings)
  oriShuffle_tr=matrix(ncol = length(sp1@cellList), nrow = sp1@nShufflings)
  
  for(i in 1:sp1@nShufflings){
    pt1s<-shiftPositionRandom(pt1)
    ## make the maps
    sp.s1<-firingRateMap2d(sp1,st1,pt1s,nRowMap = sp1@nRowMap,nColMap = sp1@nRowMap)
    sp.s1@reduceSize <- F
    
    sp.s1 <- firingRateMapsRotation(sp.s1, 180)
    
    ### z score object ###
    #object zone boundaries for position 1 and 2
    map.df1 <- mapsAsDataFrame(sp.s1) 
    map.df1$rate[map.df1$rate == -1] <- NA
    #top right
    xmin1<-26
    xmax1<-31
    ymin1<-28
    ymax1<-33
    #bottom left
    xmin2<-7
    xmax2<-12
    ymin2<-5
    ymax2<-10
    #top left
    xmin3<-7
    xmax3<-12
    ymin3<-28
    ymax3<-33
    #bottom right
    xmin4<-26
    xmax4<-31
    ymin4<-5
    ymax4<-10
    
    #save object surrounding zones
    zone1 <- c(xmin1-2,xmax1+4,ymin1-4, ymax1+2) #top right
    zone2 <- c(xmin2-4,xmax2+2,ymin2-2, ymax2+4) #bottom left
    zone3 <- c(xmin3-4,xmax3+2,ymin3-4, ymax3+2) #top left
    zone4 <- c(xmin4-2,xmax4+4,ymin4-2, ymax4+4) #bottom right
    
    #top right
    map1.zone1 <- map.df1[which(map.df1$x > zone1[1] & map.df1$x < zone1[2]  & map.df1$y > zone1[3] & map.df1$y < zone1[4]),]
    n1.zone1 <- sum(!is.na(map1.zone1$rate[map1.zone1$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
    map1.nozone1 <- map.df1[which(!(map.df1$x > zone1[1] & map.df1$x < zone1[2]  & map.df1$y > zone1[3] & map.df1$y < zone1[4])),]
    #bottom left
    map1.zone2 <- map.df1[which(map.df1$x > zone2[1] & map.df1$x < zone2[2]  & map.df1$y > zone2[3] & map.df1$y < zone2[4]),]
    n1.zone2 <- sum(!is.na(map1.zone2$rate[map1.zone2$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
    map1.nozone2 <- map.df1[which(!(map.df1$x > zone2[1] & map.df1$x < zone2[2]  & map.df1$y > zone2[3] & map.df1$y < zone2[4])),]
    #top left
    map1.zone3 <- map.df1[which(map.df1$x > zone3[1] & map.df1$x < zone3[2]  & map.df1$y > zone3[3] & map.df1$y < zone3[4]),]
    n1.zone3 <- sum(!is.na(map1.zone3$rate[map1.zone3$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
    map1.nozone3 <- map.df1[which(!(map.df1$x > zone3[1] & map.df1$x < zone3[2]  & map.df1$y > zone3[3] & map.df1$y < zone3[4])),]
    #bottom right
    map1.zone4 <- map.df1[which(map.df1$x > zone4[1] & map.df1$x < zone4[2]  & map.df1$y > zone4[3] & map.df1$y < zone4[4]),]
    n1.zone4 <- sum(!is.na(map1.zone4$rate[map1.zone4$clu.id == paste(rs@session, "_",cg@clu[1],sep = "")]))
    map1.nozone4 <- map.df1[which(!(map.df1$x > zone4[1] & map.df1$x < zone4[2]  & map.df1$y > zone4[3] & map.df1$y < zone4[4])),]
    
    # calculate mean rate in each of those zones for each cell
    mean_fr1.zone1 <- c()
    mean_fr1.nozone1 <- c()
    sd_fr1.nozone1 <- c()
    mean_fr1.zone2 <- c()
    mean_fr1.nozone2 <- c() 
    sd_fr1.nozone2 <- c()
    mean_fr1.zone3 <- c()
    mean_fr1.nozone3 <- c() 
    sd_fr1.nozone3 <- c()
    mean_fr1.zone4 <- c()
    mean_fr1.nozone4 <- c() 
    sd_fr1.nozone4 <- c()
    
    for(j in 1:st1@nCells){
      #zone1
      mean_fr1.zone1[j] <- mean(map1.zone1$rate[map1.zone1$clu.id == paste(rs@session, "_",cg@clu[j],sep = "")], na.rm = TRUE)
      map1.nozone1_sample <- sample(map1.nozone1$rate[which(map1.nozone1$clu.id == paste(rs@session, "_",cg@clu[j],sep = "") & !is.na(map1.nozone1$rate))], size = n1.zone1)  #from a random sample of pixels as big as the object zone, as in Tsao et.al, 2013
      mean_fr1.nozone1[j] <- mean(map1.nozone1_sample, na.rm = TRUE)
      sd_fr1.nozone1[j] <- sd(map1.nozone1_sample, na.rm = TRUE)
      #zone2
      mean_fr1.zone2[j] <- mean(map1.zone2$rate[map1.zone2$clu.id == paste(rs@session, "_",cg@clu[j],sep = "")], na.rm = TRUE)
      map1.nozone2_sample <- sample(map1.nozone2$rate[which(map1.nozone2$clu.id == paste(rs@session, "_",cg@clu[j],sep = "") & !is.na(map1.nozone2$rate))], size = n1.zone2)
      mean_fr1.nozone2[j] <- mean(map1.nozone2_sample, na.rm = TRUE)
      sd_fr1.nozone2[j] <- sd(map1.nozone2_sample, na.rm = TRUE)
      #zone3
      mean_fr1.zone3[j] <- mean(map1.zone3$rate[map1.zone3$clu.id == paste(rs@session, "_",cg@clu[j],sep = "")], na.rm = TRUE)
      map1.nozone3_sample <- sample(map1.nozone3$rate[which(map1.nozone3$clu.id == paste(rs@session, "_",cg@clu[j],sep = "") & !is.na(map1.nozone3$rate))], size = n1.zone3)
      mean_fr1.nozone3[j] <- mean(map1.nozone3_sample, na.rm = TRUE)
      sd_fr1.nozone3[j] <- sd(map1.nozone3_sample, na.rm = TRUE)
      #zone4
      mean_fr1.zone4[j] <- mean(map1.zone4$rate[map1.zone4$clu.id == paste(rs@session, "_",cg@clu[j],sep = "")], na.rm = TRUE)
      map1.nozone4_sample <- sample(map1.nozone4$rate[which(map1.nozone4$clu.id == paste(rs@session, "_",cg@clu[j],sep = "") & !is.na(map1.nozone4$rate))], size = n1.zone4)
      mean_fr1.nozone4[j] <- mean(map1.nozone4_sample, na.rm = TRUE)
      sd_fr1.nozone4[j] <- sd(map1.nozone4_sample, na.rm = TRUE)
    }
    #Calculate z score for session 
    z.score1_tr <- (mean_fr1.zone1 - mean_fr1.nozone1)/(sd_fr1.nozone1/sqrt(n1.zone1))
    z.score1_tl <- (mean_fr1.zone3 - mean_fr1.nozone3)/(sd_fr1.nozone3/sqrt(n1.zone3))
    z.score1_br <- (mean_fr1.zone4 - mean_fr1.nozone4)/(sd_fr1.nozone4/sqrt(n1.zone4))
    z.score1_bl <- (mean_fr1.zone2 - mean_fr1.nozone2)/(sd_fr1.nozone2/sqrt(n1.zone2))
    
    #add to matrix
    zscoreShuffle_bl[i,] <- z.score1_bl
    zscoreShuffle_br[i,] <- z.score1_br
    zscoreShuffle_tl[i,] <- z.score1_tl
    zscoreShuffle_tr[i,] <- z.score1_tr
  }
  return(list(zscoreShuffle_bl, zscoreShuffle_br, zscoreShuffle_tl, zscoreShuffle_tr))
}
