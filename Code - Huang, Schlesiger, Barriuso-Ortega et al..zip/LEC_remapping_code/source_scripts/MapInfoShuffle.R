#' Calculate random spatial statistics of the firing rate maps of neurons
#'
#' The random values are obtained by shifting the position data.
#' The number of shufflings is nShufflings of the SpatialProperties2d object.

getMapInfoShuffle <- function(sp,st,pt,triggered=F){
    if(sp@nShufflings==0)            
      stop("sp@nShufflings==0")
    
    sp@peakRateShuffle=numeric()
    sp@infoScoreShuffle=numeric()
    sp@sparsityShuffle=numeric()
    
    for(i in 1:sp@nShufflings){
      pts<-shiftPositionRandom(pt)
      
      ## make the maps
      if(triggered==FALSE)
        sp<-firingRateMap2d(sp,st,pts)
      else
        sp<-spikeTriggeredFiringRateMap2d(sp,st,pts)
      
      sp@peakRateShuffle <- c(sp@peakRateShuffle,apply(sp@maps,3,max))
      sp@infoScoreShuffle <- c(sp@infoScoreShuffle,
                               .Call("information_score_cwrap",
                                     length(sp@cellList),
                                     as.numeric(sp@maps),
                                     as.numeric(sp@occupancy),
                                     as.integer(sp@nColMap*sp@nRowMap)))
      sp@sparsityShuffle <- c(sp@sparsityShuffle, .Call("sparsity_score_cwrap",
                                                        length(sp@cellList),
                                                        as.numeric(sp@maps),
                                                        as.numeric(sp@occupancy),
                                                        as.integer(sp@nColMap*sp@nRowMap)))
    }
    return(sp)
  }
