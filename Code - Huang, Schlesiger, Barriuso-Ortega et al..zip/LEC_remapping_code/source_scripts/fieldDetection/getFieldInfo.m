function fieldData = getFieldInfo(map,spikeMap,timeMap,fieldBounds,fieldBins,p)
colAxis = (p.xRange(1)+p.binWidth/2):p.binWidth:(p.xRange(2)-p.binWidth/2);
rowAxis = (p.yRange(1)+p.binWidth/2):p.binWidth:(p.yRange(2)-p.binWidth/2);

% Linear indicies to field bins
fInd = unique(sub2ind(size(map),fieldBins(:,1),fieldBins(:,2)));


% Field map
fieldMap = zeros(size(map));
fieldMap(fInd) = map(fInd);

% Center of mass (COM)
totalRate = sum(map(fInd(~isnan(map(fInd)))));
yCOM = map(fInd(~isnan(map(fInd))))'*rowAxis(fieldBins((~isnan(map(fInd))),1))';
xCOM = map(fInd(~isnan(map(fInd))))'*colAxis(fieldBins((~isnan(map(fInd))),2))';
fieldCenter = [xCOM yCOM]/totalRate;

% Mean bin rate in field
meanBinRate = nanmean(map(fInd));

% Number of spikes
nSp = sum(spikeMap(fInd));

% Field occupancy
occupancy = sum(timeMap(fInd));

% Average rate in field
avgRate = nSp/occupancy;

% Peak rate in field
peakBinRate = nanmax(map(fInd));


% Field Size
if strcmp(p.fieldSizeMethod,'boundary')
    basis = fieldBounds.boundary*diff(p.xRange)/2;
else
    basis = fieldBins;
end
fieldSize = getFieldSize(basis,p.binWidth,p.fieldSizeMethod,p.fieldSizeMeasure);

% Spike density (spikes/cm2 of bin/sec in field)
density = (nSp/fieldSize)/occupancy;

% Store and return
fieldData.fieldMap = fieldMap;
fieldData.fieldBounds = fieldBounds;
fieldData.fieldBins = fieldBins;
fieldData.center = fieldCenter;
fieldData.fieldSize = fieldSize;
fieldData.meanBinRate = meanBinRate;
fieldData.peakBinRate = peakBinRate;
fieldData.nSp = nSp;
fieldData.occupancy = occupancy;
fieldData.avgRate = avgRate;
fieldData.density = density;