% Calculates the raw rate map.
function [spk_map spkx_pixel spky_pixel not_assigned] = rawspkmap(spkx,spky,axis,offset)
if nargin==3 || isempty(offset)
    offset = 1/2;
end
bins = length(axis);
binWidth = axis(2)-axis(1);
minPos = axis(1);
correction = 1+offset;

spk_map = zeros(bins);
spkx_pixel = NaN(length(spkx),1);
spky_pixel = NaN(length(spky),1);

% Find number of position samples in each bin
pcx = minPos-binWidth*correction; % X-coord for current bin position
for ii = 1:bins
    % Increment the x coordinate
    pcx = pcx + binWidth;
    I = find(spkx > pcx & spkx < pcx+binWidth);
    % Y-coord for current bin position
    pcy = minPos-binWidth*correction;
    for jj=1:bins
        % Increment the y coordinate
        pcy = pcy + binWidth;
        J = find(spky(I) > pcy & spky(I) < pcy+binWidth);
        % Number of position samples in the current bin
        spk_map(jj,ii) = length(J);
        spkx_pixel(I(J)) = jj; spky_pixel(I(J)) = ii; %invert x and y as in map
        %         % Convert count to rate
        %         if (tmap(jj,ii) <= 0.15) %do not calculate rates for bins that were occupied for less than 150 ms
        %             map(jj,ii) = NaN;
        %         else
        %             map(jj,ii) = map(jj,ii)/tmap(jj,ii);
        %         end
    end
end
not_assigned = length(spkx)-sum(sum(spk_map));