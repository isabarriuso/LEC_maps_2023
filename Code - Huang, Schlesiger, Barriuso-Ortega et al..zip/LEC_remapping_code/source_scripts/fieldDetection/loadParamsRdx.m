function p = loadParamsRdx(pFile)

if nargin == 0
    %% Rdx
    p.xRange = [-50 50];
    p.yRange = [-50 50];
    p.HDresolution = 1;
    p.sampRate = 30;
    p.bins = 20;
    p.binWidth = 5;
    p.gridWidth = 2.5;
    p.gridSmoothing = 1.5 * p.gridWidth;
    p.outerRadius = NaN;
    p.centerRadius = NaN;
    p.smoothing = 'kernal';
    p.smoothingFactor = 3;
    p.useAdaptiveMap = 1;
    p.shape = [1 100];
    p.minNumBins = 5;
    p.fieldThreshold = 0.2;
    p.lowestFieldRate = 1;
    p.minRunSpeed = 2;
    p.alpha = 10000;
    p.fpass = [0 125];
    p.acNBins = 501;
    p.acBinWidth = 0.002;
    p.acMinSpikes = 100;
    p.acVars.fBand = [4 12];
    p.acVars.tapers = [1 1]; %TW product, number of tapers (max 2TW-1)
    p.acVars.pad = 1;
    p.acMaxLags = 500;
    p.acThresh = 5;
    p.spikeFs = 500;
    %p.posFs = 30;  Sampling rate should really be calcualted directly from
    %data using this formula: posFs = round(nanmedian(1./diff(t)));
    p.spikePhaseWindow = 0.5;
    p.fieldSizeMethod = 'boundary';
    p.fieldSizeMeasure = 'area';
    p.filtLFP.fBand = [4 12];
    p.filtLFP.bandName = 'theta';
    p.filtLFP.phaseMethod = 'hilbert';
    p.IFR.windowSize = 0.25;
    p.IFR.windowUnits = 'seconds';
    p.phaseBand = 'theta';
    p.dRotation = 30;
    p.minOccupancy = 0.15;
    p.delimeterThresh = [];
    p.ISIDuration = 0.006;
    p.maxISI = 1;
    
    p.lfp.fpass = [0 120];
    p.lfp.tWid = 3;
    p.lfp.tStep = p.lfp.tWid/2;
    p.lfp.bandwidth = 2;
    p.lfp.nTapers = 1;
    p.lfp.fftPad = 0;
    
    
    
    %% Analysis Type
    p.mazeType = 'OF';                  % 'OF' (Open field) || 'LT' (Linear Track)
    p.trialMethod = 'field';            % Method by which single trials are defined
    % 'field' || 'train'
    p.boundaryMethod = 'pixel';         % Method by which fields are defined
    % 'shape' || 'uniformCutoff' || 'pixel'
    p.posDims = 1;                      % Number of position dimensions to use in 'LT' mode
    % 1 || 2
    
    
    
    %% Analysis Session Managment (Optional)
    % Turning off one or more of these functions after an initial run of the analysis
    % can save time during subsequent analysis sessions, but is never
    % required.
    %
    % NOTE: Although the specified functions are dependent on one another for
    % input/output, the analysis software is foolproof. For example, if the
    % field-finder is set to run, the pass-finder will run regardless of
    % whether or not it is set to run via these parameters.
    %
    % DISCLAIMER: On the other hand, the analysis software CANNOT
    % (currently) tell whether or not (say) the
    % TTList (or these parameters) have changed or if binFinder has been rerun, etc.
    % Thus, care should be taken when turning these off.
    %
    % DEVELOPER'S NOTE: In the future, these settings should be automated
    % on a need-to-run basis, invisible to the user.
    p.runFieldFinder = 1;
    p.runFieldFinder = 1;               %(Intentionally doubled due to bug)
    p.runPassFinder = 1;
    p.runDataFormatter = 1;
    
    %% Fields and Maps
    % Parameters used by several functions that deal in fields and maps
    p.useLargestFieldPerCell = 0;       % Use only the largest field per cell
    p.useTemporalFields = 0;            % Not currently implemented for common use
    p.xRange = [-50 50];                % Range of x coordinate values
    p.yRange = [-50 50];                % Range of y coordinate values
    p.mapSize = 20;                     % Number of bins per row/column (i.e. for square maps)
    p.binSize = 5;                      % Spatial bin size (cm)
    p.interpBinSize = 1;                % Spatial bin size (cm) used for interpolated smooth maps
    p.binSizeInterp = p.interpBinSize;  % Same as above
    p.mapSizeInterp = p.binSize*p.mapSize/p.binSizeInterp;
    p.crossingCutoff = 0.5;             % Contour through which an animal must traverse for a pass to qualify
    p.minRateCutoff = 2;                % Minimum peak rate (Hz) required for a field to qualify
    p.minDwellTime = 0.2;               % Minimum time-duration (s) for a pass to be considered
    
    % Used exclusively in 'uniformCutoff' mode
    p.useRefMap = 0;                    % Use a map of fields averaged over all subsessions (not currently supported)
    p.withinFieldCutoff = 0.2;          % Fraction of max rate at which a field-boundary is defined
    p.useMaxRateForFieldCutoff = 1;     % Allows a refMap-based field to qualify even if a field from a constituent subsession is below the specified cutoff
    p.nContours = 30;                   % Number of contours used to define field
    p.minContours = 4;                  % Number of contours required to qualify as a field
    p.replaceOuterBoundWithSmoothBound = 1;
    
    % Used exclusively in 'pixel' mode
    p.useAdaptiveMap = 1;               % Use map with adaptive smoothing
    p.makeMapSquare = 1;                % Make map generated by adaptive smoothing square
    
    % Used exclusively in 'shape' mode
    p.minDiameter = 10;                 % Minimum diameter required to qualify as a field
    p.percMax0 = 0.98;                  % Fraction of cell maximum rate to begin looking for peaks
    p.dPerc = 0.1;                      % Amount above fraction is decreased with each iteration
    p.dPercRefine = 0.01;               % Amount above fraction is decreased when field edges are being refined
    
    % Used for adaptive path length in 'LT' mode - set and modified by program
    p.pathLims = [];
    %% Run/Trial/Pass Processing
    % Removal of passes that do not satify each of the
    % criteria set below.
    %
    % Pass processing is semi-destructive: unprocessed runs remain in the rateInfo structure, which,
    % in turn, is saved in a file entitled ratesDuringPassesThroughFields;
    % however, runs that do not satisfy these criteria are removed from all
    % downstream structures (e.g. spikePool) and are therefore not
    % considered in subsequent analyses.
    %
    % CAUTION: Entire fields (and cells) may be removed at this stage of the
    % analysis. Do NOT attempt to reconcile information from rateInfo with
    % information from the completed analysis.
    p.minSpikeCount = 5;                % Minimum number of spikes required for a pass to be retained
    p.minAvgVelocity = 3;               % Minimum average velocity required for a pass to be retained
    p.minAvgRate = 0;                   % Minimum average rate for a pass to be retained
    p.maxCircVariance = inf;            % Maximum amount of circular variance allowed for a pass to be retained; has dubious utilit
    p.maxFiringPause = 1;               % Maximum interspike-time allowed for a pass to be retained
    p.firingPauseMethod = 'fixed';      % Use in 'train' mode only; determines how spike-train trials are delineated
    % 'fixed' (uses maxFiringPause) || 'mean' (uses mean interspike interval) || 'median' (uses median interspike interval)
    
    %% Spike Processing
    % Remove/retain spikes based on various characteristics
    %
    % Spike processing must be on to use any/all processing options.
    % Turning spike processing on while leaving all processing
    % options off is okay but will slow down the analysis.
    %
    % Spike processing is inherently non-destructive: spikes are processed
    % by selective indexing during circ-lin stat and summary plot
    % generation, but no spikes are permanently removed from the input structure.
    % One exception: if processBeforePooling = 1, only spikes that meet the
    % specified criteria will be included in the pooled data. This option
    % may speed up the analysis, but it isn't necessary: only the
    % processed spikes will be considered in the analysis, anyway.
    %
    % The options to use lead or tail spikes are mutually exclusive, as are the
    % options to use the first or last spike in a theta cycle: if both
    % options are turned on, preference is given to the former option over the
    % latter (e.g. lead spikes will be used instead of tail spikes).
    % The option to use lead/tail spikes can be used in conjunction with
    % the option to use the first/last spikes within a theta cycle:
    % lead/tail spikes are selected first, then the first/last of these
    % within each theta cycle is selected.
    %
    % Both velocity options require useVelocityThreshold = 1
    p.processSpikes = 0;
    p.processBeforePooling = 0;
    p.discretizeBursts = 0;                  % All spikes within a burst are given the timestamp of the leading spike
    p.useLeadSpikes = 0;                % Use only the first spike within each burst (defined below)
    p.useTailSpikes = 0;                % Use only the last spike within each burst (defined below)
    p.burstDuration = .025;             % Duration of a burst: period of time in which only first/last spike will be taken if using lead/tail spikes
    p.firstSpikePerCycle = 0;           % Use only the first spike per theta cycle
    p.lastSpikePerCycle = 0;            % Use only the last spike per theta cycle
    p.useVelocityThreshold = 0;         % Remove spikes that occured below a specified run velocity
    p.minSpikeVelocity = 0;             % Minimum run velocity at which a spike will be retained
    p.truncateAfterLowVelSpike = 0;     % Cut a pass short if a spike occurs at subthreshold velocity
    
    %% Circular-Linear Regression
    p.regEngine = 'rcc';               % 'rcc' || (deprecated) 'fma'
    p.searchBounds = [-2 2];           % Range within which to search for the best fitting slope
    p.searchIncrement = 0.1;           % Width of subinterval to search for maximizer
    p.searchStart = 0;                 % (deprecated) previously used with FMA engine
    p.theilSen = 1;                    % (deprecated) previously used with FMA engine
    
    % Specifies which measures (against phase) are to be included in the
    % circular-linear regression statistics. In general, for a trial or
    % pool of N spikes, the measure must also be of length N.
    p.xFields.field = [{'drz'},{'runDist'},{'runDistNorm'},{'absDist'},{'absDistNorm'}];
    p.xFields.train = [{'runDist'},{'runDistNorm'},{'absDist'},{'absDistNorm'}];
    
    %% Summary Plot Generation
    % Generate pdf files containing circ-lin stat plots and run/field
    % diagrams for passes/pools that meet various statistical criteria.
    %
    % Criteria are based on how statParams are defined below and include:
    %   'allRuns'               - all passes/pools
    %   'goodP'                 - all passes/pools with p <=maxP
    %   'badP'                  - all passes/pools with p > maxP
    %   'slopeInRange'          - all passes/pools with slope within range specified by slopeBounds
    %   'slopeAboveRange'       - all passes/pools with slope above range specified by slopeBounds
    %   'slopeUnderRange'       - all passes/pools with slope below range specified by slopeBounds
    %   'coeffInRange'          - all passes/pools with correlation coefficient within range specified by coeffBounds
    %   'coeffAboveRange'       - all passes/pools with correlation coefficient above range specified by coeffBounds
    %   'coeffUnderRange'       - all passes/pools with correlation coefficient below range specified by coeffBounds
    %   'ideal'                 - all passes/pools that meet the 'goodP','slopeInRange' and 'coeffInRange' criteria
    %   'pNaN','slopeNaN',
    %   'coeffNaN','RNaN'       - all passes/pools where the respective statistic came back NaN (good for troubleshooting)
    %
    % NOTE: statParams are set independently for single trial (pass) and
    % pooled data.
    %
    % NOTE: Selecting multiple criteria will result in one set of plots
    % being generated per criteria per measure (e.g. run distance); it will
    % NOT result in one set of plots of runs/pools that meet all of the criteria
    % chosen.
    %
    % NOTE: This is perhaps the most time-consuming part of the analysis if
    % run, so choose your criteria wisely. You may always plot by another
    % criteria later without rerunning the entire analysis.
    %
    % You may choose to plot spikes excluded via spike processing either
    % unmarked or ghosted. In either case, you must set showExcludedSpikes = 1.
    % These options have no effect unless spike processing is turned on.
    p.generateSummaryPlots = 1;
    p.plotCriteria = {'goodP','badP','allRuns'};  % Cell array of criteria to plot by (see above)
    p.showExcludedSpikes = 0;                     % Plot spikes excluded via spike processing
    p.ghostExcludedSpikes = 0;                    % Spikes excluded via spike processing are plotted in gray
    p.byCycle = 1;                                % Will cause phase data to be plotted in units of cycles (cf. radians); for presentation only
    p.plot2DLTPath = 1;                           % Plot 2D path with 1D analysis in 'LT' mode
    p.trackRadius = 10;                           % One-half the (used) height of the linear track
    p.showWholePath = 0;                          % Plot the whole path (ghosted)
    p.showAllSpikes = 0;                          % Plot all spikes (ghosted)
    p.statParams.byPass.maxP = 0.05;              % See above
    p.statParams.byPass.slopeBounds = [-inf 0];   % "
    p.statParams.byPass.coeffBounds = [-1 0];     % "
    p.statParams.byPool.maxP = 0.01;              % "
    p.statParams.byPool.slopeBounds = [-inf 0];   % "
    p.statParams.byPool.coeffBounds = [-1 0];     % "
    
    %% Pooling
    % toPool is a cell array of (spikePool) data fields to be
    % concatenated (i.e. pooled).
    %
    % auxData provides instructions for how to handle auxillary data that
    % are not pooled as above, but provide information about the pooled
    % data:
    %   'takeMean'   - take the mean of pass values for this data field
    %   'takeMedian' - take the median of pass values for this data field
    %   'takeSum'    - take the sum of pass values for this data field
    %   'directAdd'  - directly add singleton data shared by all passes
    %
    % NOTE: A data field MUST be listed in order to be included in the pool
    % substructure; however, it is NOT required that every data field listed must be found within the
    % input structure.
    %
    % DISCLAIMER: In general, to ensure that the expectations of downstream
    % functions are met, both parameter structures are best left unmodified
    % except by experienced users.
    p.poolParams.toPool = {'pSp','tSp','drz','runDist','runDistNorm','absDist','absDistNorm','centDist','centDistNorm','instRate','iDrz'};
    p.poolParams.auxData = struct(...
        'session', struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellNum', struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellName',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'direction',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellThetaFreq',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellThetaMax',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellCoherence',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellInfoScore',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellAvgRate',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellMaxRate',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellPhaseAng',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellPhaseLen',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellRateArray',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellMapAdaptive',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellMap',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'cellpRayleigh',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'numPasses', struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'fieldSize', struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'maxRate',struct('takeMean', 0,'takeMedian', 0,'takeSum', 0,'directAdd', 1), ...
        'avgSpikeFreq',struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'avgInstRate', struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'avgBinRate', struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'avgIBinRate', struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'avgRate', struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'avgVelocity', struct('takeMean', 1,'takeMedian',1 ,'takeSum', 0,'directAdd', 0), ...
        'spikeCount', struct('takeMean', 1,'takeMedian', 1,'takeSum', 1,'directAdd', 0), ...
        'dMax',struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'dLinMax',struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'runTime', struct('takeMean', 1,'takeMedian', 1,'takeSum',0 ,'directAdd', 0), ...
        'cStdPath', struct('takeMean',1 ,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'cVarPath', struct('takeMean',1 ,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'cKurtPath', struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'mrvLenPath', struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'turnVal', struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'dLinToPathMin', struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'avgHz', struct('takeMean', 1,'takeMedian', 1,'takeSum', 0,'directAdd', 0), ...
        'avgAmp', struct('takeMean',1,'takeMedian', 1,'takeSum', 0,'directAdd', 0) ...
        );
    
    %% Add Cell Information from BinFinder
    % Specify what information is to be added from binFinder
    %
    % Generally, information needs to be from an NxM cell array, where N is the
    % number of subsessions and M is the number of cells. Typically,  each
    % element of the cell array should be 1x1 double, although other data types
    % will work.
    %
    % strNames specifies the structures from which information is
    % to be added EXACTLY AS THEY ARE NAMED BY BINFINDER. Check your binFinder
    % map file for the exact name of each structure that you wish to use.
    %
    % labels specifies how this information is labeled WITHIN THE ANALYSIS.
    %
    % Naturally, strNames and labels must have the same number of elements.
    %
    % NOTE: For information to be added from a binFinder structure, it is
    % necessary that that structure name is listed. However, it is NOT required that
    % every structure listed must exist.
    p.addFromBinFinder.strNames = ...
        {'informationArray','coherenceArray','ThetafreqArray','ThetamaxArray','spikePhaseAngleArray', 'spikePhaseLengthArray','rateArray','adaptiveMapArray','mapArray', 'pRayleighArray'};
    p.addFromBinFinder.labels = ...
        {'cellInfoScore',   'cellCoherence', 'cellThetaFreq', 'cellThetaMax', 'cellPhaseAng',         'cellPhaseLen',         'cellRateArray','cellMapAdaptive','cellMap', 'cellpRayleigh'};
    
    %% Misc
    
    % Used with getInstRates().
    % Specifies in units of cycles, radians, degrees, or time the diameter around a spike
    % used to calculate its instaneous rate.
    p.windowUnits = 'seconds'; %'cycles'||'radians'||'degrees'||'seconds'
    p.windowSize = 0.25;
    p.generateInstRatePlots = 0;
    p.irateBinSize = 5;
    
    
elseif ischar(pFile)
    load(pFile);
else
    p = pFile;
end

