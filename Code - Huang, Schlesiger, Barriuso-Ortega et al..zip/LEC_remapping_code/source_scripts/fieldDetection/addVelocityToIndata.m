function [indata speed] = addVelocityToIndata(indata)
n_sess = size(indata,1);
n_seg = size(indata,2);
speed = nan(n_sess,n_seg);

for ii = 1:n_sess
    for kk = 1:n_seg
        [v s] = getVelocity(indata(ii,kk).x,indata(ii,kk).y,indata(ii,kk).t);
        indata(ii,kk).v = v(:,2);
        speed(ii,kk) = s;
        disp('speed'); disp(s);
    end
end
