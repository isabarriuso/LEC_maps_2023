function fieldSize = getFieldSize(basis,binWidth,method,measure)
if nargin < 4 || isempty(measure)
    measure = 'area';
end
if nargin <3 || isempty(method)
    if size(basis,1) == 2 && size(basis,2) == 2
        if isequal(basis(:,1),int16(basis(:,1)))
            method = 'bin';
        else
            method = 'boundary';            
        end
    elseif size(basis,1) == 2
        method = 'boundary';
    elseif size(basis,2) == 2
        method = 'bin';
    end
end
switch lower(method)
    case 'bin'
        fieldBins = basis;
        switch lower(measure)
            case 'area'
                nFieldBins = size(fieldBins{f,1});
                binArea = mean(diff(rowAxis))^2;
                fieldSize = nFieldBins*binArea;
            case {'xlength','length'}
                fieldSize = (max(fieldBins(:,2))-min(fieldBins(:,2))+1)*binWidth;
            case 'ylength'
                fieldSize = (max(fieldBins(:,1))-min(fieldBins(:,1))+1)*binWidth;
        end
    case 'boundary'
        boundary = basis;
        switch lower(measure)
            case 'area'
                fieldSize = polyarea(boundary(1,:),boundary(2,:));
            case {'xlength','length'}
                fieldSize = max(boundary(1,:))-min(boundary(1,:));
            case 'ylength'
                fieldSize = max(boundary(1,:))-min(boundary(1,:));
        end
end