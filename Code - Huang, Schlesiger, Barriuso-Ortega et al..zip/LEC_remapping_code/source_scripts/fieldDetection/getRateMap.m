function [smoothed_map,pospdf] = getRateMap(spk_map,tmap)
box = [0.0025 0.0125 0.0200 0.0125 0.0025;...
    0.0125 0.0625 0.1000 0.0625 0.0125;...
    0.0200 0.1000 0.1600 0.1000 0.0200;...
    0.0125 0.0625 0.1000 0.0625 0.0125;...
    0.0025 0.0125 0.0200 0.0125 0.0025];

pospdf = tmap./sum(sum(tmap));
tmap(tmap < 0.015) = NaN; %eliminate pixels with very low occupancy, Nov. 30, 2010; Increased from 0.01 to 0.150, Jan 10, 2014
map = spk_map./tmap;
map = padarray(map,[2 2],NaN);
for i = 3:size(map,1)-2
    for j = 3:size(map,2)-2
        current_sum = 0;
        current_box = 0;
        box_i = 0;
        for ii = i-2:i+2
            box_i = box_i+1;
            box_j = 0;
            for jj = j-2:j+2
                box_j = box_j+1;
                if ~isnan(map(ii,jj))
                   current_sum = current_sum+map(ii,jj)*box(box_i,box_j);
                   current_box = current_box+box(box_i,box_j);
                end
            end
        end
        smoothed_map(i,j) = current_sum/current_box;
    end
end
smoothed_map = smoothed_map(3:end,3:end);