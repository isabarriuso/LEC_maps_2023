function fieldInfo = generateFieldInfo(rateMapIn,spikeMap,timeMap,fieldData,p)

nSess = size(rateMapIn,1);
nCells = size(rateMapIn,2);
nSegs = size(rateMapIn,3);
fieldInfo = cell(nSess,nCells,nSegs);

for ii = 1:nSess
    for jj = 1:nCells
        for kk = 1:nSegs
            nFields = fieldData(ii,jj,kk).nFields;
            if nFields >0
                for f = 1:nFields
                fieldInfo{ii,jj,kk}(f) = ...
                    getFieldInfo(...
                    rateMapIn{ii,jj,kk},...
                    spikeMap{ii,jj,kk},...
                    timeMap{ii,jj,kk},...
                    fieldData(ii,jj,kk).fieldBounds(f),...
                    fieldData(ii,jj,kk).fieldBins{f},...
                    p);
                end
            end

        end
    end
end