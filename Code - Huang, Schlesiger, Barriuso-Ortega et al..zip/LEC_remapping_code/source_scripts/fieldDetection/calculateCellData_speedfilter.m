function cellData = calculateCellData_speedfilter(x,y,t,v,angle,spkt,spkx, spky, spkv, thetadata,cellName,outputVars,params,savePath)
if isempty(params)
    p = loadParamsRdx();
else
    p = params;
    clear params
end
if isempty(outputVars) || ismember('all',lower(outputVars))
    outputVars = {'spikeMap','coherence','map', 'timeMap'};
end
x = x(v>p.minRunSpeed);
y = y(v>p.minRunSpeed);
t = t(v>p.minRunSpeed);
spkt = spkt(spkv>p.minRunSpeed);
spkx = spkx(spkv>p.minRunSpeed);
spky = spky(spkv>p.minRunSpeed);
%%

timeMap = findTimeMap(x,y,t,p.mapAxis, p.sampRate,p.offset); 

 if ~isempty(intersect(outputVars,{'spikeMap','coherence'}))
     % Calculate Spike maps
     [spikeMap spkx_pixel spky_pixel not_assigned] = rawspkmap(spkx,spky,p.mapAxis,p.offset); 
 end

 if ~isempty(intersect(outputVars,{'coherence'}))
     % Calculate the coherence from the raw map
     visited = visitedBins(x,y,p.mapAxis);
     coherence = fieldcohere(spikeMap);
     
 end


 if ~isempty(intersect(outputVars,'map'))
     % Calculate rate map
     [map] = getRateMap(spikeMap,timeMap);
 end
 

 nVars = length(outputVars);
for v = 1:nVars
    cellData.(outputVars{v}) = eval(outputVars{v});
end