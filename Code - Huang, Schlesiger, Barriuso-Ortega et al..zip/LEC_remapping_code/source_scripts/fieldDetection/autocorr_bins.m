function [corr tcorr n_spikes] = autocorr_bins(spikes,binwidth,tcorrmax)

binned_spikes = binspikes(spikes,1/binwidth);
tcorr=1:tcorrmax; % time-vector for the calculation of correlations
tcorr=(tcorr-1)*binwidth;
nbins = length(binned_spikes);

ncorr = length(tcorr); %number of points of time at which correlation is calculated

corr=zeros(size(tcorr)); % set up the vector that will contain the correlations

for j=1:ncorr % this will generate ncorr values 
    temp = binned_spikes(j:nbins).*binned_spikes(1:nbins+1-j);
    corr(j) = sum(temp);
    %corr(j) = binned_spikes(j:nbins)*binned_spikes(1:nbins+1-j).';
end
n_spikes = sum(binned_spikes);
corr = corr*binwidth;

