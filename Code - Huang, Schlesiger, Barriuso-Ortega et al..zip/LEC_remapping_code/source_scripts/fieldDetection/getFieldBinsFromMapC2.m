function [fieldBins, fieldMask] = getFieldBinsFromMapC2(map,minPeakRate,threshold,minNumBins,mapInterpFactor,pctPeak,dPctPeak)
if nargin<7 || isempty(dPctPeak)
    dPctPeak = 0.01;
end
if nargin<6 || isempty(pctPeak)
    pctPeak = 0.98;
end
if nargin<5 || isempty(mapInterpFactor)
    mapInterpFactor = 5;
end
if nargin<4 || isempty(minNumBins)
    minNumBins = 5;
end
if nargin<3 || isempty(threshold)
    threshold = 0.2;
end
if nargin<2 || isempty(minPeakRate)
    minPeakRate = 2;
end

map(isnan(map))=0;
mapSize = size(map);
imapSize = mapSize*mapInterpFactor+2; %Added a +2 to account for the fact that the imap gets a 0 value pad 3/7/17 GWD

xAxis = linspace(1,mapSize(2),mapSize(2));
yAxis = linspace(1,mapSize(1),mapSize(1));
ixAxis = linspace(1,mapSize(2),mapSize(2)*mapInterpFactor);
iyAxis = linspace(1,mapSize(1),mapSize(1)*mapInterpFactor);

rMax = max(map(:));
imap = interp2(xAxis,yAxis',map,ixAxis,iyAxis');
% imap(1,:) = 0; imap(end,:) = 0; imap(:,1) = 0; imap(:,end) = 0;
imap = padarray(imap,[1 1],0);
currentMinCutoff = threshold*rMax;
nFields = 0;
while pctPeak*rMax>currentMinCutoff

    C0 = contourc(imap,pctPeak*rMax*[1 1]);
    if isempty(C0)
        pctPeak = pctPeak-dPctPeak;
        continue;
    end
    CStr = parseContours(C0);
    nC = length(CStr);
    tmpInds = cell(nC,1);
    CTmp = cell(nC,1);
    rMaxTmp = nan(nC,1);
    keep = false(nC,1);
    nBins = nan(nC,1);
    for ic = 1:nC
        CTmp{ic} = closeLoop([CStr(ic).xdata; CStr(ic).ydata]);
        %Added a scale and shift factor to account for the zero bins added
        %around the map when going back to the original map size 3/7/17 GWD
        nBins(ic) = length(find(poly2mask(((CTmp{ic}(1,:)*(imapSize(2)-2)/imapSize(2))-1)/mapInterpFactor,((CTmp{ic}(2,:)*(imapSize(1)-2)/imapSize(1))-1)/mapInterpFactor,mapSize(2),mapSize(1))));
        tmpInds{ic} = poly2mask(CTmp{ic}(1,:),CTmp{ic}(2,:),imapSize(2),imapSize(1));
    end
    for ic = 1:nC
        if nC>1
            for ic2 = setdiff(1:nC,ic)
                isect = ~isempty((find(logical(tmpInds{ic}) & logical(tmpInds{ic2}))));
                if isect > 0
                    break;
                end
            end
        else
            isect = false;
        end
        if ~isempty(find(tmpInds{ic}, 1)) && ~isect
            rMaxTmp(ic) = max(imap(tmpInds{ic}));
            keep(ic) = nBins(ic)>=minNumBins & max(imap(tmpInds{ic}))>=minPeakRate;
        end
    end
    if isempty(find(keep,1))
        pctPeak = pctPeak-dPctPeak;
        continue;
    end
    if nFields == 0
        C = CTmp(keep);
        fInds = tmpInds(keep);
        fMax = rMaxTmp(keep);
        nFields = length(C);
        fDone = false(nFields,1);
        fv = nan(nFields,1);
        continue;
    else
        CTmp = CTmp(keep);
        tmpInds = tmpInds(keep);
        rMaxTmp = rMaxTmp(keep);
        nC = length(CTmp);
    end
    fAccounted = false(nFields,1);
    tmpAccounted = false(nC,1);
    for ic = 1:nC
        for f = 1:nFields
            nBinsTmp = length(find(logical(tmpInds{ic})));
            nBinsUnion = length(find(logical(tmpInds{ic}) | logical(fInds{f})));
            nBinsISect = length(find(logical(tmpInds{ic}) & logical(fInds{f})));
            if nBinsUnion == nBinsTmp
                if ~fDone(f)
                    absorption = false;
                    for f2 = f+1:nFields
                        nBinsUnion2 = length(find(logical(tmpInds{ic}) | logical(fInds{f2})));
                        if nBinsUnion2 == nBinsTmp
                            absorption = true;
                            break;
                        end
                    end
                    if absorption || (pctPeak*rMax)/fMax(f)<threshold
                        fDone(f) = true;
                        fv(f) = rMax*(pctPeak+dPctPeak);
                    else
                        C{f} = CTmp{ic};
                        fInds{f} = tmpInds{ic};
                        fv(f) = rMax*pctPeak;
                    end
                    
                end
                fAccounted(f) = true;
                tmpAccounted(ic) = true;
                break;
            elseif nBinsISect > 0
                if ~fDone(f)
                    fDone(f) = true;
                    fv(f) = rMax*(pctPeak+dPctPeak);
                end
                fAccounted(f) = true;
                tmpAccounted(ic) = true;
                break;
            end
        end
    end
    
    toAdd = find(~tmpAccounted);
    if ~isempty(toAdd)
        for ic = toAdd'
            fInds = cat(1,fInds,tmpInds(ic));
            C = cat(1,C,CTmp(ic));
            fDone = cat(1,fDone,false);
            fv = cat(1,fv,nan);
            fMax = cat(1,fMax,rMaxTmp(ic));
        end
    end
    currentMinCutoff = threshold*unique(min(fMax));
    nFields = length(fInds);
    figure(1), clf,imagesc(imap)  %Comment in/out here for plotting (begin)
    hold on;
    for f = 1:nFields
        plot(C{f}(1,:),C{f}(2,:),'w','LineWidth',5)
    end  
    pause(.005) %Comment in/out here for plotting (end)
    pctPeak = pctPeak-dPctPeak;
end
fieldBins = cell(nFields,1);
fieldMask = cell(nFields,1);
badField = [];
for f = 1:nFields
    %Added a scale and shift factor to account for the zero bins added
    %around the map when going back to the original map size 3/7/17 GWD
    fieldMask{f} = poly2mask(((C{f}(1,:)*(imapSize(2)-2)/imapSize(2))-1)/mapInterpFactor,((C{f}(2,:)*(imapSize(1)-2)/imapSize(1))-1)/mapInterpFactor,mapSize(2),mapSize(1));
    if max(map(fieldMask{f}))<minPeakRate
        badField = cat(1,badField,f);
    end
    [rowBins colBins] = find(fieldMask{f});
    fieldBins{f} = [rowBins colBins];

end

figure(1), clf,imagesc(imap)  %Comment in/out here for plotting (begin)
hold on;
for f = 1:nFields
    plot(C{f}(1,:),C{f}(2,:),'w','LineWidth',5)
end  
pause(.005) %Comment in/out here for plotting (end)

fieldMask(badField) = [];
fieldBins(badField) = [];

nFields = nFields - length(badField);
figure(1), clf, imagesc(map); %Comment in/out here for plotting (begin)
hold on;
for f = 1:nFields
    scatter(fieldBins{f,1}(:,2),fieldBins{f,1}(:,1))
end  
pause(.1) %Comment in/out here for plotting (end)
if nFields == 0
    fieldMask = cell(0,1);
    fieldBins = cell(0,1);
end