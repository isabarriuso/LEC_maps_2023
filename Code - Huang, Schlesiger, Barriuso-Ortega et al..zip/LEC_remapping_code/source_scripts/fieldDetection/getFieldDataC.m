function fieldData = getFieldDataC(map,minPeakRate,fieldThreshold,minNumBins,mapSizeInterp,xRange,yRange)

fieldBins = getFieldBinsFromMapC2(map,minPeakRate,fieldThreshold,minNumBins);
fieldBounds = findFieldContoursFromFieldBins(map,fieldBins,mapSizeInterp,xRange,yRange);
nFields = length(fieldBounds);

fieldData.nFields = nFields;
fieldData.fieldBounds = fieldBounds;
fieldData.fieldBins = fieldBins;