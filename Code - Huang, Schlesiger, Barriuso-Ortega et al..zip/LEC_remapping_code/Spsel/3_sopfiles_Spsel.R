library(snow)
library(relectro)
library(scales)

workers<-c(rep("localhost",3))
cl<-makeCluster(workers, type = "SOCK",outfile="")
print(paste("Using",length(workers), "threads"))
clusterEvalQ(cl,library(relectro))

#choose 1, uncomment the rest
ep<-new("ElectroProject",directory="/data/projects/LEC_spsel/")
# ep<-new("ElectroProject",directory="/data/projects/MEC_CB/")
# ep<-new("ElectroProject",directory="/data/projects/MEC_PV/")
# ep<-new("ElectroProject",directory="/data/projects/CA1_spsel/")
# ep<-new("ElectroProject",directory="/data/projects/MS_spsel/")

ep<-setSessionList(ep)
save(ep,file=paste(ep@resultsDirectory,"ep",sep="/")) 
load(file=paste(ep@resultsDirectory,"ep",sep="/"))
rss<-getSessionList(ep,clustered=T)
rss<-sortRecSessionListChronologically(rss)

spikeOnPathRes <- function(rs, trial_n=NA){
  print(rs@session)
  source('~/source_scripts/sop_respath.R')
  source('~/source_scripts/Positrack.R')
  library(scales)
  myList <- getRecSessionObjects(rs)
  cg <- myList$cg
  hd <- myList$hd
  pt <- myList$pt
  st <- myList$st
  sp <- myList$sp
  
  pt_positrack <- setInvalidOutsideInterval(pt, s=rs@trialStartRes[c(1,3)], e=rs@trialEndRes[c(1,3)])
  int_posi <- data.frame(start=rs@trialStartRes[c(1,3)], end=rs@trialEndRes[c(1,3)])
  pt_posib <- pt_positrack
  
  for (interval in 1:length(int_posi[,1])){
    pt_posib@x <- pt_positrack@x[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@y <- pt_positrack@y[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@xWhl <- pt_positrack@xWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    pt_posib@yWhl <- pt_positrack@yWhl[which(pt_positrack@res > int_posi[interval,1] & pt_positrack@res < int_posi[interval,2])]
    #set the same scale in the trk files as in the positrack files
    pt@x[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@x))] <- rescale(pt_posib@x[!is.na(pt_posib@x)], to = c(0,70), from=range(pt_posib@x, na.rm = T))
    pt@y[which((pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]) & !is.na(pt@y))] <- rescale(pt_posib@y[!is.na(pt_posib@y)], to = c(0,70), from=range(pt_posib@y, na.rm = T))
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@xWhl[which(pt_posib@xWhl>=0)], to = c(0, 700), from=range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T))
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_posi[interval,1] & pt@res < int_posi[interval,2]))] <- rescale(pt_posib@yWhl[which(pt_posib@yWhl>=0)], to = c(0, 700), from=range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T))
  }

  int_hc <- data.frame(start=rs@trialStartRes[2], end=rs@trialEndRes[2])
  pt_hc <- setInvalidOutsideInterval(pt, s=int_hc[,1],e=int_hc[,2])
  x_save <- range(pt_posib@x, na.rm = T)
  y_save <- range(pt_posib@y, na.rm = T)
  xw_save <- range(pt_posib@xWhl[which(pt_posib@xWhl>=0)], na.rm = T)
  yw_save <- range(pt_posib@yWhl[which(pt_posib@yWhl>=0)], na.rm = T)
  for (t in 1:nrow(int_hc)){
    #get x and y values of trial number t (of the OF trials in room 55)
    x <- pt_hc@x[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    y <- pt_hc@y[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    xWhl <- pt_hc@xWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    yWhl <- pt_hc@yWhl[which(pt_hc@res > int_hc[t,1] & pt_hc@res < int_hc[t,2])]
    
    pt@x[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@x))] <- rescale(x[!is.na(x)], to = c(0,70), from=x_save)
    pt@y[which((pt@res > int_hc[t,1] & pt@res < int_hc[t,2]) & !is.na(pt@y))] <- rescale(y[!is.na(y)], to = c(0,70), from=y_save)
    pt@xWhl[which(pt@xWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(xWhl[which(xWhl>=0)], to = c(0, 700), from=xw_save) 
    pt@yWhl[which(pt@yWhl>=0 & (pt@res > int_hc[t,1] & pt@res < int_hc[t,2]))] <- rescale(yWhl[which(yWhl>=0)], to = c(0, 700), from=yw_save) 
  }
  rm(x, y, yWhl, xWhl, pt_hc, int_hc, int_posi, pt_posib, pt_positrack) #free some memory
  
  pt@speed<- .Call("speed_from_whl_cwrap",
                   as.numeric(pt@x),
                   as.numeric(pt@y),
                   length(pt@x),
                   1.0, # already in cm
                   pt@samplingRateDat, 
                   pt@resSamplesPerWhlSample)
  pt@speed[which(pt@speed==(-1.0))] <- NA
  
  print(paste('min x_cm:', min(pt@x, na.rm = T),'; max x_cm:', max(pt@x, na.rm = T)))
  print(paste('min y_cm:', min(pt@y, na.rm = T),'; max y_cm:', max(pt@y, na.rm = T)))
  
  print("Selecting res values for specified trial...")
  if (isTRUE(is.numeric(trial_n))){
    print(rs@trialStartRes[trial_n])
    print(rs@trialEndRes[trial_n])
    pt <- setInvalidOutsideInterval(pt,s=rs@trialStartRes[trial_n], e=rs@trialEndRes[trial_n])
    st <- setIntervals(st,s=rs@trialStartRes[trial_n], e=rs@trialEndRes[trial_n])
  }
  print("creating sop_res file...")
  sop_res <- spikeOnPath_res(sp, st, pt)

  #store the results in files readable outside of R
  write.csv(as.data.frame(sop_res[1:3]), file = paste("~/LEC_remapping/results/Spsel_sop/",rs@session,"_",trial_n,".xyPath", sep = ""))
  write.csv(as.data.frame(sop_res[4:length(sop_res)]), file=paste("~/LEC_remapping/results/Spsel_sop/",rs@session,"_",trial_n,".sop_phase_laser", sep = ""))
  return(result=sop_res)
}


#1st OF trial
runOnSessionList(ep,sessionList=rss, fnct=spikeOnPathRes, save=T,overwrite=T, 
                 trial_n=1, parallel = F, cluster= cl) 
#2nd OF trials
runOnSessionList(ep,sessionList=rss, fnct=spikeOnPathRes,save=T,overwrite=T, 
                trial_n=3, parallel = F, cluster= cl)

stopCluster(cl)
rm(cl,workers)