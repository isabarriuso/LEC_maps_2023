## plot results figure 1
library(ggplot2)
library(ggridges)
library(scales)
library(ggpubr)
library(FSA)

res_dir <-'~/LEC_remapping/results/'

################### load all datasets ##################################
#LEC
cells_all1 <- read.csv(paste(res_dir,"Spsel_stats_wv_LEC.csv", sep=""), header = T)
cells_all1$region <- 'lec'
#MEC
cells_all2 <- read.csv(paste(res_dir,"Spsel_stats_wv_LEC.csv", sep=""), header = T)
cells_all2$region <- 'mec'
## for excitatory neurons:
celltypes_mec <- read.csv("/data/projects/Schlesiger2021/results/sumtable_celltypes_Tobi.csv", header = T)
levels(celltypes_mec$cell_id) <- levels(cells_all2$cell.id)
cells_all2 <- cells_all2[which(cells_all2$cell.id %in% celltypes_mec$cell_id[which(celltypes_mec$thetalocked==1 & celltypes_mec$trough==1)]),]
#CA1
cells_all3 <- read.csv(paste(res_dir,"Spsel_stats_wv_CA1.csv", sep=""), header = T)
cells_all3$region <- 'ca1'
#MS
cells_all4 <- read.csv(paste(res_dir,"Spsel_stats_wv_MS.csv", sep=""), header = T)
cells_all4$region <- 'ms'

cells_all <- rbind(cells_all1, cells_all2, cells_all3, cells_all4)
cells_all$region <- factor(cells_all$region, levels=c("lec", "mec", "ca1", "ms"))


cells_all$spatial <- "nonspatial"
cells_all$spatial[which(cells_all$IS_S1>cells_all$Threshold95_IS_S1 & cells_all$MS_S1ab>cells_all$Threshold95_MS_S1)] <- "spatial"

#proportion of spatial neurons
#pie chart
library(stringr)
library(dplyr)
plot_data <- cells_all %>% 
  group_by(region, spatial) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = region, y = percent, fill=spatial)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 0),'%', sep = "")), position = position_stack(vjust=0.5), color="white") +#,vjust = 1.2
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_void() + 
  scale_fill_manual(values = c('#74d2c2','#0a3010',"#f2dd69", '#ff7f11', '#FFB370', '#A21632'))#+

#last session lec
mean(cells_all_f$IS_S1[which(cells_all_f$region=="lec" & (cells_all_f$session=="ms6770-15122018-0107" | cells_all_f$session=="ms6769-25012019-0107" | cells_all_f$session=="ms6912a-08032019-0107" | cells_all_f$session=="ms7026-29042019-0107" | cells_all_f$session=="ms7053-13062019-0107"))], na.rm = T)
mean(cells_all_f$MS_S1ab[which(cells_all_f$region=="lec" & (cells_all_f$session=="ms6770-15122018-0107" | cells_all_f$session=="ms6769-25012019-0107" | cells_all_f$session=="ms6912a-08032019-0107" | cells_all_f$session=="ms7026-29042019-0107" | cells_all_f$session=="ms7053-13062019-0107"))], na.rm = T)


##### excitatory neurons
cells_all_f <- cells_all[which(cells_all$MFR_S1>0.1 & cells_all$MFR_S2>0.1 & cells_all$MFR_S1<5. & cells_all$MFR_S2<5. &
                                 cells_all$trough.to.peak.duration.s1>0.4 & cells_all$spike.asymmetry.s1<0.1),]

ggplot(cells_all_f, mapping=aes(x=IS_S1, color=region))+
  stat_ecdf()+
  xlim(c(0,2))+
  theme_classic()+#facet_grid(.~region)+#facet_wrap(.~mouse)+
  theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12), 
        axis.title.y = element_text(size = 14), axis.title.x = element_blank(), 
        legend.text = element_text(size = 12), legend.title = element_text(size = 14), legend.position="right",
        strip.text = element_text(size=14))+
  scale_color_manual(values=c('#F4AE51', '#8FBC8D', '#6499CC','#635D5B', '#50a1d9', 'black','grey'))

ggplot(cells_all_f, mapping=aes(x=MS_S1ab, color=region))+
  stat_ecdf()+
  xlim(c(0,1))+
  theme_classic()+
  theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12), 
        axis.title.y = element_text(size = 14), axis.title.x = element_blank(), 
        legend.text = element_text(size = 12), legend.title = element_text(size = 14), legend.position="right",
        strip.text = element_text(size=14))+
  scale_color_manual(values=c('#F4AE51', '#8FBC8D', '#6499CC','#635D5B', '#50a1d9', 'black','grey'))

ggplot(cells_all, mapping = aes(x=Threshold95_IS_S1, y=IS_S1, color=spatial))+
  geom_point()+ facet_wrap(.~region)+
  scale_color_manual(values=c('black', 'red'))+
  coord_equal()+ xlim(c(0, 0.5))+ ylim(c(-0.25, 1))+
  geom_abline(slope = 1, intercept = 0, linetype="dashed")+
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

ggplot(cells_all, mapping = aes(x=Threshold95_MS_S1ab, y=MS_S1ab, color=spatial))+
  geom_point()+ facet_wrap(.~region)+
  scale_color_manual(values=c('black', 'red'))+
  coord_equal()+ xlim(c(0, 0.5))+ ylim(c(-0.25, 1))+
  geom_abline(slope = 1, intercept = 0, linetype="dashed")+
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

library(stringr)
library(dplyr)
plot_data <- cells_all_f %>% 
  group_by(region, spatial) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = region, y = percent, fill=spatial)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 1),'%', sep = "")), position = position_stack(vjust=0.5), color="white")+
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_classic2()+ 
  scale_fill_manual(values = c('#74d2c2','#0a3010'))#+

#Supplementary Figure S2
ggplot(cells_all_f[which(cells_all_f$region=="lec"),], mapping=aes(y=IS_S1, x=Mouse_number))+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+
  geom_point(aes(color=region), position = position_jitterdodge(jitter.width = 1.0))+
  theme_classic()+
  theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12), 
        axis.title.y = element_text(size = 14), axis.title.x = element_blank(), 
        legend.text = element_text(size = 12), legend.title = element_text(size = 14), legend.position="right",
        strip.text = element_text(size=14))+
  scale_color_manual(values=c('#F4AE51'))

ggplot(cells_all_f[which(cells_all_f$region=="lec"),], mapping=aes(y=MS_S1ab, x=Mouse_number))+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+
  geom_point(aes(color=region), position = position_jitterdodge(jitter.width = 1.0))+
  theme_classic()+
  theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12), 
        axis.title.y = element_text(size = 14), axis.title.x = element_blank(), 
        legend.text = element_text(size = 12), legend.title = element_text(size = 14), legend.position="right",
        strip.text = element_text(size=14))+
  scale_color_manual(values=c('#F4AE51'))

library(stringr)
library(dplyr)
plot_data <- cells_all_f[which(cells_all_f$region=="lec")] %>% 
  group_by(Mouse_number, spatial) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = Mouse_number, y = percent, fill=spatial)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 1),'%', sep = "")), position = position_stack(vjust=0.5), color="white") +#,vjust = 1.2
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_classic2()+ 
  scale_fill_manual(values = c('#74d2c2','#F4AE51'))#+

############ Figure 3: inhibitory neurons
ggplot(cells_all, mapping = aes(x=trough.to.peak.duration.s1, y=spike.asymmetry.s1, color=region))+
  geom_point()+
  facet_wrap(.~region)+
  scale_color_manual(values=c('#F4AE52','#8DBB8B', '#50a1d9', '#625C5B','#164060', '#50a1d9', 'black','grey'))+
  theme_linedraw()+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  geom_hline(yintercept=0.1, linetype="dashed")+
  geom_vline(xintercept=0.4, linetype="dashed")

#prop inhibitory
cells_all$exin <- "other"
cells_all$exin[which(cells_all$MFR_S1>5. & cells_all$MFR_S2>5. & cells_all$ttp<0.4 & cells_all$spike.asymmetry>0.1)] <- "fast-spiking"

cells_all_f <- cells_all[which(cells_all$MFR_S1>0.1 & cells_all$MFR_S2>0.1),]
library(stringr)
library(dplyr)
plot_data <- cells_all_f %>% 
  group_by(region, exin) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = region, y = percent, fill=exin)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 1),'%', sep = "")), position = position_stack(vjust=0.5), color="white") +
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_minimal() + 
  scale_fill_manual(values = c('#74d2c2','#0a3010',"#f2dd69", '#ff7f11', '#FFB370', '#A21632'))#+

#prop spatial (inhibitory)
cells_all_f <- cells_all[which(cells_all$MFR_S1>5. & cells_all$MFR_S2>5. & cells_all$trough.to.peak.duration.s1<0.4 & cells_all$spike.asymmetry.s1>0.1),]
library(stringr)
library(dplyr)
plot_data <- cells_all_f %>% 
  group_by(region, spatial) %>% 
  tally %>% 
  mutate(percent = n/sum(n))

ggplot(plot_data, aes(x = region, y = percent, fill=spatial)) +
  geom_bar(show.legend=T,position="fill",stat = "identity") +
  geom_text(aes(label = paste(round(percent*100, digits = 1),'%', sep = "")), position = position_stack(vjust=0.5), color="white") +
  scale_y_continuous(labels = percent, limits = c(0,1))+
  theme_classic() + 
  scale_fill_manual(values = c('#74d2c2','#0a3010',"#f2dd69", '#ff7f11', '#FFB370', '#A21632'))#+

ggplot(cells_all_f[which(cells_all_f$region=="lec"),], mapping=aes(y=MFR_S1, x=region))+
  geom_boxplot(outlier.alpha=0, coef=0, alpha=0)+
  geom_point(aes(color=region), position = position_jitterdodge(jitter.width = 1.0))+
  theme_classic()+
  theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12), 
        axis.title.y = element_text(size = 14), axis.title.x = element_blank(), 
        legend.text = element_text(size = 12), legend.title = element_text(size = 14), legend.position="right",
        strip.text = element_text(size=14))+
  scale_color_manual(values=c('#F4AE51', '#8FBC8D', '#6499CC','#635D5B', '#50a1d9', 'black','grey'))

